package com.jtkj.led1248.light.utils;
public class CoolledUUtils extends com.jtkj.led1248.light.utils.LightUtils {
    private static final String OTA_FILE_NAME = "coolledu.bin";
    private static final String TAG = "CoolledUUtils";
    private static final java.util.List colorFulFrameTypeFour;
    private static final java.util.List colorFulFrameTypeOne;
    private static final java.util.List colorFulFrameTypeThree;
    private static final java.util.List colorFulFrameTypeTwo;
    private static final java.util.List colorTypeEight;
    private static final java.util.List colorTypeEleven;
    private static final java.util.List colorTypeFive;
    private static final java.util.List colorTypeFour;
    private static final java.util.List colorTypeFourTeen;
    private static final java.util.List colorTypeNine;
    private static final java.util.List colorTypeOne;
    private static final java.util.List colorTypeSeven;
    private static final java.util.List colorTypeSix;
    private static final java.util.List colorTypeTen;
    private static final java.util.List colorTypeThirteen;
    private static final java.util.List colorTypeThree;
    private static final java.util.List colorTypeTwelve;
    private static final java.util.List colorTypeTwo;
    private static final java.util.List fourColorFrameTypeFour;
    private static final java.util.List fourColorFrameTypeOne;
    private static final java.util.List fourColorFrameTypeThree;
    private static final java.util.List fourColorFrameTypeTwo;
    private static final java.util.List greenColorFrameTypeOne;
    private static final java.util.List greenColorFrameTypeThree;
    private static final java.util.List greenColorFrameTypeTwo;
    private static final java.util.List redColorFrameTypeOne;
    private static final java.util.List redColorFrameTypeThree;
    private static final java.util.List redColorFrameTypeTwo;
    private static final java.util.List threeColorFrameTypeOne;
    private static final java.util.List threeColorFrameTypeThree;
    private static final java.util.List threeColorFrameTypeTwo;
    private static final java.util.List yellowColorFrameTypeOne;
    private static final java.util.List yellowColorFrameTypeThree;
    private static final java.util.List yellowColorFrameTypeTwo;

    static CoolledUUtils()
    {
        com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$1();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$2();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$3();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeFour = new com.jtkj.led1248.light.utils.CoolledUUtils$4();
        com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$5();
        com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$6();
        com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$7();
        com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$8();
        com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$9();
        com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$10();
        com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$11();
        com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$12();
        com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$13();
        com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeFour = new com.jtkj.led1248.light.utils.CoolledUUtils$14();
        com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$15();
        com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$16();
        com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$17();
        com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$18();
        com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$19();
        com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$20();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeOne = new com.jtkj.led1248.light.utils.CoolledUUtils$21();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTwo = new com.jtkj.led1248.light.utils.CoolledUUtils$22();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeThree = new com.jtkj.led1248.light.utils.CoolledUUtils$23();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFour = new com.jtkj.led1248.light.utils.CoolledUUtils$24();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFive = new com.jtkj.led1248.light.utils.CoolledUUtils$25();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeSix = new com.jtkj.led1248.light.utils.CoolledUUtils$26();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeSeven = new com.jtkj.led1248.light.utils.CoolledUUtils$27();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeEight = new com.jtkj.led1248.light.utils.CoolledUUtils$28();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeNine = new com.jtkj.led1248.light.utils.CoolledUUtils$29();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTen = new com.jtkj.led1248.light.utils.CoolledUUtils$30();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeEleven = new com.jtkj.led1248.light.utils.CoolledUUtils$31();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTwelve = new com.jtkj.led1248.light.utils.CoolledUUtils$32();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeThirteen = new com.jtkj.led1248.light.utils.CoolledUUtils$33();
        com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFourTeen = new com.jtkj.led1248.light.utils.CoolledUUtils$34();
        return;
    }

    public CoolledUUtils()
    {
        return;
    }

    private static java.util.List convertData(java.util.List p4, int p5)
    {
        while (p5 < p4.size()) {
            int v0_1 = Integer.valueOf(((String) p4.get(p5)), 16).intValue();
            if ((v0_1 <= Integer.parseInt("00", 16)) || (v0_1 >= Integer.valueOf("04", 16).intValue())) {
                p5++;
            } else {
                p4.add(p5, "02");
                p4.set((p5 + 1), com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt((v0_1 ^ Integer.valueOf("04", 16).intValue())));
                int v5_1 = (p5 + 2);
                if (v5_1 > (p4.size() - 1)) {
                    break;
                }
                return com.jtkj.led1248.light.utils.CoolledUUtils.convertData(p4, v5_1);
            }
        }
        return p4;
    }

    public static java.util.List convertEnd(java.util.List p3)
    {
        int v0_1 = Integer.valueOf("00", 16).intValue();
        java.util.List v3_2 = p3.iterator();
        while (v3_2.hasNext()) {
            v0_1 ^= Integer.valueOf(((String) v3_2.next()), 16).intValue();
        }
        return com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForInt(v0_1);
    }

    public static java.util.List dealWithArbAndXbl(java.util.List p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        int v1_0 = (p3.size() - 1);
        while (v1_0 >= 0) {
            v0_1.add(((com.jtkj.led1248.light.emoji.TextEmojiManager$TextEmojiItem) p3.get(v1_0)));
            v1_0--;
        }
        return v0_1;
    }

    public static java.util.List getAnimationData(java.util.List p0, int p1, int p2)
    {
        return com.jtkj.led1248.light.utils.CoolledUUtils.getAnimationDataColor(p0, p1, p2);
    }

    public static java.util.List getAnimationDataColor(java.util.List p6, int p7, int p8)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.Iterator v6_1 = p6.iterator();
        while (v6_1.hasNext()) {
            int v3 = 0;
            while (v3 < p7) {
                int v4 = 0;
                while (v4 < p8) {
                    v0_1.addAll(com.jtkj.led1248.light.emoji.TextEmojiManagerCoolLEDU.getColorDataWithColorWithRGB444Transfer(((com.jtkj.led1248.widget.DrawView$DrawItem) ((java.util.List) v6_1.next()).get(((v4 * p7) + v3))).color));
                    v4++;
                }
                v3++;
            }
        }
        return v0_1;
    }

    public static java.util.List getCheckPasswordData(String p6)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0d");
        int v1_4 = new java.util.Random().nextInt(256);
        com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v1_4);
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v1_4));
        int v2_1 = 0;
        while (v2_1 < p6.length()) {
            String v3_6 = Integer.valueOf(new StringBuilder("0").append(p6.charAt(v2_1)).toString(), 16).intValue();
            com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v3_6);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt((v3_6 ^ v1_4)));
            v2_1++;
        }
        java.util.List v6_3 = Integer.valueOf("00", 16).intValue();
        int v1_1 = 2;
        while (v1_1 < v0_1.size()) {
            v6_3 ^= Integer.valueOf(((String) v0_1.get(v1_1)), 16).intValue();
            v1_1++;
        }
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v6_3));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getDataForCombineProgram(com.jtkj.led1248.light.device.DeviceManager$CoolleduCombineProgram p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        if (p3.getType() != 2) {
            if (p3.getType() != 1) {
                if (p3.getType() != 4) {
                    if (p3.getType() == 3) {
                        java.util.List v3_2 = ((com.jtkj.led1248.light.device.DeviceManager$CoolleduTextCombineProgram) p3).textItem;
                        if (v3_2.textContentProgramContent != null) {
                            if (v3_2.textCustomColorProgramContent != null) {
                                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithTextCustomColorProgramContent(v3_2.textCustomColorProgramContent));
                            }
                            if (v3_2.textAutoColorProgramContent != null) {
                                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithTextAutoColorProgramContent(v3_2.textAutoColorProgramContent));
                            }
                            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithTextContentProgramContent(v3_2.textContentProgramContent));
                        }
                        if (v3_2.frameItem != null) {
                            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithFrameProgramContent(v3_2.frameItem));
                        }
                    }
                    return v0_1;
                } else {
                    v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithFrameProgramContent(((com.jtkj.led1248.light.device.DeviceManager$CoolleduFrameCombineProgram) p3).frameProgramContent));
                    return v0_1;
                }
            } else {
                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithGraffitiCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$CoolleduGraffitiCombineProgram) p3).graffitiItem.graffitiProgramContent));
                return v0_1;
            }
        } else {
            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithAnimationCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$CoolleduAnimationCombineProgram) p3).animationItem.animationProgramContent));
            return v0_1;
        }
    }

    public static java.util.List getDataForProgram(com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.Iterator v2_2 = p2.combinePrograms.iterator();
        while (v2_2.hasNext()) {
            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataForCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$CoolleduCombineProgram) v2_2.next())));
        }
        return v0_1;
    }

    public static java.util.List getDataPacket(java.util.List p8, String p9)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        java.util.List v2_7 = (p8.size() / 1024);
        java.util.ArrayList v3_14 = (p8.size() % 1024);
        int v4 = 0;
        int v5 = 0;
        while (v5 < v2_7) {
            java.util.List v6_0 = (v5 * 1024);
            v5++;
            v1_1.add(p8.subList(v6_0, (v5 * 1024)));
        }
        if (v3_14 > null) {
            v1_1.add(p8.subList((v2_7 * 1024), p8.size()));
        }
        while (v4 < v1_1.size()) {
            java.util.List v2_4 = new java.util.ArrayList();
            v2_4.add("00");
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(p8));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwo(v4));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwo(((java.util.List) v1_1.get(v4)).size()));
            v2_4.addAll(((java.util.Collection) v1_1.get(v4)));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.convertEnd(v2_4));
            java.util.ArrayList v3_12 = new java.util.ArrayList();
            v3_12.add(p9);
            v3_12.addAll(v2_4);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v3_12));
            v4++;
        }
        return v0_1;
    }

    public static com.jtkj.led1248.light.utils.CoolledUUtils$DataResult getDataResult(com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram p2, int p3)
    {
        com.jtkj.led1248.light.utils.CoolledUUtils$DataResult v0_1 = new com.jtkj.led1248.light.utils.CoolledUUtils$DataResult();
        java.util.List v2_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithProgram(p2);
        v0_1.beginDataForProgram = com.jtkj.led1248.light.utils.CoolledUUtils.getStartDataForProgram(v2_3, p3);
        java.util.ArrayList v3_3 = new java.util.ArrayList();
        v3_3.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledUUtils$LzssCompress.getLzssCompressData(v2_3), "03"));
        v0_1.dataForProgram = v3_3;
        return v0_1;
    }

    public static com.jtkj.led1248.light.utils.CoolledUUtils$DataResult getDataResult(com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram p1, int p2, int p3)
    {
        com.jtkj.led1248.light.utils.CoolledUUtils$DataResult v0_1 = new com.jtkj.led1248.light.utils.CoolledUUtils$DataResult();
        java.util.List v1_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getDataWithProgram(p1);
        v0_1.beginDataForProgram = com.jtkj.led1248.light.utils.CoolledUUtils.getStartDataForProgram(v1_3, p2, p3);
        java.util.ArrayList v2_3 = new java.util.ArrayList();
        v2_3.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledUUtils$LzssCompress.getLzssCompressData(v1_3), "03"));
        v0_1.dataForProgram = v2_3;
        return v0_1;
    }

    public static java.util.List getDataWithAnimationCombineProgram(com.jtkj.led1248.light.device.DeviceManager$CoolleduAnimationProgramContent p5)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("03");
        java.util.List v2_16 = 0;
        while (v2_16 < 7) {
            v1_1.add("00");
            v2_16++;
        }
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p5.layerType));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.showHeight));
        v1_1.add("00");
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.speed));
        java.util.List v5_2 = com.jtkj.led1248.light.utils.CoolledUUtils.getAnimationData(p5.mListDrawItems, p5.showWidth, p5.showHeight);
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(v5_2.size()));
        v1_1.addAll(v5_2);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDataWithFrameProgramContent(com.jtkj.led1248.light.device.DeviceManager$CoolleduFrameProgramContent p7)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledUUtils.TAG, new StringBuilder("getDataWithFrameProgramContent>>>").append(p7.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("04");
        java.util.List v2_15 = 0;
        while (v2_15 < 7) {
            v1_2.add("00");
            v2_15++;
        }
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p7.layerType));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p7.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p7.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p7.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p7.showHeight));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p7.frameShowType));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p7.speed));
        if (p7.frameType != 1) {
            if (p7.frameType != 2) {
                if (p7.frameType != 3) {
                    if (p7.frameType != 4) {
                        if (p7.frameType != 5) {
                            if (p7.frameType != 6) {
                                if (p7.frameType != 7) {
                                    if (p7.frameType != 8) {
                                        if (p7.frameType != 9) {
                                            if (p7.frameType != 10) {
                                                if (p7.frameType != 11) {
                                                    if (p7.frameType != 12) {
                                                        if (p7.frameType != 13) {
                                                            if (p7.frameType != 14) {
                                                                if (p7.frameType != 15) {
                                                                    if (p7.frameType != 16) {
                                                                        if (p7.frameType != 17) {
                                                                            if (p7.frameType != 18) {
                                                                                if (p7.frameType != 19) {
                                                                                    if (p7.frameType == 20) {
                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                                        java.util.List v7_3 = com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeThree;
                                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_3.size()));
                                                                                        v1_2.addAll(v7_3);
                                                                                    }
                                                                                } else {
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                                    java.util.List v7_5 = com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeTwo;
                                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_5.size()));
                                                                                    v1_2.addAll(v7_5);
                                                                                }
                                                                            } else {
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                                java.util.List v7_7 = com.jtkj.led1248.light.utils.CoolledUUtils.yellowColorFrameTypeOne;
                                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_7.size()));
                                                                                v1_2.addAll(v7_7);
                                                                            }
                                                                        } else {
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                            java.util.List v7_9 = com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeThree;
                                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_9.size()));
                                                                            v1_2.addAll(v7_9);
                                                                        }
                                                                    } else {
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                        java.util.List v7_11 = com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeTwo;
                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_11.size()));
                                                                        v1_2.addAll(v7_11);
                                                                    }
                                                                } else {
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                    java.util.List v7_13 = com.jtkj.led1248.light.utils.CoolledUUtils.greenColorFrameTypeOne;
                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_13.size()));
                                                                    v1_2.addAll(v7_13);
                                                                }
                                                            } else {
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                java.util.List v7_15 = com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeFour;
                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_15.size()));
                                                                v1_2.addAll(v7_15);
                                                            }
                                                        } else {
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                            java.util.List v7_17 = com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeThree;
                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_17.size()));
                                                            v1_2.addAll(v7_17);
                                                        }
                                                    } else {
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                        java.util.List v7_19 = com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeTwo;
                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_19.size()));
                                                        v1_2.addAll(v7_19);
                                                    }
                                                } else {
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                    java.util.List v7_21 = com.jtkj.led1248.light.utils.CoolledUUtils.fourColorFrameTypeOne;
                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_21.size()));
                                                    v1_2.addAll(v7_21);
                                                }
                                            } else {
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                java.util.List v7_23 = com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeThree;
                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_23.size()));
                                                v1_2.addAll(v7_23);
                                            }
                                        } else {
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                            java.util.List v7_25 = com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeTwo;
                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_25.size()));
                                            v1_2.addAll(v7_25);
                                        }
                                    } else {
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                        java.util.List v7_27 = com.jtkj.led1248.light.utils.CoolledUUtils.redColorFrameTypeOne;
                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_27.size()));
                                        v1_2.addAll(v7_27);
                                    }
                                } else {
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                    java.util.List v7_29 = com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeThree;
                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_29.size()));
                                    v1_2.addAll(v7_29);
                                }
                            } else {
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                java.util.List v7_31 = com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeTwo;
                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_31.size()));
                                v1_2.addAll(v7_31);
                            }
                        } else {
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                            java.util.List v7_33 = com.jtkj.led1248.light.utils.CoolledUUtils.threeColorFrameTypeOne;
                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_33.size()));
                            v1_2.addAll(v7_33);
                        }
                    } else {
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                        java.util.List v7_35 = com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeFour;
                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_35.size()));
                        v1_2.addAll(v7_35);
                    }
                } else {
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                    java.util.List v7_37 = com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeThree;
                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_37.size()));
                    v1_2.addAll(v7_37);
                }
            } else {
                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                java.util.List v7_39 = com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeTwo;
                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_39.size()));
                v1_2.addAll(v7_39);
            }
        } else {
            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
            java.util.List v7_41 = com.jtkj.led1248.light.utils.CoolledUUtils.colorFulFrameTypeOne;
            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v7_41.size()));
            v1_2.addAll(v7_41);
        }
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithGraffitiCombineProgram(com.jtkj.led1248.light.device.DeviceManager$CoolleduGraffitiProgramContent p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("02");
        java.util.List v2_19 = 0;
        while (v2_19 < 7) {
            v1_1.add("00");
            v2_19++;
        }
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.layerType));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.showHeight));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.mode));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.speed));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.stayTime));
        java.util.List v4_2 = com.jtkj.led1248.light.utils.CoolledUUtils.getGraffitiData(p4.mDrawItems, p4.showWidth, p4.showHeight);
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(v4_2.size()));
        v1_1.addAll(v4_2);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDataWithProgram(com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.List v1_4 = new java.util.ArrayList();
        int v2 = 0;
        while (v2 < 8) {
            v1_4.add("00");
            v2++;
        }
        v0_1.addAll(v1_4);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForWithOneByte(p4.getContentNumber()));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForWithOneByte(p4.showCount));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataForProgram(p4));
        return v0_1;
    }

    public static java.util.List getDataWithTextAutoColorProgramContent(com.jtkj.led1248.light.device.DeviceManager$CoolleduTextAutoColorProgramContent p10)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledUUtils.TAG, new StringBuilder("getDataWithTextAutoColorProgramContent>>>").append(p10.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("05");
        String v3_4 = 0;
        while (v3_4 < 7) {
            v1_2.add("00");
            v3_4++;
        }
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p10.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p10.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p10.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p10.showHeight));
        if (p10.autoColorType != 1) {
            if (p10.autoColorType != 2) {
                if (p10.autoColorType != 3) {
                    if (p10.autoColorType != 4) {
                        if (p10.autoColorType != 5) {
                            if (p10.autoColorType != 6) {
                                if (p10.autoColorType != 7) {
                                    if (p10.autoColorType != 8) {
                                        if (p10.autoColorType != 9) {
                                            if (p10.autoColorType != 10) {
                                                if (p10.autoColorType != 11) {
                                                    if (p10.autoColorType != 12) {
                                                        if (p10.autoColorType != 13) {
                                                            if (p10.autoColorType == 14) {
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(8));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                                java.util.List v10_73 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFourTeen;
                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_73.size()));
                                                                v1_2.addAll(v10_73);
                                                            }
                                                        } else {
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(8));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                            java.util.List v10_5 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeThirteen;
                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_5.size()));
                                                            v1_2.addAll(v10_5);
                                                        }
                                                    } else {
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(7));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                        java.util.List v10_10 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTwelve;
                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_10.size()));
                                                        v1_2.addAll(v10_10);
                                                    }
                                                } else {
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(7));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                    java.util.List v10_15 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeEleven;
                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_15.size()));
                                                    v1_2.addAll(v10_15);
                                                }
                                            } else {
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(6));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                                java.util.List v10_20 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTen;
                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_20.size()));
                                                v1_2.addAll(v10_20);
                                            }
                                        } else {
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(6));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                            java.util.List v10_25 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeNine;
                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_25.size()));
                                            v1_2.addAll(v10_25);
                                        }
                                    } else {
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(5));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                        java.util.List v10_30 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeEight;
                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_30.size()));
                                        v1_2.addAll(v10_30);
                                    }
                                } else {
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(4));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(5));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                    java.util.List v10_35 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeSeven;
                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_35.size()));
                                    v1_2.addAll(v10_35);
                                }
                            } else {
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(4));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(4));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                                java.util.List v10_40 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeSix;
                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_40.size()));
                                v1_2.addAll(v10_40);
                            }
                        } else {
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(3));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(3));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                            java.util.List v10_45 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFive;
                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_45.size()));
                            v1_2.addAll(v10_45);
                        }
                    } else {
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(3));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(2));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                        java.util.List v10_50 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeFour;
                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_50.size()));
                        v1_2.addAll(v10_50);
                    }
                } else {
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(2));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                    java.util.List v10_55 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeThree;
                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_55.size()));
                    v1_2.addAll(v10_55);
                }
            } else {
                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
                java.util.List v10_60 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeTwo;
                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_60.size()));
                v1_2.addAll(v10_60);
            }
        } else {
            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p10.speed));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
            java.util.List v10_65 = com.jtkj.led1248.light.utils.CoolledUUtils.colorTypeOne;
            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v10_65.size()));
            v1_2.addAll(v10_65);
        }
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithTextContentProgramContent(com.jtkj.led1248.light.device.DeviceManager$CoolleduTextContentProgramContent p4)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledUUtils.TAG, new StringBuilder("getDataWithTextContentProgramContent>>>").append(p4.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("01");
        java.util.List v2_1 = 0;
        while (v2_1 < 7) {
            v1_2.add("00");
            v2_1++;
        }
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.layerType));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p4.showHeight));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.mode));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.speed));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p4.stayTime));
        java.util.List v4_1 = com.jtkj.led1248.light.utils.CoolledUUtils.getTextDataForEmoji(p4, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(v4_1.data.size()));
        v1_2.addAll(v4_1.data);
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithTextCustomColorProgramContent(com.jtkj.led1248.light.device.DeviceManager$CoolleduTextCustomColorProgramContent p5)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("06");
        java.util.List v2_22 = 0;
        while (v2_22 < 7) {
            v1_1.add("00");
            v2_22++;
        }
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(p5.showHeight));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p5.mode));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p5.speed));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p5.stayTime));
        v1_1.add("00");
        java.util.List v5_1 = com.jtkj.led1248.light.utils.CoolledUUtils.getTextCustomColorDataForEmoji(p5, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v5_1.textNumber));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithTwoByte(v5_1.allTextWidth));
        v1_1.addAll(v5_1.allTextWidths);
        v1_1.addAll(v5_1.allTextColors);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDeviceInfo()
    {
        java.util.List v0_1 = new java.util.ArrayList();
        v0_1.add("1f");
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getDrawListDataFColor(java.util.List p5, int p6, int p7)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        int v2 = 0;
        while (v2 < p6) {
            int v3 = 0;
            while (v3 < p7) {
                v0_1.addAll(com.jtkj.led1248.light.emoji.TextEmojiManagerCoolLEDU.getColorDataWithColorWithRGB444Transfer(((com.jtkj.led1248.widget.DrawView$DrawItem) p5.get(((v3 * p6) + v2))).color));
                v3++;
            }
            v2++;
        }
        return v0_1;
    }

    public static java.util.List getGraffitiData(java.util.List p0, int p1, int p2)
    {
        return com.jtkj.led1248.light.utils.CoolledUUtils.getDrawListDataFColor(p0, p1, p2);
    }

    public static java.util.List getMusicDataString(int p2, int[] p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("01");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForInt(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataString(p3));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getOTAData(android.content.Context p2)
    {
        try {
            java.util.List v2_5 = p2.getResources().getAssets().open("coolledu.bin");
            byte[] v0 = com.jtkj.led1248.light.utils.CoolledUUtils.readStream(v2_5);
            v2_5.close();
        } catch (java.util.List v2_1) {
            com.jtkj.led1248.CoolLED.reportError(v2_1);
        }
        return com.jtkj.led1248.light.utils.CoolledUUtils.byte2hex(v0);
    }

    public static java.util.List getOTAUpdate(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress.getLzssCompressData(p2), "ff"));
        return v0_1;
    }

    public static com.jtkj.led1248.light.utils.CoolledUUtils$CoolleduOTADataResult getOtaDataResult()
    {
        com.jtkj.led1248.light.utils.CoolledUUtils$CoolleduOTADataResult v0_1 = new com.jtkj.led1248.light.utils.CoolledUUtils$CoolleduOTADataResult();
        java.util.List v1_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getOTAData(com.jtkj.led1248.CoolLED.getInstance());
        v0_1.beginDataForOTAUpgrade = com.jtkj.led1248.light.utils.CoolledUUtils.getStartDataForOtaUpgrade(v1_3);
        java.util.ArrayList v2_0 = new java.util.ArrayList();
        v2_0.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledUUtils$LzssCompress.getLzssCompressData(v1_3), "ff"));
        v0_1.dataForForOTAUpgrade = v2_0;
        return v0_1;
    }

    private static java.util.List getSendDataWithInfo(java.util.List p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("01");
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getDataStringLength(p3));
        v1_2.addAll(p3);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.convertData(v1_2, 0));
        v0_1.add("03");
        return v0_1;
    }

    public static java.util.List getSetBrightness(int p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("04");
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(p2));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetMirror(boolean p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0c");
        if (p2 == null) {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
        } else {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
        }
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetPasswordData(String p6)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0e");
        int v1_4 = new java.util.Random().nextInt(256);
        com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v1_4);
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v1_4));
        int v2_1 = 0;
        while (v2_1 < p6.length()) {
            String v3_6 = Integer.valueOf(new StringBuilder("0").append(p6.charAt(v2_1)).toString(), 16).intValue();
            com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v3_6);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt((v3_6 ^ v1_4)));
            v2_1++;
        }
        java.util.List v6_3 = Integer.valueOf("00", 16).intValue();
        int v1_1 = 2;
        while (v1_1 < v0_1.size()) {
            v6_3 ^= Integer.valueOf(((String) v0_1.get(v1_1)), 16).intValue();
            v1_1++;
        }
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(v6_3));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetRyhthmType(int p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("06");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForInt(p2));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartDataForOtaUpgrade(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("fe");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(p2));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartDataForProgram(java.util.List p2, int p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("1a");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(p2));
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForIntWithOneByte(p3));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartDataForProgram(java.util.List p2, int p3, int p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("02");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(p2));
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForIntWithOneByte(p3));
        v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForIntWithOneByte(p4));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartOTAUpdate(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("fe");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getHexListStringForIntWithFourByte(p2));
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSwitchData(boolean p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("05");
        if (p2 == null) {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(0));
        } else {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt(1));
        }
        return com.jtkj.led1248.light.utils.CoolledUUtils.getSendDataWithInfo(v0_1);
    }

    public static com.jtkj.led1248.light.utils.LightUtils$TextColorDataFor32Device getTextCustomColorDataForEmoji(com.jtkj.led1248.light.device.DeviceManager$CoolleduTextCustomColorProgramContent p0, com.jtkj.led1248.light.utils.FontUtils p1)
    {
        return p1.getFontByteCustomColorDataCoolleduForEmoji(p0);
    }

    public static com.jtkj.led1248.light.utils.LightUtils$TextData getTextDataForEmoji(com.jtkj.led1248.light.device.DeviceManager$CoolleduTextContentProgramContent p3, com.jtkj.led1248.light.utils.FontUtils p4)
    {
        com.jtkj.led1248.light.utils.LightUtils$TextData v0_1 = new com.jtkj.led1248.light.utils.LightUtils$TextData();
        String v1_5 = new java.util.ArrayList();
        try {
            v1_5.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.byte2hex(p4.getFontByteDataCoolleduForEmoji(p3).data));
            v0_1.data = v1_5;
            return v0_1;
        } catch (Exception v3_1) {
            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledUUtils.TAG, new StringBuilder("catch (Exception e) ").append(v3_1.getMessage()).toString());
            com.jtkj.led1248.CoolLED.reportError(v3_1);
            return v0_1;
        }
    }

    public static boolean isArab(String p1)
    {
        if (!p1.matches("[\\u0600-\\u06ff|\\u0750-\\u077f].*")) {
            return 0;
        } else {
            return 1;
        }
    }

    public static boolean isArbOrXbl(java.util.List p2)
    {
        int v2_1 = p2.iterator();
        while (v2_1.hasNext()) {
            boolean v0_4 = ((com.jtkj.led1248.light.emoji.TextEmojiManager$TextEmojiItem) v2_1.next());
            if ((v0_4.isText) && ((com.jtkj.led1248.light.utils.CoolledUUtils.isArab(v0_4.text)) || (com.jtkj.led1248.light.utils.CoolledUUtils.isXbl(v0_4.text)))) {
                return 1;
            }
        }
        return 0;
    }

    public static boolean isXbl(String p1)
    {
        if (!p1.matches("[\\u0590-\\u05ff].*")) {
            return 0;
        } else {
            return 1;
        }
    }

    public static byte[] readStream(java.io.InputStream p4)
    {
        java.io.ByteArrayOutputStream v0_1 = new java.io.ByteArrayOutputStream();
        byte[] v1_1 = new byte[1024];
        while(true) {
            int v2 = p4.read(v1_1);
            if (v2 == -1) {
                break;
            }
            v0_1.write(v1_1, 0, v2);
        }
        v0_1.close();
        p4.close();
        return v0_1.toByteArray();
    }

    public static java.util.List recoverData(java.util.List p7)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        int v2_0 = 0;
        int v3 = 1;
        int v5 = 2;
        if ((p7.size() > 2) && ((Integer.parseInt(((String) p7.get(0)), 16) == Integer.parseInt("01", 16)) && (Integer.parseInt(((String) p7.get((p7.size() - 1))), 16) == Integer.parseInt("03", 16)))) {
            v0_1 = p7.subList(v3, (p7.size() - v3));
        }
        java.util.ArrayList v7_2 = new java.util.ArrayList();
        while (v2_0 < v0_1.size()) {
            if (Integer.parseInt(((String) v0_1.get(v2_0)), 16) == Integer.parseInt("02", 16)) {
                String v1_16 = (v2_0 + 1);
                if (v1_16 < v0_1.size()) {
                    v7_2.add(com.jtkj.led1248.light.utils.CoolledUUtils.getHexStringForInt((Integer.valueOf(((String) v0_1.get(v1_16)), 16).intValue() ^ Integer.valueOf("04", 16).intValue())));
                    v2_0 = v1_16;
                }
            } else {
                v7_2.add(((String) v0_1.get(v2_0)));
            }
            v2_0++;
        }
        java.util.ArrayList v0_5 = new java.util.ArrayList();
        while (v5 < v7_2.size()) {
            v0_5.add(((String) v7_2.get(v5)));
            v5++;
        }
        return v0_5;
    }
}
