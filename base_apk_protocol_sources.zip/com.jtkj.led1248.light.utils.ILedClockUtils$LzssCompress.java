package com.jtkj.led1248.light.utils;
public class ILedClockUtils$LzssCompress {
    private static final int F = 18;
    private static final int N = 512;
    private static final int NIL = 512;
    private static final int THRESHOLD = 2;
    private static int codesize;
    private static int[] dad;
    private static byte[] enbuffer;
    private static int[] lson;
    private static int match_length;
    private static int match_position;
    private static int printcount;
    private static int[] rson;
    private static int textsize;

    static ILedClockUtils$LzssCompress()
    {
        int[] v0_1 = new byte[529];
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer = v0_1;
        int[] v1_0 = new int[513];
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson = v1_0;
        int[] v1_2 = new int[769];
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson = v1_2;
        int[] v0_3 = new int[513];
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad = v0_3;
        return;
    }

    public ILedClockUtils$LzssCompress()
    {
        return;
    }

    public static void DeleteNode(int p7)
    {
        if (com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad[p7] != 512) {
            int v0_11 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
            int[] v2_2 = v0_11[p7];
            if (v2_2 != 512) {
                int[] v3_0 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson[p7];
                if (v3_0 != 512) {
                    if (v0_11[v3_0] != 512) {
                        do {
                            int v0_3 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
                            v3_0 = v0_3[v3_0];
                        } while(v0_3[v3_0] != 512);
                        int[] v2_1 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad;
                        int[] v5_0 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson;
                        v0_3[v2_1[v3_0]] = v5_0[v3_0];
                        v2_1[v5_0[v3_0]] = v2_1[v3_0];
                        v5_0[v3_0] = v5_0[p7];
                        v2_1[v5_0[p7]] = v3_0;
                    }
                    v2_2 = v3_0;
                    int v0_7 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
                    v0_7[v2_2] = v0_7[p7];
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad[v0_7[p7]] = v2_2;
                }
            } else {
                v2_2 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson[p7];
            }
            int v0_10 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad;
            v0_10[v2_2] = v0_10[p7];
            int[] v3_4 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
            int v4_2 = v0_10[p7];
            if (v3_4[v4_2] != p7) {
                com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson[v4_2] = v2_2;
            } else {
                v3_4[v4_2] = v2_2;
            }
            v0_10[p7] = 512;
            return;
        } else {
            return;
        }
    }

    public static void InitTree()
    {
        int v0_0 = 513;
        while (v0_0 <= 768) {
            com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson[v0_0] = 512;
            v0_0++;
        }
        int v0_1 = 0;
        while (v0_1 < 512) {
            com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad[v0_1] = 512;
            v0_1++;
        }
        return;
    }

    public static void InsertNode(int p8)
    {
        int v0_2 = (com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress$$ExternalSyntheticBackport0.m(com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[p8]) + 513);
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson[p8] = 512;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson[p8] = 512;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length = 0;
        int[] v2_0 = 1;
        do {
            int v5_0;
            if (v2_0 < null) {
                int[] v4_0 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson;
                v5_0 = v4_0[v0_2];
                if (v5_0 == 512) {
                    v4_0[v0_2] = p8;
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad[p8] = v0_2;
                    return;
                }
            } else {
                int[] v4_1 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
                v5_0 = v4_1[v0_2];
                if (v5_0 == 512) {
                    v4_1[v0_2] = p8;
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad[p8] = v0_2;
                    return;
                }
            }
            v0_2 = v5_0;
            int[] v4_2 = 1;
            while (v4_2 < 18) {
                v2_0 = (com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress$$ExternalSyntheticBackport0.m(com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[(p8 + v4_2)]) - com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress$$ExternalSyntheticBackport0.m(com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[(v0_2 + v4_2)]));
                if (v2_0 != null) {
                    break;
                }
                v4_2++;
            }
        } while(v4_2 <= com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length);
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_position = v0_2;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length = v4_2;
        if (v4_2 < 18) {
        } else {
            int[] v1_5 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.dad;
            v1_5[p8] = v1_5[v0_2];
            int[] v2_5 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lson;
            v2_5[p8] = v2_5[v0_2];
            int[] v4_4 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.rson;
            v4_4[p8] = v4_4[v0_2];
            v1_5[v2_5[v0_2]] = p8;
            v1_5[v4_4[v0_2]] = p8;
            int v5_5 = v1_5[v0_2];
            if (v4_4[v5_5] != v0_2) {
                v2_5[v5_5] = p8;
            } else {
                v4_4[v5_5] = p8;
            }
            v1_5[v0_2] = 512;
            return;
        }
    }

    public static byte[] concat(byte[] p3, byte p4)
    {
        if (p3 != 0) {
            byte[] v2 = new byte[1];
            v2[0] = p4;
            byte[] v4_3 = java.util.Arrays.copyOf(p3, (p3.length + 1));
            System.arraycopy(v2, 0, v4_3, p3.length, 1);
            return v4_3;
        } else {
            int v3_1 = new byte[1];
            v3_1[0] = p4;
            return v3_1;
        }
    }

    public static java.util.List getLzssCompressData(java.util.List p1)
    {
        java.util.List v1_2 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.lazssCompress(com.jtkj.led1248.light.utils.LightUtils.fromListStringToByteArray(p1));
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.addAll(com.jtkj.led1248.light.utils.LightUtils.byte2hex(v1_2));
        return v0_1;
    }

    public static byte[] lazssCompress(byte[] p17)
    {
        byte v1_0 = 17;
        byte[] v2 = new byte[17];
        int v3 = p17.length;
        java.util.ArrayList v4_1 = new java.util.ArrayList();
        int v5_6 = 0;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.textsize = 0;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.codesize = 0;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.printcount = 0;
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.InitTree();
        v2[0] = 0;
        int v6_0 = 0;
        while(true) {
            int v7_1 = 494;
            if (v6_0 >= 494) {
                break;
            }
            com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[v6_0] = 0;
            v6_0++;
        }
        int v6_1 = 0;
        int v8 = 0;
        while ((v6_1 < 18) && (v8 < v3)) {
            com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[(494 + v6_1)] = p17[v8];
            v6_1++;
            v8++;
        }
        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.textsize = v6_1;
        if (v6_1 != 0) {
            int v11_0 = 1;
            while (v11_0 <= 18) {
                com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.InsertNode((494 - v11_0));
                v11_0++;
            }
            com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.InsertNode(494);
            int v12_1 = 0;
            int v9_4 = 1;
            int v11_2 = 1;
            do {
                if (com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length > v6_1) {
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length = v6_1;
                }
                int v13_4;
                int v16;
                int v13_2 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length;
                if (v13_2 > 2) {
                    int v14_2 = (v9_4 + 1);
                    byte[] v15_1 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_position;
                    v16 = v5_6;
                    v2[v9_4] = ((byte) (v15_1 & 255));
                    int v5_4 = (v9_4 + 2);
                    v2[v14_2] = ((byte) (((v15_1 >> 4) & 240) | (v13_2 - 3)));
                    v13_4 = v5_4;
                } else {
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length = 1;
                    v2[v5_6] = ((byte) (v2[v5_6] | v11_2));
                    v13_4 = (v9_4 + 1);
                    v2[v9_4] = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer[v7_1];
                    v16 = v5_6;
                }
                int v5_7 = ((byte) (v11_2 << 1));
                if ((v5_7 & 255) != 0) {
                    v11_2 = v5_7;
                    v9_4 = v13_4;
                } else {
                    int v5_1 = v16;
                    while (v5_1 < v13_4) {
                        v4_1.add(Byte.valueOf(v2[v5_1]));
                        v5_1++;
                    }
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.codesize = (com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.codesize + v13_4);
                    v2[v16] = v16;
                    v9_4 = 1;
                    v11_2 = 1;
                }
                int v5_10 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.match_length;
                int v13_0 = v16;
                while ((v13_0 < v5_10) && (v8 < v3)) {
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.DeleteNode(v12_1);
                    int v14_0 = p17[v8];
                    byte[] v15_0 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.enbuffer;
                    v15_0[v12_1] = v14_0;
                    if (v12_1 < v1_0) {
                        v15_0[(v12_1 + 512)] = v14_0;
                    }
                    v12_1 = ((v12_1 + 1) & 511);
                    v7_1 = ((v7_1 + 1) & 511);
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.InsertNode(v7_1);
                    v13_0++;
                    v8++;
                    v1_0 = 17;
                }
                byte v1_10 = (com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.textsize + v13_0);
                com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.textsize = v1_10;
                int v14_5 = com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.printcount;
                if (v1_10 > v14_5) {
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.printcount = (v14_5 + 1024);
                }
                while(true) {
                    byte v1_11 = (v13_0 + 1);
                    if (v13_0 >= v5_10) {
                        break;
                    }
                    com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.DeleteNode(v12_1);
                    v12_1 = ((v12_1 + 1) & 511);
                    v7_1 = ((v7_1 + 1) & 511);
                    v6_1--;
                    if (v6_1 > 0) {
                        com.jtkj.led1248.light.utils.ILedClockUtils$LzssCompress.InsertNode(v7_1);
                    }
                    v13_0 = v1_11;
                }
                if (v6_1 > 0) {
                    v5_6 = v16;
                    v1_0 = 17;
                } else {
                }
            } while(v9_4 <= 1);
            int v0_6 = new byte[v4_1.size()];
            int v5_0 = v16;
            while (v5_0 < v4_1.size()) {
                v0_6[v5_0] = ((byte) ((Byte) v4_1.get(v5_0)).intValue());
                v5_0++;
            }
            return v0_6;
        } else {
            return 0;
        }
    }
}
