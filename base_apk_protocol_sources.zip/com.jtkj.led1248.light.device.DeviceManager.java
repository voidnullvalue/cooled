package com.jtkj.led1248.light.device;
public class DeviceManager {
    private static final int BLE_MTU_MAX_SIZE = 247;
    private static final int BLE_MTU_MIN_SIZE = 23;
    private static final int BLE_OPERATION_INTERNAL = 1000;
    private static final int BLE_WRITE_CHAR_MAX_SIZE = 180;
    private static final int BLE_WRITE_CHAR_MIN_SIZE = 20;
    public static final String CONNECTED_DEVICE_INFO = "CONNECTED_DEVICE_INFO";
    public static final String CONNECT_SUCCESS_ADDRESS_KEY = "DeviceManager_CONNECT_SUCCESS_ADDRESS_KEY";
    public static final int COOLEDM_1632 = 15;
    public static final int COOLEDM_1664 = 16;
    public static final int COOLEDM_1696 = 17;
    public static final int COOLEDM_16X_COLUMN_LESS_THAN_AND_EQUAL_96 = 14;
    public static final int COOLEDM_16X_COLUMN_MORE_THAN_192 = 13;
    public static final int COOLEDM_16X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 12;
    public static final int COOLEDM_32X_COLUMN_LESS_THAN_AND_EQUAL_96 = 18;
    public static final int COOLEDM_32X_COLUMN_MORE_THAN_192 = 20;
    public static final int COOLEDM_32X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 19;
    public static final int COOLEDS_1632_PASSWORD = 10;
    public static final int COOLEDS_1664_PASSWORD = 9;
    public static final int COOLEDS_1696_PASSWORD = 8;
    public static final int COOLEDS_COLUMN_MORE_THAN64_PASSWORD = 11;
    public static final int COOLEDUD = 30;
    public static final int COOLEDUX_16X_COLUMN_LESS_AND_EQUAL_96 = 37;
    public static final int COOLEDUX_16X_COLUMN_MORE_THAN_192 = 39;
    public static final int COOLEDUX_16X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 38;
    public static final int COOLEDUX_20X_COLUMN_LESS_AND_EQUAL_256 = 48;
    public static final int COOLEDUX_20X_COLUMN_MORE_THAN_256 = 49;
    public static final int COOLEDUX_24X_COLUMN_LESS_AND_EQUAL_96 = 43;
    public static final int COOLEDUX_24X_COLUMN_MORE_THAN_192 = 45;
    public static final int COOLEDUX_24X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 44;
    public static final int COOLEDUX_32X_COLUMN_LESS_AND_EQUAL_96 = 40;
    public static final int COOLEDUX_32X_COLUMN_MORE_THAN_192 = 42;
    public static final int COOLEDUX_32X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 41;
    public static final int COOLEDU_16X_COLUMN_LESS_AND_EQUAL_96 = 21;
    public static final int COOLEDU_16X_COLUMN_MORE_THAN_192 = 23;
    public static final int COOLEDU_16X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 22;
    public static final int COOLEDU_20X_COLUMN_LESS_AND_EQUAL_256 = 46;
    public static final int COOLEDU_20X_COLUMN_MORE_THAN_256 = 47;
    public static final int COOLEDU_24X_COLUMN_LESS_AND_EQUAL_96 = 27;
    public static final int COOLEDU_24X_COLUMN_MORE_THAN_192 = 29;
    public static final int COOLEDU_24X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 28;
    public static final int COOLEDU_32X_COLUMN_LESS_AND_EQUAL_96 = 24;
    public static final int COOLEDU_32X_COLUMN_MORE_THAN_192 = 26;
    public static final int COOLEDU_32X_COLUMN_MORE_THAN_96_LESS_AND_EQUAL_192 = 25;
    public static final String COOLEDU_LOCAL_MIC_KEY = "COOLEDU_LOCAL_MIC_SUPPORTED_KEY";
    public static final int COOLEDX_1632 = 3;
    public static final int COOLEDX_1664 = 4;
    public static final int COOLEDX_1696 = 6;
    public static final int COOLEDX_COLUMN_MORE_THAN64 = 5;
    public static final int COOLED_1248 = 1;
    public static final int COOLED_536 = 2;
    public static final int COOLED_A = 7;
    public static final String COOL_LED = "CoolLED";
    public static final String COOL_LED_536 = "CoolLED536";
    public static final int COOL_LED_COLORFUL = 2;
    public static final int COOL_LED_COLORFUL_ILED_CLOCK = 4;
    public static final int COOL_LED_COLORFUL_UX = 3;
    public static int COOL_LED_DEVICE_COLOR_TYPE = 1;
    public static final String COOL_LED_DEVICE_TYPE_KEY = "COOL_LED_DEVICE_TYPE_KEY";
    public static final String COOL_LED_S = "CoolLEDS";
    public static final int COOL_LED_SEVEN = 1;
    public static final int COOL_LED_SINGLE = 0;
    public static final String COOL_LED_X = "CoolLEDX";
    public static final String Cool_LED_A = "CoolLEDA";
    public static final String Cool_LED_M = "CoolLEDM";
    public static final String Cool_LED_U = "CoolLEDU";
    public static final String Cool_LED_UD = "iLedBike";
    public static final String Cool_LED_UX = "CoolLEDUX";
    public static int CoolleduxDeviceVersion = 255;
    public static int CoolleduxLocalOTAVersion = 255;
    public static int CoolleduxRemoteOTAVersion = 255;
    public static String Coolledux_REMOTE_OTA_FILE_NAME = "";
    public static String Coolledux_REMOTE_OTA_FILE_URL = "";
    public static int DEVICE_COLUMN = 64;
    public static final String DEVICE_COLUMN_KEY = "DEVICE_COLUMN_KEY";
    public static String DEVICE_NAME = "";
    public static final String DEVICE_NAME_KEY = "DEVICE_NAME_KEY";
    public static final String DEVICE_PASSWORD_FOR = "DeviceManager_DEVICE_PASSWORD_FOR_>>>";
    public static int DEVICE_ROW = 16;
    public static final String DEVICE_ROW_KEY = "DEVICE_ROW_KEY";
    public static int DEVICE_TYPE = 255;
    public static final String DEVICE_TYPE_KEY = "DEVICE_TYPE_KEY";
    public static int DeviceVersion = 4;
    public static final String ILED_CLOCK = "iLedClock";
    public static final int ILedClock = 50;
    public static int ILedClockDeviceVersion = 255;
    public static int ILedClockLocalOTAVersion = 255;
    public static int ILedClockRemoteOTAVersion = 255;
    public static String ILedClock_REMOTE_OTA_FILE_NAME = "";
    public static String ILedClock_REMOTE_OTA_FILE_URL = "";
    private static final int INTERNAL_BETWEEN_TWO_PACKAGE = 15;
    public static final String IS_COOLLEDX_EXCEPT_1632_PASSWORD_ENABLE = "DeviceManager_IS_COOLLEDX_EXCEPT_1632_PASSWORD_ENABLE";
    public static final String LOCAL_MIC_KEY = "LOCAL_MIC_SUPPORTED_KEY";
    private static final int MAC_TIMES_TO_CHECK_PASSWORD = 3;
    private static final int MAX_RETRY_TIMES_FOR_ALL = 3;
    private static final int MAX_RETRY_TIMES_FOR_PACKAGE = 3;
    public static final int MAX_TIMES_TO_SET_BLE_NOTIFY = 3;
    private static final int MESSAGE_SEND_OVERTIME = 5000;
    private static final int MSG_CHECK_RESPONSE = 1001;
    private static final int MSG_SEND_MESSAGE = 1000;
    private static final int RESEND_DELAY_TIME = 1000;
    private static final int RETRY_FOR_SEND_COOLDEDX_DEVICE_DATA = 1002;
    private static final int RETRY_FOR_SEND_OTA = 1006;
    private static final int RETRY_FOR_SEND_PROGRAM = 1004;
    private static final int RETRY_FOR_START_SEND_OTA = 1005;
    private static final int RETRY_FOR_START_SEND_PROGRAM = 1003;
    public static final int SET_BLE_NOTIFY_AFTER_CONNECTED = 500;
    private static final String TAG = "DeviceManager";
    private static final String UUID_CHARACTER = "0000fff1-0000-1000-8000-00805f9b34fb";
    public static final String UUID_SERVICE = "0000fff0-0000-1000-8000-00805f9b34fb";
    public static final String iDevilEyes = "iDevilEyes";
    public static final String iLedCar = "iLedCar";
    public static final String iLedHat = "iLedHat";
    public static final String iLedHatC = "iLedHatC";
    public static final String iLedOpen = "iLedOpen";
    public static boolean isCoolleduxHardwareNeedForceUpgrade = False;
    public static boolean isCoolleduxHardwareUpdateSupported = False;
    public static boolean isILedCar = False;
    public static boolean isILedClockHardwareNeedForceUpgrade = False;
    public static boolean isILedClockHardwareUpdateSupported = False;
    public static boolean isLocalMicOnOff = False;
    public static boolean isLocalMicSupported = False;
    public static boolean isMirror = False;
    public static boolean isMusic = False;
    public static boolean isRemoteEnable = False;
    public static boolean isRemoteNoiseEnable = False;
    public static boolean isShowDeviceId = False;
    public static boolean isSwitchOnOff = True;
    public static int mBrightNess = 0;
    public static int mDriveState = 255;
    public static volatile com.jtkj.led1248.light.device.DeviceManager mInstance;
    public static int mRotate;
    private int CoolleduLocalOTAVersion;
    private int ILedClock_PACKAGE_SIZE;
    private int UX_PACKAGE_SIZE;
    private boolean isCoolleduHardwareNeedForceUpgrade;
    private boolean isExit;
    private boolean isMessageSuccess;
    boolean isMultiDevice;
    java.util.List mBleDeviceItems;
    private java.util.Map mBleDeviceMap;
    private int mCheckPasswordKind;
    private int mCheckPasswordTimes;
    private java.util.Map mChooseMultDeviceMap;
    private com.jtkj.led1248.light.device.DeviceManager$ConnectSuccessAddress mConnectSuccessAddress;
    private java.util.Map mConnectSuccessMap;
    com.jtkj.led1248.light.utils.CoolledMUtils$DataResult mCoolledmDataResult;
    int mCoolledmProgramCount;
    java.util.List mCoolledmProgramData;
    int mCoolledmProgramIndex;
    java.util.List mCoolledmProgramList;
    com.jtkj.led1248.light.utils.CoolledUUtils$DataResult mCoolleduDataResult;
    com.jtkj.led1248.light.utils.CoolledUUtils$CoolleduOTADataResult mCoolleduOTADataResult;
    java.util.List mCoolleduOTAUpgradeData;
    int mCoolleduProgramCount;
    java.util.List mCoolleduProgramData;
    int mCoolleduProgramIndex;
    java.util.List mCoolleduProgramList;
    com.jtkj.led1248.light.utils.CoolledUXUtils$DataResult mCoolleduxDataResult;
    com.jtkj.led1248.light.utils.CoolledUXUtils$CoolleduxOTADataResult mCoolleduxOTADataResult;
    java.util.List mCoolleduxOTAUpgradeData;
    int mCoolleduxProgramCount;
    java.util.List mCoolleduxProgramData;
    int mCoolleduxProgramIndex;
    java.util.List mCoolleduxProgramList;
    java.util.List mCoolledxTextIconData;
    private java.util.concurrent.BlockingQueue mDataStrings;
    private com.jtkj.library.fastble.data.BleDevice mDeviceCheckOrSetPassword;
    private java.util.Map mDeviceConnectTimeMap;
    private int mDeviceIndex;
    public String mDeviceInfo;
    int mDrivingState;
    int mGroupType;
    private com.jtkj.led1248.light.device.DeviceManager$DeviceHandler mHandler;
    com.jtkj.led1248.light.utils.ILedClockUtils$DataResult mILedClockDataResult;
    com.jtkj.led1248.light.utils.ILedClockUtils$ILedClockOTADataResult mILedClockOTADataResult;
    java.util.List mILedClockOTAUpgradeData;
    int mILedClockProgramCount;
    java.util.List mILedClockProgramData;
    int mILedClockProgramIndex;
    java.util.List mILedClockProgramList;
    private int mMaxRetryTimesForAll;
    private int mMaxRetryTimesForPackage;
    private String mPasswordToCheck;
    private String mPasswordToSet;
    private java.util.Map mSendDataEnableMap;
    private int mSendIndex;
    int mSetBleNotifyTimes;
    private java.util.Map mUxDeviceVersionMap;
    private java.util.Map mUxPackageSizeMap;
    private java.util.Map mVerifyPasswordMap;
    private boolean sendNextWhenLastSuccess;

    static bridge synthetic com.jtkj.led1248.light.device.DeviceManager$DeviceHandler -$$Nest$fgetmHandler(com.jtkj.led1248.light.device.DeviceManager p0)
    {
        return p0.mHandler;
    }

    static bridge synthetic void -$$Nest$fputmCheckPasswordTimes(com.jtkj.led1248.light.device.DeviceManager p0, int p1)
    {
        p0.mCheckPasswordTimes = p1;
        return;
    }

    static bridge synthetic void -$$Nest$mcheckPassWordAfterConnectSuccess(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1)
    {
        p0.checkPassWordAfterConnectSuccess(p1);
        return;
    }

    static bridge synthetic void -$$Nest$mdeleteDeviceDisconnectOrConnectFailure(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1)
    {
        p0.deleteDeviceDisconnectOrConnectFailure(p1);
        return;
    }

    static bridge synthetic void -$$Nest$mgetDeviceInfo(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1)
    {
        p0.getDeviceInfo(p1);
        return;
    }

    static bridge synthetic void -$$Nest$mprocessMessage(com.jtkj.led1248.light.device.DeviceManager p0, android.os.Message p1)
    {
        p0.processMessage(p1);
        return;
    }

    static bridge synthetic void -$$Nest$msaveDeviceConnectSuccess(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1)
    {
        p0.saveDeviceConnectSuccess(p1);
        return;
    }

    static bridge synthetic void -$$Nest$msetBleResponse(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1, String p2, String p3)
    {
        p0.setBleResponse(p1, p2, p3);
        return;
    }

    static bridge synthetic void -$$Nest$msetMtu(com.jtkj.led1248.light.device.DeviceManager p0, com.jtkj.library.fastble.data.BleDevice p1)
    {
        p0.setMtu(p1);
        return;
    }

    static bridge synthetic String -$$Nest$sfgetTAG()
    {
        return com.jtkj.led1248.light.device.DeviceManager.TAG;
    }

    static DeviceManager()
    {
        return;
    }

    public DeviceManager()
    {
        this.sendNextWhenLastSuccess = 0;
        this.CoolleduLocalOTAVersion = 4;
        this.isCoolleduHardwareNeedForceUpgrade = 0;
        this.UX_PACKAGE_SIZE = 1024;
        this.mUxPackageSizeMap = new java.util.HashMap();
        this.mUxDeviceVersionMap = new java.util.HashMap();
        this.ILedClock_PACKAGE_SIZE = 1024;
        this.isExit = 0;
        this.mMaxRetryTimesForPackage = 3;
        this.mMaxRetryTimesForAll = 3;
        this.mSendIndex = 0;
        this.isMessageSuccess = 0;
        this.mDeviceIndex = 0;
        this.mSetBleNotifyTimes = 0;
        this.mHandler = new com.jtkj.led1248.light.device.DeviceManager$DeviceHandler(this);
        this.mDataStrings = new java.util.concurrent.LinkedBlockingQueue();
        this.mBleDeviceMap = new java.util.HashMap();
        this.mSendDataEnableMap = new java.util.HashMap();
        this.mConnectSuccessMap = new java.util.HashMap();
        this.mVerifyPasswordMap = new java.util.HashMap();
        this.mDeviceConnectTimeMap = new java.util.HashMap();
        this.mCheckPasswordTimes = 0;
        this.mChooseMultDeviceMap = new java.util.HashMap();
        this.isMultiDevice = 0;
        this.mCoolleduOTAUpgradeData = new java.util.ArrayList();
        this.mILedClockOTAUpgradeData = new java.util.ArrayList();
        this.mCoolleduxOTAUpgradeData = new java.util.ArrayList();
        this.mCoolleduProgramData = new java.util.ArrayList();
        this.mCoolleduxProgramData = new java.util.ArrayList();
        this.mILedClockProgramData = new java.util.ArrayList();
        this.mCoolledmProgramData = new java.util.ArrayList();
        this.mCoolledxTextIconData = new java.util.ArrayList();
        this.init();
        return;
    }

    private void checkCoolLEDMMessages(java.util.List p18)
    {
        int v2_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkCoolLEDMMessages>>>").append(p18.toString()).toString());
        if (p18.size() != 5) {
            if (p18.size() != 2) {
                if (p18.size() == 7) {
                    com.jtkj.library.commom.logger.CLog.i(v2_2, "getCoollEDMDeviceInfo");
                    if (Integer.parseInt(((String) p18.get(0)), 16) == Integer.parseInt("1f", 16)) {
                        StringBuilder v3_81 = Integer.parseInt(((String) p18.get(1)), 16);
                        com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p18.get(2)), 16);
                        String v5_19 = Integer.parseInt(((String) p18.get(3)), 16);
                        int v6_5 = Integer.parseInt(((String) p18.get(4)), 16);
                        String v4_36 = Integer.parseInt(((String) p18.get(5)), 16);
                        Integer.parseInt(((String) p18.get(6)), 16);
                        if (v3_81 != null) {
                            if (v3_81 == 1) {
                                com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                        }
                        if (v5_19 != null) {
                            if (v5_19 == 1) {
                                com.jtkj.led1248.light.device.DeviceManager.isMirror = 1;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isMirror = 0;
                        }
                        if (v6_5 != 0) {
                            if (v6_5 == 1) {
                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = 1;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = 0;
                        }
                        com.jtkj.led1248.CoolLED.getInstance().savePreference("LOCAL_MIC_SUPPORTED_KEY", Boolean.valueOf(com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported));
                        if (v4_36 != null) {
                            if (v4_36 == 1) {
                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = 1;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = 0;
                        }
                        String v1_3 = new com.jtkj.led1248.light.device.DeviceManager$DeviceCoolLEDMInfo();
                        v1_3.isSwitchOnOff = com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff;
                        v1_3.isMirror = com.jtkj.led1248.light.device.DeviceManager.isMirror;
                        v1_3.brightNess = com.jtkj.led1248.light.device.DeviceManager.mBrightNess;
                        v1_3.isLocalMicSupported = com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported;
                        v1_3.isLocalMicOnOff = com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff;
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDMDeviceInfoEvent(v1_3));
                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("getCoolLEDMDeviceInfo>>>").append(v1_3.toString()).toString());
                    }
                }
            } else {
                if (Integer.parseInt(((String) p18.get(0)), 16) != Integer.parseInt("02", 16)) {
                    if (Integer.parseInt(((String) p18.get(0)), 16) != Integer.parseInt("0d", 16)) {
                        if (Integer.parseInt(((String) p18.get(0)), 16) != Integer.parseInt("0e", 16)) {
                            if (Integer.parseInt(((String) p18.get(0)), 16) != Integer.parseInt("04", 16)) {
                                if (Integer.parseInt(((String) p18.get(0)), 16) != Integer.parseInt("0c", 16)) {
                                    if (Integer.parseInt(((String) p18.get(0)), 16) == Integer.parseInt("05", 16)) {
                                        String v1_9 = Integer.parseInt(((String) p18.get(1)), 16);
                                        if (v1_9 != null) {
                                            if (v1_9 == 1) {
                                                com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                                            }
                                        } else {
                                            com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                                        }
                                        String v1_11 = new com.jtkj.led1248.light.device.DeviceManager$DeviceCoolLEDMInfo();
                                        v1_11.isSwitchOnOff = com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff;
                                        v1_11.isMirror = com.jtkj.led1248.light.device.DeviceManager.isMirror;
                                        v1_11.brightNess = com.jtkj.led1248.light.device.DeviceManager.mBrightNess;
                                        v1_11.isLocalMicSupported = com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported;
                                        v1_11.isLocalMicOnOff = com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff;
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDMDeviceInfoEvent(v1_11));
                                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("getCoolLEDMDeviceInfo>>>").append(v1_11.toString()).toString());
                                        return;
                                    }
                                } else {
                                    String v1_17 = Integer.parseInt(((String) p18.get(1)), 16);
                                    if (v1_17 != null) {
                                        if (v1_17 == 1) {
                                            com.jtkj.led1248.light.device.DeviceManager.isMirror = 1;
                                        }
                                    } else {
                                        com.jtkj.led1248.light.device.DeviceManager.isMirror = 0;
                                    }
                                    com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("isMirror>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMirror).toString());
                                    return;
                                }
                            } else {
                                com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p18.get(1)), 16);
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("mBrightNess>>>").append(com.jtkj.led1248.light.device.DeviceManager.mBrightNess).toString());
                                return;
                            }
                        } else {
                            if (Integer.parseInt(((String) p18.get(1)), 16) != 0) {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>SetPasswordCoollEDM>>failure>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(0, this.mDeviceCheckOrSetPassword));
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>SetPasswordCoollEDM>>success>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToSet);
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(1, this.mDeviceCheckOrSetPassword));
                                return;
                            }
                        }
                    } else {
                        if (Integer.parseInt(((String) p18.get(1)), 16) != 0) {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_FAILURE_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>CheckPasswordCoollEDM>>failure>>>password>>>").append(this.mPasswordToCheck).toString());
                            String v1_64 = this.mCheckPasswordKind;
                            if (v1_64 != 2) {
                                if (v1_64 == 1) {
                                    String v1_65 = this.mCheckPasswordTimes;
                                    if (v1_65 < 3) {
                                        this.mCheckPasswordTimes = (v1_65 + 1);
                                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                        this.checkPassWordAfterConnectSuccess(this.mDeviceCheckOrSetPassword);
                                        return;
                                    } else {
                                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                        return;
                                    }
                                }
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "checkPassword>>>CHECK_PASSWORD_AFTER_INPUT_PASSWORD>>>");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                return;
                            }
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_SUCCESS_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("checkPassword>>>CheckPasswordCoollEDM>>success>>>password>>>").append(this.mPasswordToCheck).toString());
                            this.mVerifyPasswordMap.put(this.mDeviceCheckOrSetPassword.getMac(), Boolean.valueOf(1));
                            com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToCheck);
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 5));
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 1, this.mDeviceCheckOrSetPassword));
                            this.updateDeviceInfo(void v0_0.mDeviceCheckOrSetPassword);
                            return;
                        }
                    }
                } else {
                    String v1_106 = Integer.parseInt(((String) p18.get(1)), 16);
                    if (v1_106 != null) {
                        if (v1_106 != 1) {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("results.size() == 2>>>response ==").append(v1_106).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("response == 1>>>sendCoolledmProgramData>>>(response == 1 no need send from package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(this.mCoolledmProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                            if (this.mCoolledmProgramIndex != (this.mCoolledmProgramCount - 1)) {
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolledmProgramData.size(), this.mCoolledmProgramData.size())));
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "mCoolledmProgramIndex /= (mCoolledmProgramCount - 1)>>>sendNextProgramData");
                                this.mMaxRetryTimesForPackage = 3;
                                this.mMaxRetryTimesForAll = 3;
                                void v0_1 = this.clearAllMessages();
                                v0_1.mSendIndex = 0;
                                v0_1.mCoolledmProgramIndex = (v0_1.mCoolledmProgramIndex + 1);
                                v0_1.isMessageSuccess = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("sendingData from next program>>>SendIndex>>>").append(v0_1.mSendIndex).append(">>>mDeviceIndex>>>").append(v0_1.mDeviceIndex).append(">>>mSendDataEnableMap.size()>>>").append(v0_1.mSendDataEnableMap.size()).toString());
                                v0_1.sendCoolledmStartSendProgramData(v0_1.mCoolledmProgramList, v0_1.mCoolledmProgramIndex, v0_1.mCoolledmProgramCount);
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "send start send program success to the last program mCoolledmProgramIndex == (mCoolledmProgramCount - 1)(response == 1)");
                                if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                    com.jtkj.library.commom.logger.CLog.i(v2_2, "send to not the last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))>>>(response == 1)");
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolledmProgramData.size(), this.mCoolledmProgramData.size())));
                                    this.mMaxRetryTimesForPackage = 3;
                                    this.mMaxRetryTimesForAll = 3;
                                    void v0_2 = this.clearAllMessages();
                                    v0_2.mDeviceIndex = (v0_2.mDeviceIndex + 1);
                                    v0_2.mCoolledmProgramIndex = 0;
                                    v0_2.mSendIndex = 0;
                                    v0_2.isMessageSuccess = 0;
                                    com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("sendingData to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_2.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(v0_2.mCoolledmProgramIndex).append(">>> mDeviceIndex>>").append(v0_2.mDeviceIndex).toString());
                                    v0_2.sendCoolledmStartSendProgramData(v0_2.mCoolledmProgramList, v0_2.mCoolledmProgramIndex, v0_2.mCoolledmProgramCount);
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v2_2, "send  to the last device success (mDeviceIndex == (mSendDataEnableMap.size() - 1))(response == 1)");
                                    void v0_3 = this.clearAllMessages();
                                    v0_3.isMessageSuccess = 1;
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((v0_3.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(v0_3.mCoolledmProgramData.size(), v0_3.mCoolledmProgramData.size())));
                                    v0_3.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$21(v0_3), 1000);
                                    return;
                                }
                            }
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("response == 0>>>send startProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(this.mCoolledmProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        void v0_4 = this.clearAllMessages();
                        v0_4.sendCoolledmProgramData(v0_4.mSendIndex).mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            }
        } else {
            if (Integer.parseInt(((String) p18.get(0)), 16) == Integer.parseInt("03", 16)) {
                StringBuilder v3_121 = Integer.parseInt(((String) p18.get(4)), 16);
                this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p18.get(2))).append(((String) p18.get(3))).toString(), 16);
                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("response>>>").append(v3_121).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                if (v3_121 != null) {
                    if (v3_121 != 1) {
                        if (v3_121 != 2) {
                            if (v3_121 != 3) {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("response ==").append(v3_121).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "response == 3>>>DATA_ERROR");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                return;
                            }
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, "response == 2>>>DEVICE_ERROR");
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                            return;
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_2, "response == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForCoolLEDM>>>1");
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                        return;
                    }
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolledmProgramData.size()>>>").append(this.mCoolledmProgramData.size()).append(">>>mCoolledmProgramIndex>>>").append(this.mCoolledmProgramIndex).append(">>>mCoolledmProgramCount>>>").append(this.mCoolledmProgramCount).toString());
                    if (this.mSendIndex != (this.mCoolledmProgramData.size() - 1)) {
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolledmProgramData.size())));
                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(this.mCoolledmProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        void v0_6 = this.clearAllMessages();
                        String v1_214 = (v0_6.mSendIndex + 1);
                        v0_6.mSendIndex = v1_214;
                        v0_6.sendCoolledmProgramData(v1_214).mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("send data to the last package success>>>(mSendIndex == (mCoolledmProgramData.size() - 1))>>").append((this.mCoolledmProgramData.size() - 1)).toString());
                        if (this.mCoolledmProgramIndex != (this.mCoolledmProgramCount - 1)) {
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolledmProgramData.size(), this.mCoolledmProgramData.size())));
                            com.jtkj.library.commom.logger.CLog.i(v2_2, "send data to  not  the last program (mCoolledmProgramIndex /= (mCoolledmProgramCount - 1)))");
                            this.mMaxRetryTimesForPackage = 3;
                            this.mMaxRetryTimesForAll = 3;
                            void v0_8 = this.clearAllMessages();
                            v0_8.mCoolledmProgramIndex = (v0_8.mCoolledmProgramIndex + 1);
                            v0_8.mSendIndex = 0;
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("sendingData to the next program from 0package>>>mSendIndex>>> ").append(v0_8.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(v0_8.mCoolledmProgramIndex).append(">>> mDeviceIndex>>").append(v0_8.mDeviceIndex).toString());
                            v0_8.sendCoolledmStartSendProgramData(v0_8.mCoolledmProgramList, v0_8.mCoolledmProgramIndex, v0_8.mCoolledmProgramCount);
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("send last package to the last program (mCoolledmProgramIndex == (mCoolledmProgramCount - 1)>>>mCoolledmProgramIndex>>>").append(this.mCoolledmProgramIndex).append(">>>mCoolledmProgramCount>>>").append(this.mCoolledmProgramCount).toString());
                            com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>deviceSize>>>").append(this.mSendDataEnableMap.size()).toString());
                            if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolledmProgramData.size(), this.mCoolledmProgramData.size())));
                                this.isMessageSuccess = 1;
                                this.mMaxRetryTimesForPackage = 3;
                                this.mMaxRetryTimesForAll = 3;
                                void v0_9 = this.clearAllMessages();
                                v0_9.mDeviceIndex = (v0_9.mDeviceIndex + 1);
                                v0_9.mCoolledmProgramIndex = 0;
                                v0_9.mSendIndex = 0;
                                v0_9.isMessageSuccess = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_2, new StringBuilder("send data to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_9.mSendIndex).append(">>>mCoolledmProgramIndex>>>").append(v0_9.mCoolledmProgramIndex).append(">>> mDeviceIndex>>").append(v0_9.mDeviceIndex).toString());
                                v0_9.sendCoolledmStartSendProgramData(v0_9.mCoolledmProgramList, v0_9.mCoolledmProgramIndex, v0_9.mCoolledmProgramCount);
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_2, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolledmProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolledmProgramData.size(), this.mCoolledmProgramData.size())));
                                void v0_10 = this.clearAllMessages();
                                v0_10.isMessageSuccess = 1;
                                v0_10.mDeviceIndex = 0;
                                v0_10.mCoolledmProgramIndex = 0;
                                v0_10.mSendIndex = 0;
                                v0_10.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$20(v0_10), 1000);
                                return;
                            }
                        }
                    }
                }
            }
        }
        return;
    }

    private void checkCoolLEDUMessages(java.util.List p20)
    {
        void v0_0 = this;
        java.util.List v2_17 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkCoolLEDUMessages>>>").append(p20.toString()).toString());
        if (p20.size() != 5) {
            if (p20.size() != 2) {
                if (p20.size() == 7) {
                    com.jtkj.library.commom.logger.CLog.i(v2_17, "getCoolLEDUDeviceInfo");
                    if (Integer.parseInt(((String) p20.get(0)), 16) == Integer.parseInt("1f", 16)) {
                        int v16_1;
                        com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_300;
                        String v3_131 = Integer.parseInt(((String) p20.get(1)), 16);
                        com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p20.get(2)), 16);
                        String v4_83 = Integer.parseInt(((String) p20.get(3)), 16);
                        String v5_27 = Integer.parseInt(((String) p20.get(4)), 16);
                        int v6_17 = Integer.parseInt(((String) p20.get(5)), 16);
                        Integer.parseInt(((String) p20.get(6)), 16);
                        if (v3_131 != null) {
                            v1_300 = 1;
                            v16_1 = 0;
                            if (v3_131 == 1) {
                                com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                            }
                        } else {
                            v16_1 = 0;
                            com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                            v1_300 = 1;
                        }
                        if (v4_83 != null) {
                            if (v4_83 == v1_300) {
                                com.jtkj.led1248.light.device.DeviceManager.isMirror = v1_300;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isMirror = v16_1;
                        }
                        if (v5_27 != null) {
                            if (v5_27 == v1_300) {
                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = v1_300;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = v16_1;
                        }
                        com.jtkj.led1248.CoolLED.getInstance().savePreference("COOLEDU_LOCAL_MIC_SUPPORTED_KEY", Boolean.valueOf(com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported));
                        if (v6_17 != 0) {
                            if (v6_17 == v1_300) {
                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = v1_300;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = 0;
                        }
                        com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_18 = new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUDeviceInfo();
                        v1_18.isSwitchOnOff = com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff;
                        v1_18.isMirror = com.jtkj.led1248.light.device.DeviceManager.isMirror;
                        v1_18.brightNess = com.jtkj.led1248.light.device.DeviceManager.mBrightNess;
                        v1_18.isLocalMicSupported = com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported;
                        v1_18.isLocalMicOnOff = com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff;
                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("getCoolLEDUDeviceInfo>>>").append(v1_18).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUDeviceInfoEvent(v1_18));
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent(com.jtkj.led1248.light.utils.CoolledUDUtils.getDriveState()));
                    }
                }
            } else {
                if ((Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("02", 16)) && (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("1a", 16))) {
                    if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("fe", 16)) {
                        if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("0d", 16)) {
                            if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("0e", 16)) {
                                if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("04", 16)) {
                                    if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("0c", 16)) {
                                        if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("05", 16)) {
                                            if ((Integer.parseInt(((String) p20.get(0)), 16) == Integer.parseInt("1e", 16)) || (Integer.parseInt(((String) p20.get(0)), 16) == Integer.parseInt("1c", 16))) {
                                                com.jtkj.led1248.light.device.DeviceManager.mDriveState = Integer.parseInt(((String) p20.get(1)), 16);
                                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("getCoolLEDUdeviceInfo>>>driveSate>>>").append(com.jtkj.led1248.light.device.DeviceManager.mDriveState).toString());
                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$DriveStateResponseEvent(com.jtkj.led1248.light.device.DeviceManager.mDriveState));
                                                return;
                                            }
                                        } else {
                                            com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_133 = Integer.parseInt(((String) p20.get(1)), 16);
                                            if (v1_133 != null) {
                                                if (v1_133 == 1) {
                                                    com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                                                }
                                            } else {
                                                com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                                            }
                                            com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_135 = new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUDeviceInfo();
                                            v1_135.isSwitchOnOff = com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff;
                                            v1_135.isMirror = com.jtkj.led1248.light.device.DeviceManager.isMirror;
                                            v1_135.brightNess = com.jtkj.led1248.light.device.DeviceManager.mBrightNess;
                                            v1_135.isLocalMicSupported = com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported;
                                            v1_135.isLocalMicOnOff = com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff;
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUDeviceInfoEvent(v1_135));
                                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("getCoolLEDUdeviceInfo>>>").append(v1_135.toString()).toString());
                                            return;
                                        }
                                    } else {
                                        com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_141 = Integer.parseInt(((String) p20.get(1)), 16);
                                        if (v1_141 != null) {
                                            if (v1_141 == 1) {
                                                com.jtkj.led1248.light.device.DeviceManager.isMirror = 1;
                                            }
                                        } else {
                                            com.jtkj.led1248.light.device.DeviceManager.isMirror = 0;
                                        }
                                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("isMirror>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMirror).toString());
                                        return;
                                    }
                                } else {
                                    com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p20.get(1)), 16);
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("mBrightNess>>>").append(com.jtkj.led1248.light.device.DeviceManager.mBrightNess).toString());
                                    return;
                                }
                            } else {
                                if (Integer.parseInt(((String) p20.get(1)), 16) != 0) {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>SetCoolLEDUDevicePassword>>failure>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(0, this.mDeviceCheckOrSetPassword));
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>SetCoolLEDUDevicePassword>>success>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                    com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToSet);
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(1, this.mDeviceCheckOrSetPassword));
                                    return;
                                }
                            }
                        } else {
                            if (Integer.parseInt(((String) p20.get(1)), 16) != 0) {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_FAILURE_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>CheckCoolLEDUDevicePassword>>failure>>>password>>>").append(this.mPasswordToCheck).toString());
                                com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_188 = this.mCheckPasswordKind;
                                if (v1_188 != 2) {
                                    if (v1_188 == 1) {
                                        com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_189 = this.mCheckPasswordTimes;
                                        if (v1_189 < 3) {
                                            this.mCheckPasswordTimes = (v1_189 + 1);
                                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                            this.checkPassWordAfterConnectSuccess(this.mDeviceCheckOrSetPassword);
                                            return;
                                        } else {
                                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                            return;
                                        }
                                    }
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, "checkPassword>>>CHECK_PASSWORD_AFTER_INPUT_PASSWORD>>");
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                    return;
                                }
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_SUCCESS_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("checkPassword>>>CheckCoolLEDUDevicePassword>>success>>>password>>>").append(this.mPasswordToCheck).toString());
                                this.mVerifyPasswordMap.put(this.mDeviceCheckOrSetPassword.getMac(), Boolean.valueOf(1));
                                com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToCheck);
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 5));
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 1, this.mDeviceCheckOrSetPassword));
                                v0_0.updateDeviceInfo(v0_0.mDeviceCheckOrSetPassword);
                                return;
                            }
                        }
                    } else {
                        if (Integer.parseInt(((String) p20.get(1)), 16) != 0) {
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("response == 0>>>send startCoolleduProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                            this.mMaxRetryTimesForPackage = 3;
                            this.mMaxRetryTimesForAll = 3;
                            void v0_8 = this.clearAllMessages();
                            v0_8.sendCooleduOtaUpgradeData(v0_8.mSendIndex).mHandler.sendEmptyMessageDelayed(1005, 5000);
                            return;
                        }
                    }
                } else {
                    com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_243 = Integer.parseInt(((String) p20.get(1)), 16);
                    if (v1_243 != null) {
                        if (v1_243 != 1) {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("results.size() == 2>>>response ==").append(v1_243).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("response == 1>>>sendCoolleduProgramData>>>(response == 1 no need send from package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(this.mCoolleduProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                            if (this.mCoolleduProgramIndex != (this.mCoolleduProgramCount - 1)) {
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduProgramData.size(), this.mCoolleduProgramData.size())));
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "mCoolleduProgramIndex /= (mCoolleduProgramCount - 1)>>>sendNextProgramData");
                                this.mMaxRetryTimesForPackage = 3;
                                this.mMaxRetryTimesForAll = 3;
                                void v0_10 = this.clearAllMessages();
                                v0_10.mSendIndex = 0;
                                v0_10.mCoolleduProgramIndex = (v0_10.mCoolleduProgramIndex + 1);
                                v0_10.isMessageSuccess = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("sendingData from next program>>>SendIndex>>>").append(v0_10.mSendIndex).append(">>>mDeviceIndex>>>").append(v0_10.mDeviceIndex).append(">>>mSendDataEnableMap.size()>>>").append(v0_10.mSendDataEnableMap.size()).toString());
                                v0_10.sendCoolleduStartSendProgramData(v0_10.mCoolleduProgramList, v0_10.mCoolleduProgramIndex, v0_10.mCoolleduProgramCount);
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "send Coolledu start send program success to the last program mCoolleduProgramIndex == (mCoolleduProgramCount - 1)(response == 1)");
                                if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, "send to not the last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))>>>(response == 1)");
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduProgramData.size(), this.mCoolleduProgramData.size())));
                                    this.mMaxRetryTimesForPackage = 3;
                                    this.mMaxRetryTimesForAll = 3;
                                    void v0_11 = this.clearAllMessages();
                                    v0_11.mDeviceIndex = (v0_11.mDeviceIndex + 1);
                                    v0_11.mCoolleduProgramIndex = 0;
                                    v0_11.mSendIndex = 0;
                                    v0_11.isMessageSuccess = 0;
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("sendingData to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_11.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(v0_11.mCoolleduProgramIndex).append(">>> mDeviceIndex>>").append(v0_11.mDeviceIndex).toString());
                                    v0_11.sendCoolleduStartSendProgramData(v0_11.mCoolleduProgramList, v0_11.mCoolleduProgramIndex, v0_11.mCoolleduProgramCount);
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, "send  to the last device success (mDeviceIndex == (mSendDataEnableMap.size() - 1))(response == 1)");
                                    void v0_12 = this.clearAllMessages();
                                    v0_12.isMessageSuccess = 1;
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((v0_12.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(v0_12.mCoolleduProgramData.size(), v0_12.mCoolleduProgramData.size())));
                                    v0_12.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$11(v0_12), 1000);
                                    return;
                                }
                            }
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("response == 0>>>send startCoolleduProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(this.mCoolleduProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        void v0_13 = this.clearAllMessages();
                        v0_13.sendCooleduProgramData(v0_13.mSendIndex).mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            }
        } else {
            if (Integer.parseInt(((String) p20.get(0)), 16) != Integer.parseInt("03", 16)) {
                if (Integer.parseInt(((String) p20.get(0)), 16) == Integer.parseInt("ff", 16)) {
                    String v3_197 = Integer.parseInt(((String) p20.get(4)), 16);
                    this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p20.get(2))).append(((String) p20.get(3))).toString(), 16);
                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("OTAresponse>>>").append(v3_197).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                    if (v3_197 != null) {
                        if (v3_197 != 1) {
                            if (v3_197 != 2) {
                                if (v3_197 != 3) {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("OTAresponse ==").append(v3_197).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v2_17, "OTAresponse == 3>>>DATA_ERROR");
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                    return;
                                }
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "OTAresponse == 2>>>DEVICE_ERROR");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                                return;
                            }
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, "OTAresponse == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForCoolLEDU>>>1");
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                            return;
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduOTAUpgradeData.size()>>>").append(this.mCoolleduOTAUpgradeData.size()).toString());
                        if (this.mSendIndex != (this.mCoolleduOTAUpgradeData.size() - 1)) {
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolleduOTAUpgradeData.size())));
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                            this.mMaxRetryTimesForPackage = 3;
                            this.mMaxRetryTimesForAll = 3;
                            void v0_15 = this.clearAllMessages();
                            com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_346 = (v0_15.mSendIndex + 1);
                            v0_15.mSendIndex = v1_346;
                            v0_15.sendCooleduOtaUpgradeData(v1_346).mHandler.sendEmptyMessageDelayed(1006, 5000);
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("send data to the last package success>>>(mSendIndex == (mCoolleduOTAUpgradeData.size() - 1))>>").append((this.mCoolleduOTAUpgradeData.size() - 1)).toString());
                            if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduOTAUpgradeData.size(), this.mCoolleduOTAUpgradeData.size())));
                                this.isMessageSuccess = 1;
                                this.mMaxRetryTimesForPackage = 3;
                                this.mMaxRetryTimesForAll = 3;
                                void v0_1 = this.clearAllMessages();
                                v0_1.mDeviceIndex = (v0_1.mDeviceIndex + 1);
                                v0_1.mSendIndex = 0;
                                v0_1.isMessageSuccess = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("send data to the next device from 0 package>>>mSendIndex>>> ").append(v0_1.mSendIndex).append(">>> mDeviceIndex>>").append(v0_1.mDeviceIndex).toString());
                                v0_1.sendCoolleduStartSendOTAUpgradeData();
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduOTAUpgradeData.size(), this.mCoolleduOTAUpgradeData.size())));
                                void v0_2 = this.clearAllMessages();
                                v0_2.isMessageSuccess = 1;
                                v0_2.mDeviceIndex = 0;
                                v0_2.mSendIndex = 0;
                                v0_2.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$10(v0_2), 1000);
                                return;
                            }
                        }
                    }
                }
            } else {
                String v3_12 = Integer.parseInt(((String) p20.get(4)), 16);
                this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p20.get(2))).append(((String) p20.get(3))).toString(), 16);
                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("response>>>").append(v3_12).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                if (v3_12 != null) {
                    if (v3_12 != 1) {
                        if (v3_12 != 2) {
                            if (v3_12 != 3) {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("response ==").append(v3_12).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "response == 3>>>DATA_ERROR");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                return;
                            }
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, "response == 2>>>DEVICE_ERROR");
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                            return;
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_17, "response == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForCoolLEDU>>>1");
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                        return;
                    }
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduProgramData.size()>>>").append(this.mCoolleduProgramData.size()).append(">>>mCoolleduProgramIndex>>>").append(this.mCoolleduProgramIndex).append(">>>mCoolleduProgramCount>>>").append(this.mCoolleduProgramCount).toString());
                    if (this.mSendIndex != (this.mCoolleduProgramData.size() - 1)) {
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolleduProgramData.size())));
                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(this.mCoolleduProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        void v0_3 = this.clearAllMessages();
                        com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent v1_64 = (v0_3.mSendIndex + 1);
                        v0_3.mSendIndex = v1_64;
                        v0_3.sendCooleduProgramData(v1_64).mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("send data to the last package success>>>(mSendIndex == (mCoolleduProgramData.size() - 1))>>").append((this.mCoolleduProgramData.size() - 1)).toString());
                        if (this.mCoolleduProgramIndex != (this.mCoolleduProgramCount - 1)) {
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduProgramData.size(), this.mCoolleduProgramData.size())));
                            com.jtkj.library.commom.logger.CLog.i(v2_17, "send data to  not  the last program (mCoolleduProgramIndex /= (mCoolleduProgramCount - 1)))");
                            this.mMaxRetryTimesForPackage = 3;
                            this.mMaxRetryTimesForAll = 3;
                            void v0_5 = this.clearAllMessages();
                            v0_5.mCoolleduProgramIndex = (v0_5.mCoolleduProgramIndex + 1);
                            v0_5.mSendIndex = 0;
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("sendingData to the next program from 0package>>>mSendIndex>>> ").append(v0_5.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(v0_5.mCoolleduProgramIndex).append(">>> mDeviceIndex>>").append(v0_5.mDeviceIndex).toString());
                            v0_5.sendCoolleduStartSendProgramData(v0_5.mCoolleduProgramList, v0_5.mCoolleduProgramIndex, v0_5.mCoolleduProgramCount);
                            return;
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("send last package to the last program (mCoolleduProgramIndex == (mCoolleduProgramCount - 1)>>>mCoolleduProgramIndex>>>").append(this.mCoolleduProgramIndex).append(">>>mCoolleduProgramCount>>>").append(this.mCoolleduProgramCount).toString());
                            com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>deviceSize>>>").append(this.mSendDataEnableMap.size()).toString());
                            if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduProgramData.size(), this.mCoolleduProgramData.size())));
                                this.isMessageSuccess = 1;
                                this.mMaxRetryTimesForPackage = 3;
                                this.mMaxRetryTimesForAll = 3;
                                void v0_6 = this.clearAllMessages();
                                v0_6.mDeviceIndex = (v0_6.mDeviceIndex + 1);
                                v0_6.mCoolleduProgramIndex = 0;
                                v0_6.mSendIndex = 0;
                                v0_6.isMessageSuccess = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_17, new StringBuilder("send data to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_6.mSendIndex).append(">>>mCoolleduProgramIndex>>>").append(v0_6.mCoolleduProgramIndex).append(">>> mDeviceIndex>>").append(v0_6.mDeviceIndex).toString());
                                v0_6.sendCoolleduStartSendProgramData(v0_6.mCoolleduProgramList, v0_6.mCoolleduProgramIndex, v0_6.mCoolleduProgramCount);
                                return;
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduProgramData.size(), this.mCoolleduProgramData.size())));
                                void v0_7 = this.clearAllMessages();
                                v0_7.isMessageSuccess = 1;
                                v0_7.mDeviceIndex = 0;
                                v0_7.mCoolleduProgramIndex = 0;
                                v0_7.mSendIndex = 0;
                                com.jtkj.library.commom.logger.CLog.i(v2_17, "onEvent>>>checktime2");
                                v0_7.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$9(v0_7), 1000);
                                return;
                            }
                        }
                    }
                }
            }
        }
        return;
    }

    private void checkCoolLEDUXMessages(java.util.List p22)
    {
        String v3_146;
        void v0_0 = this;
        int v2_18 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkCoolLEDUXMessages>>>").append(p22.toString()).toString());
        String v4_13 = 0;
        if (p22.size() < 1) {
            v3_146 = 0;
        } else {
            v3_146 = ((String) p22.get(0));
        }
        if (!android.text.TextUtils.isEmpty(v3_146)) {
            int v6_33 = 16;
            if (Integer.parseInt(v3_146, 16) != Integer.parseInt("1c", 16)) {
                if (Integer.parseInt(v3_146, 16) != Integer.parseInt("0a", 16)) {
                    if (Integer.parseInt(v3_146, 16) != Integer.parseInt("0b", 16)) {
                        if (Integer.parseInt(v3_146, 16) != Integer.parseInt("10", 16)) {
                            if (Integer.parseInt(v3_146, 16) != Integer.parseInt("0f", 16)) {
                                if (Integer.parseInt(v3_146, 16) != Integer.parseInt("11", 16)) {
                                    if (Integer.parseInt(v3_146, 16) != Integer.parseInt("13", 16)) {
                                        if (Integer.parseInt(v3_146, 16) != Integer.parseInt("09", 16)) {
                                            if (Integer.parseInt(v3_146, 16) != Integer.parseInt("fd", 16)) {
                                                if (p22.size() != 5) {
                                                    if (p22.size() != 2) {
                                                        if (Integer.parseInt(((String) p22.get(0)), 16) == Integer.parseInt("1f", 16)) {
                                                            void v0_10;
                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, "getCoolLEDUXDeviceInfo");
                                                            String v3_41 = Integer.parseInt(((String) p22.get(1)), 16);
                                                            com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p22.get(2)), 16);
                                                            com.jtkj.led1248.light.device.DeviceManager.mRotate = Integer.parseInt(((String) p22.get(3)), 16);
                                                            com.jtkj.library.fastble.data.BleDevice v5_21 = Integer.parseInt(((String) p22.get(4)), 16);
                                                            int v6_5 = Integer.parseInt(((String) p22.get(5)), 16);
                                                            int v7_5 = Integer.parseInt(((String) p22.get(6)), 16);
                                                            int v8_17 = Integer.parseInt(((String) p22.get(7)), 16);
                                                            int v9_18 = Integer.parseInt(((String) p22.get(8)), 16);
                                                            int v10_12 = Integer.parseInt(((String) p22.get(9)), 16);
                                                            com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v12_0 = 1024;
                                                            if (p22.size() != 21) {
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, "getCoolLEDUXDeviceInfo>>>default  packageSize>>>1024");
                                                                v0_10 = this.setUxDevicePackageSize(this.mDeviceCheckOrSetPassword.getMac(), 1024);
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager$15 v1_199 = Integer.parseInt(new StringBuilder().append(((String) p22.get(19))).append(((String) p22.get(20))).toString(), 16);
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getCoolLEDUXDeviceInfo>>>new  packageSize>>>").append(v1_199).toString());
                                                                if (v1_199 == null) {
                                                                    this.UX_PACKAGE_SIZE = 1024;
                                                                }
                                                                if (v1_199 <= 4096) {
                                                                    v12_0 = v1_199;
                                                                }
                                                                v0_10 = this.setUxDevicePackageSize(this.mDeviceCheckOrSetPassword.getMac(), v12_0);
                                                            }
                                                            int v19_1;
                                                            String v4_88;
                                                            if (v3_41 != null) {
                                                                v4_88 = 1;
                                                                v19_1 = 0;
                                                                if (v3_41 == 1) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                                                                }
                                                            } else {
                                                                v19_1 = 0;
                                                                com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                                                                v4_88 = 1;
                                                            }
                                                            if (v5_21 != null) {
                                                                if (v5_21 == v4_88) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = v4_88;
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = v19_1;
                                                            }
                                                            if (v6_5 != 0) {
                                                                if (v6_5 == v4_88) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = v4_88;
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff = v19_1;
                                                            }
                                                            if (v8_17 != 0) {
                                                                if (v8_17 == v4_88) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isShowDeviceId = v4_88;
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.isShowDeviceId = v19_1;
                                                            }
                                                            if (v10_12 != 0) {
                                                                if (v8_17 == v4_88) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isRemoteEnable = v4_88;
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.isRemoteEnable = v19_1;
                                                            }
                                                            com.jtkj.led1248.CoolLED.getInstance().savePreference("COOLEDU_LOCAL_MIC_SUPPORTED_KEY", Boolean.valueOf(com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported));
                                                            com.jtkj.led1248.light.device.DeviceManager$15 v1_227 = new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUXDeviceInfo();
                                                            v1_227.isSwitchOnOff = com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff;
                                                            v1_227.brightNess = com.jtkj.led1248.light.device.DeviceManager.mBrightNess;
                                                            v1_227.rotate = com.jtkj.led1248.light.device.DeviceManager.mRotate;
                                                            v1_227.isLocalMicSupported = com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported;
                                                            v1_227.isLocalMicOnOff = com.jtkj.led1248.light.device.DeviceManager.isLocalMicOnOff;
                                                            v1_227.localMicMode = v7_5;
                                                            v1_227.isShowDeviceId = com.jtkj.led1248.light.device.DeviceManager.isShowDeviceId;
                                                            v1_227.maxProgramNumber = v9_18;
                                                            v1_227.isRemoteEnable = com.jtkj.led1248.light.device.DeviceManager.isRemoteEnable;
                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getCoolLEDUXDeviceInfo>>>").append(v1_227).toString());
                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUXDeviceInfoEvent(v1_227));
                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SynchronizeTimeEvent());
                                                            com.jtkj.led1248.CoolLED.postDelay(new com.jtkj.led1248.light.device.DeviceManager$15(v0_10), 1000);
                                                        }
                                                    } else {
                                                        if ((Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("02", 16)) && (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("1a", 16))) {
                                                            if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("fe", 16)) {
                                                                if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("0d", 16)) {
                                                                    if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("0e", 16)) {
                                                                        if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("04", 16)) {
                                                                            String v4_228 = 0;
                                                                            if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("0c", 16)) {
                                                                                if (Integer.parseInt(((String) p22.get(0)), 16) == Integer.parseInt("05", 16)) {
                                                                                    String v3_241 = Integer.parseInt(((String) p22.get(1)), 16);
                                                                                    if (v3_241 != null) {
                                                                                        if (v3_241 == 1) {
                                                                                            com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 1;
                                                                                        }
                                                                                    } else {
                                                                                        com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff = 0;
                                                                                    }
                                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getCoolLEDUXdeviceInfo>>>isSwitchOnOff>>>").append(com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff).toString());
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CoolLEDUXSwitchInfo(com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff));
                                                                                    v4_228 = 0;
                                                                                }
                                                                            } else {
                                                                                String v3_250 = Integer.parseInt(((String) p22.get(1)), 16);
                                                                                if (v3_250 != null) {
                                                                                    if (v3_250 == 1) {
                                                                                        com.jtkj.led1248.light.device.DeviceManager.isMirror = 1;
                                                                                    }
                                                                                } else {
                                                                                    com.jtkj.led1248.light.device.DeviceManager.isMirror = 0;
                                                                                }
                                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("isMirror>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMirror).toString());
                                                                            }
                                                                        } else {
                                                                            com.jtkj.led1248.light.device.DeviceManager.mBrightNess = Integer.parseInt(((String) p22.get(1)), 16);
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("mBrightNess>>>").append(com.jtkj.led1248.light.device.DeviceManager.mBrightNess).toString());
                                                                        }
                                                                    } else {
                                                                        int v6_59;
                                                                        if (Integer.parseInt(((String) p22.get(1)), 16) != 0) {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>SetCoolLEDUXDevicePassword>>failure>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                                                            v6_59 = 0;
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(0, this.mDeviceCheckOrSetPassword));
                                                                        } else {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>SetCoolLEDUXDevicePassword>>success>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                                                            com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToSet);
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(1, this.mDeviceCheckOrSetPassword));
                                                                            v6_59 = 0;
                                                                        }
                                                                        v4_228 = v6_59;
                                                                    }
                                                                } else {
                                                                    if (Integer.parseInt(((String) p22.get(1)), 16) != 0) {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_FAILURE_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>CheckCoolLEDUXDevicePassword>>failure>>>password>>>").append(this.mPasswordToCheck).toString());
                                                                        String v3_298 = this.mCheckPasswordKind;
                                                                        if (v3_298 != 2) {
                                                                            if (v3_298 != 1) {
                                                                            } else {
                                                                                String v3_299 = this.mCheckPasswordTimes;
                                                                                if (v3_299 < 3) {
                                                                                    this.mCheckPasswordTimes = (v3_299 + 1);
                                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                                                                    this.checkPassWordAfterConnectSuccess(this.mDeviceCheckOrSetPassword);
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                                                                }
                                                                            }
                                                                        } else {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, "checkPassword>>>CHECK_PASSWORD_AFTER_INPUT_PASSWORD>>");
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                                                        }
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_SUCCESS_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(v0_0.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(v0_0.mDeviceCheckOrSetPassword)).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("checkPassword>>>CheckCoolLEDUXDevicePassword>>success>>>password>>>").append(this.mPasswordToCheck).toString());
                                                                        this.mVerifyPasswordMap.put(this.mDeviceCheckOrSetPassword.getMac(), Boolean.valueOf(1));
                                                                        com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToCheck);
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 5));
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 1, this.mDeviceCheckOrSetPassword));
                                                                        v0_0.updateDeviceInfo(v0_0.mDeviceCheckOrSetPassword);
                                                                    }
                                                                }
                                                            } else {
                                                                if (Integer.parseInt(((String) p22.get(1)), 16) != 0) {
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("response == 0>>>send startCoolleduxProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                    this.mMaxRetryTimesForAll = 3;
                                                                    void v0_11 = this.clearAllMessages();
                                                                    v0_11.sendCooleduxOtaUpgradeData(v0_11.mSendIndex).mHandler.sendEmptyMessageDelayed(1005, 5000);
                                                                }
                                                            }
                                                        } else {
                                                            int v9_48 = Integer.parseInt(((String) p22.get(1)), 16);
                                                            if (v9_48 != 0) {
                                                                if (v9_48 != 1) {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("results.size() == 2>>>response ==").append(v9_48).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("response == 1>>>sendCoolleduxProgramData>>>(response == 1 no need send from package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(this.mCoolleduxProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                    if (this.mCoolleduxProgramIndex != (this.mCoolleduxProgramCount - 1)) {
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxProgramData.size(), this.mCoolleduxProgramData.size())));
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "mCoolleduxProgramIndex /= (mCoolleduxProgramCount - 1)>>>sendNextProgramData");
                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                        this.mMaxRetryTimesForAll = 3;
                                                                        void v0_13 = this.clearAllMessages();
                                                                        v0_13.mSendIndex = 0;
                                                                        v0_13.mCoolleduxProgramIndex = (v0_13.mCoolleduxProgramIndex + 1);
                                                                        v0_13.isMessageSuccess = 0;
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("sendingData from next program>>>SendIndex>>>").append(v0_13.mSendIndex).append(">>>mDeviceIndex>>>").append(v0_13.mDeviceIndex).append(">>>mSendDataEnableMap.size()>>>").append(v0_13.mSendDataEnableMap.size()).toString());
                                                                        v0_13.sendCoolleduxStartSendProgramData(v0_13.mCoolleduxProgramList, v0_13.mCoolleduxProgramIndex, v0_13.mCoolleduxProgramCount);
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "send Coolledux start send program success to the last program mCoolleduxProgramIndex == (mCoolleduxProgramCount - 1)(response == 1)");
                                                                        if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, "send to not the last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))>>>(response == 1)");
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxProgramData.size(), this.mCoolleduxProgramData.size())));
                                                                            this.mMaxRetryTimesForPackage = 3;
                                                                            this.mMaxRetryTimesForAll = 3;
                                                                            void v0_14 = this.clearAllMessages();
                                                                            v0_14.mDeviceIndex = (v0_14.mDeviceIndex + 1);
                                                                            v0_14.mCoolleduxProgramIndex = 0;
                                                                            v0_14.mSendIndex = 0;
                                                                            v0_14.isMessageSuccess = 0;
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("sendingData to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_14.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(v0_14.mCoolleduxProgramIndex).append(">>> mDeviceIndex>>").append(v0_14.mDeviceIndex).toString());
                                                                            v0_14.sendCoolleduxStartSendProgramData(v0_14.mCoolleduxProgramList, v0_14.mCoolleduxProgramIndex, v0_14.mCoolleduxProgramCount);
                                                                        } else {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, "send  to the last device success (mDeviceIndex == (mSendDataEnableMap.size() - 1))(response == 1)");
                                                                            void v0_15 = this.clearAllMessages();
                                                                            v0_15.isMessageSuccess = 1;
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((v0_15.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(v0_15.mCoolleduxProgramData.size(), v0_15.mCoolleduxProgramData.size())));
                                                                            v0_15.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$14(v0_15), 1000);
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("response == 0>>>send startCoolleduxProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(this.mCoolleduxProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                this.mMaxRetryTimesForPackage = 3;
                                                                this.mMaxRetryTimesForAll = 3;
                                                                void v0_16 = this.clearAllMessages();
                                                                v0_16.sendCooleduxProgramData(v0_16.mSendIndex).mHandler.sendEmptyMessageDelayed(1004, 5000);
                                                            }
                                                        }
                                                        if ((Integer.parseInt(((String) p22.get(v4_228)), 16) != Integer.parseInt("0c", 16)) && (Integer.parseInt(((String) p22.get(v4_228)), 16) != Integer.parseInt("1c", 16))) {
                                                            if ((Integer.parseInt(((String) p22.get(v4_228)), 16) != Integer.parseInt("1e", 16)) && (Integer.parseInt(((String) p22.get(v4_228)), 16) != Integer.parseInt("1c", 16))) {
                                                                if (Integer.parseInt(((String) p22.get(v4_228)), 16) == Integer.parseInt("09", 16)) {
                                                                    com.jtkj.led1248.light.device.DeviceManager$15 v1_259 = Integer.parseInt(((String) p22.get(1)), 16);
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder(">>>synchronizeTimeResult>>>").append(v1_259).toString());
                                                                    if (v1_259 != null) {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, ">>>synchronizeTimeResult>>>failure");
                                                                        return;
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, ">>>synchronizeTimeResult>>>success");
                                                                        return;
                                                                    }
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.mDriveState = Integer.parseInt(((String) p22.get(1)), 16);
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getCoolLEDUXdeviceInfo>>>driveSate>>>").append(com.jtkj.led1248.light.device.DeviceManager.mDriveState).toString());
                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$DriveStateResponseEvent(com.jtkj.led1248.light.device.DeviceManager.mDriveState));
                                                                return;
                                                            }
                                                        } else {
                                                            com.jtkj.led1248.light.device.DeviceManager.mRotate = Integer.parseInt(((String) p22.get(1)), 16);
                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getCoolLEDUXdeviceInfo>>>mRotate>>>").append(com.jtkj.led1248.light.device.DeviceManager.mRotate).toString());
                                                            return;
                                                        }
                                                    }
                                                } else {
                                                    if (Integer.parseInt(((String) p22.get(0)), 16) != Integer.parseInt("03", 16)) {
                                                        if (Integer.parseInt(((String) p22.get(0)), 16) == Integer.parseInt("ff", 16)) {
                                                            int v8_7 = Integer.parseInt(((String) p22.get(4)), 16);
                                                            this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p22.get(2))).append(((String) p22.get(3))).toString(), 16);
                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("OTAresponse>>>").append(v8_7).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                                                            if (v8_7 != 0) {
                                                                if (v8_7 != 1) {
                                                                    if (v8_7 != 2) {
                                                                        if (v8_7 != 3) {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("OTAresponse ==").append(v8_7).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                                                            return;
                                                                        } else {
                                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, "OTAresponse == 3>>>DATA_ERROR");
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                            return;
                                                                        }
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "OTAresponse == 2>>>DEVICE_ERROR");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                                                                        return;
                                                                    }
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, "OTAresponse == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForCoolLEDUX>>>1");
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                                                                    return;
                                                                }
                                                            } else {
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduxOTAUpgradeData.size()>>>").append(this.mCoolleduxOTAUpgradeData.size()).toString());
                                                                if (this.mSendIndex != (this.mCoolleduxOTAUpgradeData.size() - 1)) {
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolleduxOTAUpgradeData.size())));
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                    this.mMaxRetryTimesForAll = 3;
                                                                    void v0_1 = this.clearAllMessages();
                                                                    com.jtkj.led1248.light.device.DeviceManager$15 v1_46 = (v0_1.mSendIndex + 1);
                                                                    v0_1.mSendIndex = v1_46;
                                                                    v0_1.sendCooleduxOtaUpgradeData(v1_46).mHandler.sendEmptyMessageDelayed(1006, 5000);
                                                                    return;
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("send data to the last package success>>>(mSendIndex == (mCoolleduxOTAUpgradeData.size() - 1))>>").append((this.mCoolleduxOTAUpgradeData.size() - 1)).toString());
                                                                    if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxOTAUpgradeData.size(), this.mCoolleduxOTAUpgradeData.size())));
                                                                        this.isMessageSuccess = 1;
                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                        this.mMaxRetryTimesForAll = 3;
                                                                        void v0_3 = this.clearAllMessages();
                                                                        v0_3.mDeviceIndex = (v0_3.mDeviceIndex + 1);
                                                                        v0_3.mSendIndex = 0;
                                                                        v0_3.isMessageSuccess = 0;
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("send data to the next device from 0 package>>>mSendIndex>>> ").append(v0_3.mSendIndex).append(">>> mDeviceIndex>>").append(v0_3.mDeviceIndex).toString());
                                                                        v0_3.sendCoolleduxStartSendOTAUpgradeData();
                                                                        return;
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxOTAUpgradeData.size(), this.mCoolleduxOTAUpgradeData.size())));
                                                                        void v0_4 = this.clearAllMessages();
                                                                        v0_4.isMessageSuccess = 1;
                                                                        v0_4.mDeviceIndex = 0;
                                                                        v0_4.mSendIndex = 0;
                                                                        v0_4.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$13(v0_4), 1000);
                                                                        return;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        int v8_10 = Integer.parseInt(((String) p22.get(4)), 16);
                                                        this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p22.get(2))).append(((String) p22.get(3))).toString(), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("response>>>").append(v8_10).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                                                        if (v8_10 != 0) {
                                                            if (v8_10 != 1) {
                                                                if (v8_10 != 2) {
                                                                    if (v8_10 != 3) {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("response ==").append(v8_10).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                                                        return;
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "response == 3>>>DATA_ERROR");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                        return;
                                                                    }
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, "response == 2>>>DEVICE_ERROR");
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                                                                    return;
                                                                }
                                                            } else {
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, "response == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForCoolLEDUX>>>1");
                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                                                                return;
                                                            }
                                                        } else {
                                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduxProgramData.size()>>>").append(this.mCoolleduxProgramData.size()).append(">>>mCoolleduxProgramIndex>>>").append(this.mCoolleduxProgramIndex).append(">>>mCoolleduxProgramCount>>>").append(this.mCoolleduxProgramCount).toString());
                                                            if (this.mSendIndex != (this.mCoolleduxProgramData.size() - 1)) {
                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolleduxProgramData.size())));
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(this.mCoolleduxProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                this.mMaxRetryTimesForPackage = 3;
                                                                this.mMaxRetryTimesForAll = 3;
                                                                void v0_5 = this.clearAllMessages();
                                                                com.jtkj.led1248.light.device.DeviceManager$15 v1_116 = (v0_5.mSendIndex + 1);
                                                                v0_5.mSendIndex = v1_116;
                                                                v0_5.sendCooleduxProgramData(v1_116).mHandler.sendEmptyMessageDelayed(1004, 5000);
                                                                return;
                                                            } else {
                                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("send data to the last package success>>>(mSendIndex == (mCoolleduxProgramData.size() - 1))>>").append((this.mCoolleduxProgramData.size() - 1)).toString());
                                                                if (this.mCoolleduxProgramIndex != (this.mCoolleduxProgramCount - 1)) {
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxProgramData.size(), this.mCoolleduxProgramData.size())));
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, "send data to  not  the last program (mCoolleduxProgramIndex /= (mCoolleduxProgramCount - 1)))");
                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                    this.mMaxRetryTimesForAll = 3;
                                                                    void v0_7 = this.clearAllMessages();
                                                                    v0_7.mCoolleduxProgramIndex = (v0_7.mCoolleduxProgramIndex + 1);
                                                                    v0_7.mSendIndex = 0;
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("sendingData to the next program from 0package>>>mSendIndex>>> ").append(v0_7.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(v0_7.mCoolleduxProgramIndex).append(">>> mDeviceIndex>>").append(v0_7.mDeviceIndex).toString());
                                                                    v0_7.sendCoolleduxStartSendProgramData(v0_7.mCoolleduxProgramList, v0_7.mCoolleduxProgramIndex, v0_7.mCoolleduxProgramCount);
                                                                    return;
                                                                } else {
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("send last package to the last program (mCoolleduxProgramIndex == (mCoolleduxProgramCount - 1)>>>mCoolleduxProgramIndex>>>").append(this.mCoolleduxProgramIndex).append(">>>mCoolleduxProgramCount>>>").append(this.mCoolleduxProgramCount).toString());
                                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>deviceSize>>>").append(this.mSendDataEnableMap.size()).toString());
                                                                    if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxProgramData.size(), this.mCoolleduxProgramData.size())));
                                                                        this.isMessageSuccess = 1;
                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                        this.mMaxRetryTimesForAll = 3;
                                                                        void v0_8 = this.clearAllMessages();
                                                                        v0_8.mDeviceIndex = (v0_8.mDeviceIndex + 1);
                                                                        v0_8.mCoolleduxProgramIndex = 0;
                                                                        v0_8.mSendIndex = 0;
                                                                        v0_8.isMessageSuccess = 0;
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("send data to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v0_8.mSendIndex).append(">>>mCoolleduxProgramIndex>>>").append(v0_8.mCoolleduxProgramIndex).append(">>> mDeviceIndex>>").append(v0_8.mDeviceIndex).toString());
                                                                        v0_8.sendCoolleduxStartSendProgramData(v0_8.mCoolleduxProgramList, v0_8.mCoolleduxProgramIndex, v0_8.mCoolleduxProgramCount);
                                                                        return;
                                                                    } else {
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mCoolleduxProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mCoolleduxProgramData.size(), this.mCoolleduxProgramData.size())));
                                                                        void v0_9 = this.clearAllMessages();
                                                                        v0_9.isMessageSuccess = 1;
                                                                        v0_9.mDeviceIndex = 0;
                                                                        v0_9.mCoolleduxProgramIndex = 0;
                                                                        v0_9.mSendIndex = 0;
                                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "onEvent>>>checktime2");
                                                                        v0_9.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$12(v0_9), 1000);
                                                                        return;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                String v3_110 = Integer.parseInt(((String) p22.get(1)), 16);
                                                if (v3_110 != null) {
                                                    if (v3_110 == 1) {
                                                        com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported = 1;
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("get ota info>>> response>>>otaFlag>>").append(v3_110).append(">>>isCoolleduxHardwareUpdateSupported>>>").append(com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported).toString());
                                                        com.jtkj.led1248.light.device.DeviceManager.CoolleduxLocalOTAVersion = Integer.parseInt(new StringBuilder().append(((String) p22.get(2))).append(((String) p22.get(3))).toString(), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("get ota info>>> response>>>CoolleduxLocalOTAVersion>>").append(com.jtkj.led1248.light.device.DeviceManager.CoolleduxLocalOTAVersion).toString());
                                                        String v3_127 = Integer.parseInt(((String) p22.get(4)), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("get ota info>>> response>>>fileNameLength>>").append(v3_127).toString());
                                                        com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME = "";
                                                        int v2_12 = 5;
                                                        while (v2_12 < (v3_127 + 5)) {
                                                            com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME = new StringBuilder().append(com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME).append(((char) Integer.parseInt(((String) p22.get(v2_12)), 16))).toString();
                                                            v2_12++;
                                                        }
                                                        com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME = com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME.trim();
                                                        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("get ota info>>> response>>>Coolledux_REMOTE_OTA_FILE_NAME>>").append(com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME).toString());
                                                        com.jtkj.led1248.base.OkHttpUtils.getInstance().checkRemoteOtaInfo(com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME);
                                                        return;
                                                    }
                                                } else {
                                                    com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported = 0;
                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("get ota info>>> response>>>otaFlag>>").append(v3_110).append(">>>isCoolleduxHardwareUpdateSupported>>>").append(com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported).toString());
                                                    return;
                                                }
                                            }
                                        } else {
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("ux syncTime response>>>action>>").append(((String) p22.get(0))).append(">>>ack>>>").append(((String) p22.get(1))).toString());
                                            return;
                                        }
                                    } else {
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("ux color response>>>action>>").append(((String) p22.get(1))).append(">>>ack>>>").append(((String) p22.get(2))).toString());
                                        return;
                                    }
                                } else {
                                    if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("01", 16)) {
                                        if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("02", 16)) {
                                            if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("03", 16)) {
                                                if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("04", 16)) {
                                                    if (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("05", 16)) {
                                                        String v4_61;
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, "scoreBoard>>>value>>>05>>>finished");
                                                        String v3_158 = new com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEventResponse();
                                                        String v4_57 = Integer.parseInt(new StringBuilder().append(((String) p22.get(2))).append(((String) p22.get(3))).toString(), 16);
                                                        int v6_19 = Integer.parseInt(new StringBuilder().append(((String) p22.get(4))).append(((String) p22.get(5))).toString(), 16);
                                                        int v7_17 = Integer.parseInt(((String) p22.get(6)), 16);
                                                        int v8_21 = Integer.parseInt(((String) p22.get(7)), 16);
                                                        int v9_22 = Integer.parseInt(((String) p22.get(8)), 16);
                                                        int v10_16 = Integer.parseInt(((String) p22.get(9)), 16);
                                                        String v11_12 = Integer.parseInt(((String) p22.get(10)), 16);
                                                        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v12_4 = Integer.parseInt(((String) p22.get(11)), 16);
                                                        int v13_3 = Integer.parseInt(((String) p22.get(12)), 16);
                                                        com.jtkj.led1248.light.device.DeviceManager$15 v1_195 = Integer.parseInt(((String) p22.get(13)), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>hostScoreValue>>>").append(v4_57).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>visitScoreValue>>>").append(v6_19).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>hostTotalScoreValue>>>").append(v7_17).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>visitTotalScoreValue>>>").append(v8_21).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>deviceMinuteValue>>>").append(v9_22).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>deviceSecondsValue>>>").append(v10_16).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>statusValue>>>").append(v11_12).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>setMinuteValue>>>").append(v12_4).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>setSecondsValue>>>").append(v13_3).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>timeModeValue>>>").append(v1_195).toString());
                                                        v3_158.hostScore = v4_57;
                                                        v3_158.visitScore = v6_19;
                                                        v3_158.hostTotalScore = v7_17;
                                                        v3_158.visitTotalScore = v8_21;
                                                        v3_158.deviceMinute = v9_22;
                                                        v3_158.deviceSeconds = v10_16;
                                                        if (v11_12 != 1) {
                                                            v4_61 = 0;
                                                            v3_158.isStartOrStop = 0;
                                                        } else {
                                                            v3_158.isStartOrStop = 1;
                                                            v4_61 = 0;
                                                        }
                                                        v3_158.setMinute = v12_4;
                                                        v3_158.setSeconds = v13_3;
                                                        if (v1_195 != 1) {
                                                            v3_158.isCountDown = v4_61;
                                                        } else {
                                                            v3_158.isCountDown = 1;
                                                        }
                                                        v3_158.actionType = 5;
                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_158);
                                                        return;
                                                    }
                                                } else {
                                                    String v3_161 = new com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEventResponse();
                                                    com.jtkj.led1248.light.device.DeviceManager$15 v1_202 = Integer.parseInt(((String) p22.get(2)), 16);
                                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>value>>>").append(v1_202).toString());
                                                    if (v1_202 != null) {
                                                        v3_161.response = 0;
                                                    } else {
                                                        v3_161.response = 1;
                                                    }
                                                    v3_161.actionType = 4;
                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_161);
                                                    return;
                                                }
                                            } else {
                                                String v3_163 = new com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEventResponse();
                                                com.jtkj.led1248.light.device.DeviceManager$15 v1_205 = Integer.parseInt(((String) p22.get(2)), 16);
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>value>>>").append(v1_205).toString());
                                                if (v1_205 != null) {
                                                    v3_163.response = 0;
                                                } else {
                                                    v3_163.response = 1;
                                                }
                                                v3_163.actionType = 3;
                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_163);
                                                return;
                                            }
                                        } else {
                                            String v3_165 = new com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEventResponse();
                                            com.jtkj.led1248.light.device.DeviceManager$15 v1_208 = Integer.parseInt(((String) p22.get(2)), 16);
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>value>>>").append(v1_208).toString());
                                            if (v1_208 != null) {
                                                v3_165.response = 0;
                                            } else {
                                                v3_165.response = 1;
                                            }
                                            v3_165.actionType = 2;
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_165);
                                            return;
                                        }
                                    } else {
                                        String v4_89;
                                        String v3_167 = new com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEventResponse();
                                        String v4_87 = Integer.parseInt(new StringBuilder().append(((String) p22.get(2))).append(((String) p22.get(3))).toString(), 16);
                                        int v6_25 = Integer.parseInt(new StringBuilder().append(((String) p22.get(4))).append(((String) p22.get(5))).toString(), 16);
                                        int v7_26 = Integer.parseInt(((String) p22.get(6)), 16);
                                        int v8_26 = Integer.parseInt(((String) p22.get(7)), 16);
                                        int v9_26 = Integer.parseInt(((String) p22.get(8)), 16);
                                        int v10_20 = Integer.parseInt(((String) p22.get(9)), 16);
                                        String v11_17 = Integer.parseInt(((String) p22.get(10)), 16);
                                        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v12_8 = Integer.parseInt(((String) p22.get(11)), 16);
                                        int v13_7 = Integer.parseInt(((String) p22.get(12)), 16);
                                        com.jtkj.led1248.light.device.DeviceManager$15 v1_213 = Integer.parseInt(((String) p22.get(13)), 16);
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>hostScoreValue>>>").append(v4_87).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>visitScoreValue>>>").append(v6_25).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>hostTotalScoreValue>>>").append(v7_26).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>visitTotalScoreValue>>>").append(v8_26).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>deviceMinuteValue>>>").append(v9_26).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>deviceSecondsValue>>>").append(v10_20).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>statusValue>>>").append(v11_17).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>setMinuteValue>>>").append(v12_8).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>setSecondsValue>>>").append(v13_7).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("scoreBoard>>>timeModeValue>>>").append(v1_213).toString());
                                        v3_167.hostScore = v4_87;
                                        v3_167.visitScore = v6_25;
                                        v3_167.hostTotalScore = v7_26;
                                        v3_167.visitTotalScore = v8_26;
                                        v3_167.deviceMinute = v9_26;
                                        v3_167.deviceSeconds = v10_20;
                                        if (v11_17 != 1) {
                                            v4_89 = 0;
                                            v3_167.isStartOrStop = 0;
                                        } else {
                                            v3_167.isStartOrStop = 1;
                                            v4_89 = 0;
                                        }
                                        v3_167.setMinute = v12_8;
                                        v3_167.setSeconds = v13_7;
                                        if (v1_213 != 1) {
                                            v3_167.isCountDown = v4_89;
                                        } else {
                                            v3_167.isCountDown = 1;
                                        }
                                        v3_167.actionType = 1;
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_167);
                                        return;
                                    }
                                }
                            } else {
                                if (p22.size() != 3) {
                                    if (p22.size() == 9) {
                                        if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("01", 16)) {
                                            if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("03", 16)) {
                                                if (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("04", 16)) {
                                                    com.jtkj.led1248.light.device.DeviceManager$15 v1_218 = new com.jtkj.led1248.light.device.DeviceManager$CountDownEventResponse();
                                                    v1_218.actionType = 4;
                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_218);
                                                    return;
                                                }
                                            } else {
                                                String v3_177 = new com.jtkj.led1248.light.device.DeviceManager$CountDownEventResponse();
                                                com.jtkj.library.fastble.data.BleDevice v5_166 = Integer.parseInt(((String) p22.get(2)), 16);
                                                int v6_28 = Integer.parseInt(((String) p22.get(3)), 16);
                                                int v7_33 = Integer.parseInt(((String) p22.get(4)), 16);
                                                int v8_30 = Integer.parseInt(((String) p22.get(5)), 16);
                                                int v9_30 = Integer.parseInt(((String) p22.get(6)), 16);
                                                int v10_24 = Integer.parseInt(((String) p22.get(7)), 16);
                                                com.jtkj.led1248.light.device.DeviceManager$15 v1_221 = Integer.parseInt(((String) p22.get(8)), 16);
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>statusValue>>>").append(v5_166).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setHourValue>>>").append(v6_28).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setMinuteValue>>>").append(v7_33).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setSecondsValue>>>").append(v8_30).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftHourValue>>>").append(v9_30).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftMinuteValue>>>").append(v10_24).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftSecondsValue>>>").append(v1_221).toString());
                                                v3_177.setHour = v6_28;
                                                v3_177.setMinute = v7_33;
                                                v3_177.setSeconds = v8_30;
                                                v3_177.leftHour = v9_30;
                                                v3_177.leftMinute = v10_24;
                                                v3_177.leftSeconds = v1_221;
                                                if (v5_166 != 1) {
                                                    v3_177.isStartOrStop = 0;
                                                } else {
                                                    v3_177.isStartOrStop = 1;
                                                }
                                                v3_177.actionType = 3;
                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_177);
                                                return;
                                            }
                                        } else {
                                            String v3_180 = new com.jtkj.led1248.light.device.DeviceManager$CountDownEventResponse();
                                            com.jtkj.library.fastble.data.BleDevice v5_171 = Integer.parseInt(((String) p22.get(2)), 16);
                                            int v6_32 = Integer.parseInt(((String) p22.get(3)), 16);
                                            int v7_37 = Integer.parseInt(((String) p22.get(4)), 16);
                                            int v8_34 = Integer.parseInt(((String) p22.get(5)), 16);
                                            int v9_34 = Integer.parseInt(((String) p22.get(6)), 16);
                                            int v10_28 = Integer.parseInt(((String) p22.get(7)), 16);
                                            com.jtkj.led1248.light.device.DeviceManager$15 v1_225 = Integer.parseInt(((String) p22.get(8)), 16);
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>statusValue>>>").append(v5_171).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setHourValue>>>").append(v6_32).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setMinuteValue>>>").append(v7_37).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>setSecondsValue>>>").append(v8_34).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftHourValue>>>").append(v9_34).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftMinuteValue>>>").append(v10_28).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>leftSecondsValue>>>").append(v1_225).toString());
                                            v3_180.setHour = v6_32;
                                            v3_180.setMinute = v7_37;
                                            v3_180.setSeconds = v8_34;
                                            v3_180.leftHour = v9_34;
                                            v3_180.leftMinute = v10_28;
                                            v3_180.leftSeconds = v1_225;
                                            if (v5_171 != 1) {
                                                v3_180.isStartOrStop = 0;
                                            } else {
                                                v3_180.isStartOrStop = 1;
                                            }
                                            v3_180.actionType = 1;
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_180);
                                            return;
                                        }
                                    }
                                } else {
                                    if (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("02", 16)) {
                                        com.jtkj.led1248.light.device.DeviceManager$15 v1_231 = Integer.parseInt(((String) p22.get(2)), 16);
                                        String v3_189 = new com.jtkj.led1248.light.device.DeviceManager$CountDownEventResponse();
                                        v3_189.actionType = 2;
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("coutdown>>>value>>>").append(v1_231).toString());
                                        if (v1_231 != null) {
                                            v3_189.response = 0;
                                        } else {
                                            v3_189.response = 1;
                                        }
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_189);
                                        return;
                                    }
                                }
                            }
                        } else {
                            if (p22.size() != 3) {
                                if (p22.size() == 6) {
                                    if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("01", 16)) {
                                        if (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("03", 16)) {
                                            String v3_201 = new com.jtkj.led1248.light.device.DeviceManager$StopWatchEventResponse();
                                            com.jtkj.library.fastble.data.BleDevice v5_184 = Integer.parseInt(((String) p22.get(2)), 16);
                                            int v6_35 = Integer.parseInt(((String) p22.get(3)), 16);
                                            int v7_43 = Integer.parseInt(((String) p22.get(4)), 16);
                                            com.jtkj.led1248.light.device.DeviceManager$15 v1_234 = Integer.parseInt(((String) p22.get(5)), 16);
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>statusValue>>>").append(v5_184).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>hourValue>>>").append(v6_35).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>minuteValue>>>").append(v7_43).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>secondsValue>>>").append(v1_234).toString());
                                            v3_201.hour = v6_35;
                                            v3_201.minute = v7_43;
                                            v3_201.seconds = v1_234;
                                            if (v5_184 != 1) {
                                                v3_201.isStartOrStop = 0;
                                            } else {
                                                v3_201.isStartOrStop = 1;
                                            }
                                            v3_201.actionType = 3;
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_201);
                                            return;
                                        }
                                    } else {
                                        String v3_206 = new com.jtkj.led1248.light.device.DeviceManager$StopWatchEventResponse();
                                        com.jtkj.library.fastble.data.BleDevice v5_189 = Integer.parseInt(((String) p22.get(2)), 16);
                                        int v6_39 = Integer.parseInt(((String) p22.get(3)), 16);
                                        int v7_47 = Integer.parseInt(((String) p22.get(4)), 16);
                                        com.jtkj.led1248.light.device.DeviceManager$15 v1_237 = Integer.parseInt(((String) p22.get(5)), 16);
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>statusValue>>>").append(v5_189).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>hourValue>>>").append(v6_39).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>minuteValue>>>").append(v7_47).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>secondsValue>>>").append(v1_237).toString());
                                        v3_206.hour = v6_39;
                                        v3_206.minute = v7_47;
                                        v3_206.seconds = v1_237;
                                        if (v5_189 != 1) {
                                            v3_206.isStartOrStop = 0;
                                        } else {
                                            v3_206.isStartOrStop = 1;
                                        }
                                        v3_206.actionType = 1;
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_206);
                                        return;
                                    }
                                }
                            } else {
                                if (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("02", 16)) {
                                    com.jtkj.led1248.light.device.DeviceManager$15 v1_241 = Integer.parseInt(((String) p22.get(2)), 16);
                                    String v3_214 = new com.jtkj.led1248.light.device.DeviceManager$StopWatchEventResponse();
                                    v3_214.actionType = 2;
                                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("stopwatch>>>value>>>").append(v1_241).toString());
                                    if (v1_241 != null) {
                                        v3_214.response = 0;
                                    } else {
                                        v3_214.response = 1;
                                    }
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_214);
                                    return;
                                }
                            }
                        }
                    } else {
                        String v3_216 = new com.jtkj.led1248.light.device.DeviceManager$GetTimerSwitchEventResponse();
                        int v7_51 = Integer.parseInt(((String) p22.get(1)), 16);
                        if (v7_51 <= 0) {
                            com.jtkj.library.commom.logger.CLog.i(v2_18, "getTimerSwitch  number>>>0");
                        } else {
                            com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getTimerSwitch  number>>>").append(v7_51).toString());
                            int v2_23 = new java.util.ArrayList();
                            int v8_49 = 0;
                            while (v8_49 < v7_51) {
                                com.jtkj.library.fastble.data.BleDevice v5_218;
                                int v9_37 = new com.jtkj.led1248.light.device.DeviceManager$TimerSwitchItem();
                                int v10_29 = (v8_49 * 6);
                                String v11_35 = Integer.parseInt(((String) p22.get((v10_29 + 2))), v6_33);
                                int v15_4 = Integer.parseInt(((String) p22.get((v10_29 + 3))), v6_33);
                                int v13_11 = Integer.parseInt(((String) p22.get((v10_29 + 4))), v6_33);
                                String v14_25 = Integer.parseInt(((String) p22.get((v10_29 + 5))), v6_33);
                                com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v12_12 = Integer.parseInt(((String) p22.get((v10_29 + 6))), v6_33);
                                Integer.parseInt(((String) p22.get((v10_29 + 7))), v6_33);
                                int v10_33 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  enableValue>>>").append(v11_35).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  hourValue>>>").append(v15_4).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  minuteValue>>>").append(v13_11).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  repeatValue>>>").append(v14_25).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  switchValue>>>").append(v12_12).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  actionValue>>>").append(v12_12).toString());
                                if (v11_35 != null) {
                                    v5_218 = 1;
                                    v9_37.enable = 1;
                                    com.jtkj.library.commom.logger.CLog.i(v10_33, "getTimerSwitch  enable>>>true");
                                } else {
                                    v9_37.enable = v4_13;
                                    com.jtkj.library.commom.logger.CLog.i(v10_33, "getTimerSwitch  enable>>>false");
                                    v5_218 = 1;
                                }
                                v9_37.hour = v15_4;
                                v9_37.minute = v13_11;
                                if (v12_12 != null) {
                                    v9_37.isSetDeviceOn = v5_218;
                                    com.jtkj.library.commom.logger.CLog.i(v10_33, "getTimerSwitch  isSetDeviceOn>>>true");
                                } else {
                                    v9_37.isSetDeviceOn = v4_13;
                                    com.jtkj.library.commom.logger.CLog.i(v10_33, "getTimerSwitch  isSetDeviceOn>>>false");
                                }
                                int v6_50 = this.getBit(v14_25, v4_13);
                                String v11_36 = this.getBit(v14_25, v5_218);
                                com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v12_14 = this.getBit(v14_25, 2);
                                int v13_12 = this.getBit(v14_25, 3);
                                int v15_5 = this.getBit(v14_25, 4);
                                String v4_205 = this.getBit(v14_25, 5);
                                String v14_26 = this.getBit(v14_25, 6);
                                String v20 = v7_51;
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  monValue>>>").append(v6_50).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  tueValue>>>").append(v11_36).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  wedValue>>>").append(v12_14).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  thurValue>>>").append(v13_12).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  friValue>>>").append(v15_5).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  satValue>>>").append(v4_205).toString());
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  sunValue>>>").append(v14_26).toString());
                                v9_37.isMondayOn = v6_50;
                                v9_37.isTuesdayOn = v11_36;
                                v9_37.isWednesdayOn = v12_14;
                                v9_37.isThursdayOn = v13_12;
                                v9_37.isFridayOn = v15_5;
                                v9_37.isSaturdayOn = v4_205;
                                v9_37.isSundayOn = v14_26;
                                if ((v6_50 == 0) && ((v11_36 == null) && ((v12_14 == null) && ((v13_12 == 0) && ((v15_5 == 0) && ((v4_205 == null) && (v14_26 == null))))))) {
                                    v9_37.isNever = 1;
                                } else {
                                    v9_37.isNever = 0;
                                }
                                com.jtkj.library.commom.logger.CLog.i(v10_33, new StringBuilder("getTimerSwitch  isNever>>>").append(v9_37.isNever).toString());
                                v2_23.add(v9_37);
                                v8_49++;
                                v7_51 = v20;
                                v4_13 = 0;
                                v6_33 = 16;
                            }
                            v3_216.timerSwitchItemList = v2_23;
                        }
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_216);
                        return;
                    }
                } else {
                    String v3_220 = new com.jtkj.led1248.light.device.DeviceManager$SetTimerSwitchEventResponse();
                    if (Integer.parseInt(((String) p22.get(1)), 16) != Integer.parseInt("00", 16)) {
                        v3_220.isSuccess = 0;
                        com.jtkj.library.commom.logger.CLog.i(v2_18, "setTimerSwitch  response>>>value>>>!=00>>>failure");
                    } else {
                        v3_220.isSuccess = 1;
                        com.jtkj.library.commom.logger.CLog.i(v2_18, "setTimerSwitch  response>>>value>>>00>>>success");
                    }
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_220);
                    return;
                }
            } else {
                String v3_222 = new com.jtkj.led1248.light.device.ILedCarManager$ILedCarGetDriveStateResponseEvent();
                if ((Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("02", 16)) || (Integer.parseInt(((String) p22.get(1)), 16) == Integer.parseInt("03", 16))) {
                    com.jtkj.led1248.light.device.DeviceManager$15 v1_254 = Integer.parseInt(((String) p22.get(2)), 16);
                    v3_222.state = v1_254;
                    com.jtkj.library.commom.logger.CLog.i(v2_18, new StringBuilder("getDriveState  response>>>state>>>").append(v1_254).toString());
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_222);
                    return;
                }
            }
        }
        return;
    }

    private void checkCoolLEDXMessages(java.util.List p21)
    {
        String v13_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkCoolLEDXMessages>>>").append(p21.toString()).toString());
        try {
            if ((p21 != null) && (p21.size() > 0)) {
                if (p21.size() != 5) {
                    if (p21.size() == 2) {
                        if (Integer.parseInt(((String) p21.get(0)), 16) != Integer.parseInt("0d", 16)) {
                            if (Integer.parseInt(((String) p21.get(0)), 16) == Integer.parseInt("0e", 16)) {
                                if (Integer.parseInt(((String) p21.get(1)), 16) != 0) {
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>SetPasswordCoolLEDX>>failure>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(0, this.mDeviceCheckOrSetPassword));
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>SetPasswordCoolLEDX>>success>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                    com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToSet);
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(1, this.mDeviceCheckOrSetPassword));
                                    return;
                                }
                            }
                        } else {
                            if (Integer.parseInt(((String) p21.get(1)), 16) != 0) {
                                com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_FAILURE_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>CheckPasswordCoolLEDX>>failure>>>password>>>").append(this.mPasswordToCheck).toString());
                                com.jtkj.library.fastble.data.BleDevice v0_23 = this.mCheckPasswordKind;
                                if (v0_23 != 2) {
                                    if (v0_23 == 1) {
                                        com.jtkj.library.fastble.data.BleDevice v0_24 = this.mCheckPasswordTimes;
                                        if (v0_24 < 3) {
                                            this.mCheckPasswordTimes = (v0_24 + 1);
                                            com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                            this.checkPassWordAfterConnectSuccess(this.mDeviceCheckOrSetPassword);
                                            return;
                                        } else {
                                            com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                            return;
                                        }
                                    }
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, "checkPassword>>>CHECK_PASSWORD_AFTER_INPUT_PASSWORD>>>");
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                    return;
                                }
                            } else {
                                com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_SUCCESS_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("checkPassword>>>CheckPasswordCoolLEDX>>success>>>password>>>").append(this.mPasswordToCheck).toString());
                                this.mVerifyPasswordMap.put(this.mDeviceCheckOrSetPassword.getMac(), Boolean.valueOf(1));
                                com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToCheck);
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 5));
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 1, this.mDeviceCheckOrSetPassword));
                                return;
                            }
                        }
                    }
                } else {
                    if ((Integer.parseInt(((String) p21.get(0)), 16) == Integer.parseInt("02", 16)) || ((Integer.parseInt(((String) p21.get(0)), 16) == Integer.parseInt("03", 16)) || (Integer.parseInt(((String) p21.get(0)), 16) == Integer.parseInt("04", 16)))) {
                        int v9_12 = Integer.parseInt(((String) p21.get(4)), 16);
                        this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p21.get(2))).append(((String) p21.get(3))).toString(), 16);
                        com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>response>>>").append(v9_12).toString());
                        if (v9_12 != 0) {
                            com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData>>>response not 0 send again>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>isMessageSuccess>>").append(this.isMessageSuccess).append(">>>mSendDataEnableMap.size()>>>").append(this.mSendDataEnableMap.size()).toString());
                            return;
                        } else {
                            if (this.mSendIndex != (this.mCoolledxTextIconData.size() - 1)) {
                                if ((this.mSendIndex + 1) <= (this.mCoolledxTextIconData.size() - 1)) {
                                    if (this.mSendIndex <= this.mCoolledxTextIconData.size()) {
                                        com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("Progress>>").append(com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolledxTextIconData.size())).toString());
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressEvent(com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mCoolledxTextIconData.size())));
                                    }
                                    this.mSendIndex = (this.mSendIndex + 1);
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>isMessageSuccess>>").append(this.isMessageSuccess).append(">>>mSendDataEnableMap.size()>>>").append(this.mSendDataEnableMap.size()).toString());
                                    this.mMaxRetryTimesForPackage = 3;
                                    void v1_1 = this.clearAllMessages();
                                    v1_1.sendTextIconData(v1_1.mSendIndex).mHandler.sendEmptyMessageDelayed(1002, 5000);
                                    return;
                                }
                            } else {
                                void v1_3 = this.clearAllMessages();
                                if (v1_3.mDeviceIndex != (v1_3.mSendDataEnableMap.size() - 1)) {
                                    if (v1_3.mSendIndex <= v1_3.mCoolledxTextIconData.size()) {
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressEvent(com.jtkj.library.commom.tools.NumberUitls.getPercent((v1_3.mSendIndex + 1), v1_3.mCoolledxTextIconData.size())));
                                    }
                                    if (v1_3.mDeviceIndex < v1_3.mSendDataEnableMap.size()) {
                                        v1_3.mDeviceIndex = (v1_3.mDeviceIndex + 1);
                                        v1_3.mMaxRetryTimesForPackage = 3;
                                        v1_3.mMaxRetryTimesForAll = 3;
                                        v1_3.mSendIndex = 0;
                                        if (v1_3.mCoolledxTextIconData.size() >= 0) {
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressEvent(com.jtkj.library.commom.tools.NumberUitls.getPercent(0, v1_3.mCoolledxTextIconData.size())));
                                        }
                                        com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData to the next device from 0>>>SendIndex>>>").append(v1_3.mSendIndex).append(">>>mDeviceIndex>>>").append(v1_3.mDeviceIndex).append(">>>mSendDataEnableMap.size()>>>").append(v1_3.mSendDataEnableMap.size()).toString());
                                        v1_3 = v1_3.sendTextIconData(v1_3.mSendIndex);
                                        v1_3.mHandler.sendEmptyMessageDelayed(1002, 5000);
                                    }
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData>>>checkResponse send success mSendIndex>>>").append(v1_3.mSendIndex).append("text length>>").append(v1_3.mCoolledxTextIconData.size()).append("isMessageSuccess>>").append(v1_3.isMessageSuccess).toString());
                                    return;
                                } else {
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, "sendingData>>>sendSuccess");
                                    com.jtkj.library.commom.logger.CLog.i(v13_1, new StringBuilder("sendingData>>>sendSuccess>>>mDeviceIndex>>>").append(v1_3.mDeviceIndex).append("mSendDataEnableMap.size()>>>").append(v1_3.mSendDataEnableMap.size()).toString());
                                    v1_3.isMessageSuccess = 1;
                                    if (v1_3.mSendIndex <= v1_3.mCoolledxTextIconData.size()) {
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressEvent(com.jtkj.library.commom.tools.NumberUitls.getPercent((v1_3.mSendIndex + 1), v1_3.mCoolledxTextIconData.size())));
                                    }
                                    v1_3.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$8(v1_3), 1000);
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        } catch (com.jtkj.library.fastble.data.BleDevice v0_132) {
            com.jtkj.led1248.CoolLED.reportError(v0_132);
        }
        return;
    }

    private void checkDeviceUxVersionMoreThan30(String p5)
    {
        String v0_0 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
        if ((v0_0 != 37) && ((v0_0 != 38) && ((v0_0 != 39) && ((v0_0 != 40) && ((v0_0 != 41) && ((v0_0 != 42) && ((v0_0 != 43) && ((v0_0 != 44) && ((v0_0 != 45) && ((v0_0 != 48) && (v0_0 != 49))))))))))) {
            return;
        } else {
            com.jtkj.led1248.light.device.DeviceManager.CoolleduxDeviceVersion = this.getUxDeviceVersion(p5);
            String v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("checkDeviceUxVersionMoreThan30>>>CoolleduxDeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.CoolleduxDeviceVersion).append(">>>mac>>>").append(p5).toString());
            this.UX_PACKAGE_SIZE = this.getUxDevicePackageSize(p5);
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("checkDeviceUxVersionMoreThan30>>>UX_PACKAGE_SIZE>>>").append(this.UX_PACKAGE_SIZE).append(">>>mac>>>").append(p5).toString());
            return;
        }
    }

    private void checkILedClockMessages(java.util.List p24)
    {
        int v6_28;
        int v1_0 = this;
        String v5_18 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkILedClockMessages>>>").append(p24.toString()).toString());
        if (p24.size() < 1) {
            v6_28 = 0;
        } else {
            v6_28 = ((String) p24.get(0));
        }
        if (!android.text.TextUtils.isEmpty(v6_28)) {
            void v9_10 = 16;
            if (Integer.parseInt(v6_28, 16) != Integer.parseInt("1a", 16)) {
                if (Integer.parseInt(v6_28, 16) != Integer.parseInt("14", 16)) {
                    if (Integer.parseInt(v6_28, 16) != Integer.parseInt("19", 16)) {
                        if (Integer.parseInt(v6_28, 16) != Integer.parseInt("15", 16)) {
                            if (Integer.parseInt(v6_28, 16) != Integer.parseInt("16", 16)) {
                                if (Integer.parseInt(v6_28, 16) != Integer.parseInt("0a", 16)) {
                                    if (Integer.parseInt(v6_28, 16) != Integer.parseInt("0b", 16)) {
                                        void v9_49 = this;
                                        if (Integer.parseInt(v6_28, 16) != Integer.parseInt("10", 16)) {
                                            if (Integer.parseInt(v6_28, 16) != Integer.parseInt("0f", 16)) {
                                                if (Integer.parseInt(v6_28, 16) != Integer.parseInt("11", 16)) {
                                                    if (Integer.parseInt(v6_28, 16) != Integer.parseInt("13", 16)) {
                                                        if (Integer.parseInt(v6_28, 16) != Integer.parseInt("09", 16)) {
                                                            if (Integer.parseInt(v6_28, 16) != Integer.parseInt("fd", 16)) {
                                                                if (p24.size() != 5) {
                                                                    if (p24.size() != 2) {
                                                                        if (Integer.parseInt(((String) p24.get(0)), 16) == Integer.parseInt("1f", 16)) {
                                                                            try {
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, "getILedCLockDeviceInfo");
                                                                                int v1_100 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                                com.jtkj.led1248.light.device.ILedClockManager.brightNess = Integer.parseInt(((String) p24.get(2)), 16);
                                                                                com.jtkj.led1248.light.device.ILedClockManager.rotate = Integer.parseInt(((String) p24.get(3)), 16);
                                                                                int v6_22 = Integer.parseInt(((String) p24.get(4)), 16);
                                                                                int v8_16 = Integer.parseInt(((String) p24.get(5)), 16);
                                                                                com.jtkj.led1248.light.device.ILedClockManager.localMicMode = Integer.parseInt(((String) p24.get(6)), 16);
                                                                                int v10_15 = Integer.parseInt(((String) p24.get(7)), 16);
                                                                                com.jtkj.led1248.light.device.ILedClockManager.maxProgramNumber = Integer.parseInt(((String) p24.get(8)), 16);
                                                                                int v11_13 = Integer.parseInt(((String) p24.get(9)), 16);
                                                                                int v12_8 = Integer.parseInt(((String) p24.get(22)), 16);
                                                                                com.jtkj.led1248.light.device.ILedClockManager.volume = Integer.parseInt(((String) p24.get(23)), 16);
                                                                            } catch (com.jtkj.led1248.light.device.DeviceManager$19 v0_249) {
                                                                                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("getILedCLockDeviceInfo>>>Exception e>>>").append(v0_249.getMessage()).toString());
                                                                            }
                                                                            if (p24.size() != 21) {
                                                                                this.ILedClock_PACKAGE_SIZE = 1024;
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getILedCLockDeviceInfo>>>default  ILedClock_PACKAGE_SIZE>>>").append(this.ILedClock_PACKAGE_SIZE).toString());
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.DeviceManager$19 v0_230 = Integer.parseInt(new StringBuilder().append(((String) p24.get(19))).append(((String) p24.get(20))).toString(), 16);
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getILedCLockDeviceInfo>>>new  packageSize>>>").append(v0_230).toString());
                                                                                if (v0_230 == null) {
                                                                                    this.ILedClock_PACKAGE_SIZE = 1024;
                                                                                }
                                                                                if (v0_230 > 4096) {
                                                                                    this.ILedClock_PACKAGE_SIZE = 1024;
                                                                                }
                                                                            }
                                                                            com.jtkj.led1248.light.device.ILedClockManager.maxPackageSize = this.ILedClock_PACKAGE_SIZE;
                                                                            if (v1_100 != 0) {
                                                                                if (v1_100 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff = 0;
                                                                            }
                                                                            if (v6_22 != 0) {
                                                                                if (v6_22 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isLocalMicSupported = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isLocalMicSupported = 0;
                                                                            }
                                                                            if (v8_16 != 0) {
                                                                                if (v8_16 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isLocalMicOnOff = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isLocalMicOnOff = 0;
                                                                            }
                                                                            if (v10_15 != 0) {
                                                                                if (v10_15 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isShowDeviceId = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isShowDeviceId = 0;
                                                                            }
                                                                            if (v11_13 != 0) {
                                                                                if (v10_15 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isRemoteEnable = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isRemoteEnable = 0;
                                                                            }
                                                                            if (v12_8 != 0) {
                                                                                if (v10_15 == 1) {
                                                                                    com.jtkj.led1248.light.device.ILedClockManager.isMute = 1;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.led1248.light.device.ILedClockManager.isMute = 0;
                                                                            }
                                                                            com.jtkj.led1248.CoolLED.getInstance().savePreference("COOLEDU_LOCAL_MIC_SUPPORTED_KEY", Boolean.valueOf(com.jtkj.led1248.light.device.ILedClockManager.isLocalMicSupported));
                                                                            com.jtkj.led1248.light.device.DeviceManager$19 v0_266 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockDeviceInfo();
                                                                            v0_266.isSwitchOnOff = com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff;
                                                                            v0_266.brightNess = com.jtkj.led1248.light.device.ILedClockManager.brightNess;
                                                                            v0_266.rotate = com.jtkj.led1248.light.device.ILedClockManager.rotate;
                                                                            v0_266.isLocalMicSupported = com.jtkj.led1248.light.device.ILedClockManager.isLocalMicSupported;
                                                                            v0_266.isLocalMicOnOff = com.jtkj.led1248.light.device.ILedClockManager.isLocalMicOnOff;
                                                                            v0_266.localMicMode = com.jtkj.led1248.light.device.ILedClockManager.localMicMode;
                                                                            v0_266.isShowDeviceId = com.jtkj.led1248.light.device.ILedClockManager.isShowDeviceId;
                                                                            v0_266.maxProgramNumber = com.jtkj.led1248.light.device.ILedClockManager.maxProgramNumber;
                                                                            v0_266.isRemoteEnable = com.jtkj.led1248.light.device.ILedClockManager.isRemoteEnable;
                                                                            v0_266.isMute = com.jtkj.led1248.light.device.ILedClockManager.isMute;
                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getILedCLockDeviceInfo>>>").append(v0_266).toString());
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.ILedClockManager$ILedClockDeviceInfoEvent(v0_266));
                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.ILedClockManager$ILedClockSynchronizeTimeEvent());
                                                                            com.jtkj.led1248.CoolLED.postDelay(new com.jtkj.led1248.light.device.DeviceManager$19(this), 1000);
                                                                            return;
                                                                        }
                                                                    } else {
                                                                        if ((Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("02", 16)) && (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("1a", 16))) {
                                                                            if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("fe", 16)) {
                                                                                if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("0d", 16)) {
                                                                                    if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("0e", 16)) {
                                                                                        if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("04", 16)) {
                                                                                            int v8_107 = 0;
                                                                                            if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("0c", 16)) {
                                                                                                if (Integer.parseInt(((String) p24.get(0)), 16) == Integer.parseInt("05", 16)) {
                                                                                                    boolean v2_251 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                                                    if (v2_251) {
                                                                                                        if (v2_251 == 1) {
                                                                                                            com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff = 1;
                                                                                                        }
                                                                                                    } else {
                                                                                                        com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff = 0;
                                                                                                    }
                                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getILedClockdeviceInfo>>>isSwitchOnOff>>>").append(com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff).toString());
                                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.ILedClockManager$ILedClockSwitchInfo(com.jtkj.led1248.light.device.ILedClockManager.isSwitchOnOff));
                                                                                                    v8_107 = 0;
                                                                                                }
                                                                                            } else {
                                                                                                boolean v2_257 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                                                if (v2_257) {
                                                                                                    if (v2_257 == 1) {
                                                                                                        com.jtkj.led1248.light.device.DeviceManager.isMirror = 1;
                                                                                                    }
                                                                                                } else {
                                                                                                    com.jtkj.led1248.light.device.DeviceManager.isMirror = 0;
                                                                                                }
                                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("isMirror>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMirror).toString());
                                                                                            }
                                                                                        } else {
                                                                                            com.jtkj.led1248.light.device.ILedClockManager.brightNess = Integer.parseInt(((String) p24.get(1)), 16);
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder(" ILedClockManager.brightNess>>>").append(com.jtkj.led1248.light.device.ILedClockManager.brightNess).toString());
                                                                                        }
                                                                                    } else {
                                                                                        if (Integer.parseInt(((String) p24.get(1)), 16) != 0) {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>SetILedClockDevicePassword>>failure>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                                                                            v8_107 = 0;
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(0, this.mDeviceCheckOrSetPassword));
                                                                                        } else {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>SetILedClockDevicePassword>>success>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>password>>>").append(this.mPasswordToSet).toString());
                                                                                            com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToSet);
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$SetPasswordResponseEvent(1, this.mDeviceCheckOrSetPassword));
                                                                                        }
                                                                                    }
                                                                                } else {
                                                                                    if (Integer.parseInt(((String) p24.get(1)), 16) != 0) {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_FAILURE_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>CheckILedClockDevicePassword>>failure>>>password>>>").append(this.mPasswordToCheck).toString());
                                                                                        int v1_349 = this.mCheckPasswordKind;
                                                                                        if (v1_349 != 2) {
                                                                                            if (v1_349 != 1) {
                                                                                            } else {
                                                                                                int v1_350 = this.mCheckPasswordTimes;
                                                                                                if (v1_350 < 3) {
                                                                                                    this.mCheckPasswordTimes = (v1_350 + 1);
                                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                                                                                    this.checkPassWordAfterConnectSuccess(this.mDeviceCheckOrSetPassword);
                                                                                                } else {
                                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>CHECK_PASSWORD_AFTER_CONNECT>>>mCheckPasswordTimes>>").append(this.mCheckPasswordTimes).toString());
                                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "checkPassword>>>CHECK_PASSWORD_AFTER_INPUT_PASSWORD>>");
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 6));
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 0, this.mDeviceCheckOrSetPassword));
                                                                                        }
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>connectDevice>>>PASSWORD_VERIFY_SUCCESS_RESPONSE>>>addresses>>>").append(this.mDeviceCheckOrSetPassword.getMac()).append(">>>name>>> ").append(this.mDeviceCheckOrSetPassword.getName()).append(" >>>id>>>").append(com.jtkj.led1248.light.device.DeviceManager.getDeviceId(this.mDeviceCheckOrSetPassword)).toString());
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("checkPassword>>>CheckILedClockDevicePassword>>success>>>password>>>").append(this.mPasswordToCheck).toString());
                                                                                        this.mVerifyPasswordMap.put(this.mDeviceCheckOrSetPassword.getMac(), Boolean.valueOf(1));
                                                                                        com.jtkj.led1248.CoolLED.getInstance().savePreference(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString(), this.mPasswordToCheck);
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$BleDeviceConnectEvent(this.mDeviceCheckOrSetPassword, 5));
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordResponseEvent(this.mCheckPasswordKind, 1, this.mDeviceCheckOrSetPassword));
                                                                                        v9_49.updateDeviceInfo(v9_49.mDeviceCheckOrSetPassword);
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                if (Integer.parseInt(((String) p24.get(1)), 16) != 0) {
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("response == 0>>>send startILedClockProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                                    this.mMaxRetryTimesForAll = 3;
                                                                                    void v9_47 = this.clearAllMessages();
                                                                                    v9_47.sendILedClockOtaUpgradeData(v9_47.mSendIndex).mHandler.sendEmptyMessageDelayed(1005, 5000);
                                                                                }
                                                                            }
                                                                        } else {
                                                                            boolean v2_331 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                            if (v2_331) {
                                                                                if (v2_331 != 1) {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("results.size() == 2>>>response ==").append(v2_331).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("response == 1>>>sendILedClockProgramData>>>(response == 1 no need send from package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(this.mILedClockProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                                    if (this.mILedClockProgramIndex != (this.mILedClockProgramCount - 1)) {
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockProgramData.size(), this.mILedClockProgramData.size())));
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "mILedClockProgramIndex /= (mILedClockProgramCount - 1)>>>sendNextProgramData");
                                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                                        this.mMaxRetryTimesForAll = 3;
                                                                                        void v9_50 = this.clearAllMessages();
                                                                                        v9_50.mSendIndex = 0;
                                                                                        v9_50.mILedClockProgramIndex = (v9_50.mILedClockProgramIndex + 1);
                                                                                        v9_50.isMessageSuccess = 0;
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("sendingData from next program>>>SendIndex>>>").append(v9_50.mSendIndex).append(">>>mDeviceIndex>>>").append(v9_50.mDeviceIndex).append(">>>mSendDataEnableMap.size()>>>").append(v9_50.mSendDataEnableMap.size()).toString());
                                                                                        v9_50.sendILedClockStartSendProgramData(v9_50.mILedClockProgramList, v9_50.mILedClockProgramIndex, v9_50.mILedClockProgramCount);
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "send ILedClock start send program success to the last program mILedClockProgramIndex == (mILedClockProgramCount - 1)(response == 1)");
                                                                                        if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "send to not the last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))>>>(response == 1)");
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockProgramData.size(), this.mILedClockProgramData.size())));
                                                                                            this.mMaxRetryTimesForPackage = 3;
                                                                                            this.mMaxRetryTimesForAll = 3;
                                                                                            void v9_51 = this.clearAllMessages();
                                                                                            v9_51.mDeviceIndex = (v9_51.mDeviceIndex + 1);
                                                                                            v9_51.mILedClockProgramIndex = 0;
                                                                                            v9_51.mSendIndex = 0;
                                                                                            v9_51.isMessageSuccess = 0;
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("sendingData to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v9_51.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(v9_51.mILedClockProgramIndex).append(">>> mDeviceIndex>>").append(v9_51.mDeviceIndex).toString());
                                                                                            v9_51.sendILedClockStartSendProgramData(v9_51.mILedClockProgramList, v9_51.mILedClockProgramIndex, v9_51.mILedClockProgramCount);
                                                                                        } else {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "send  to the last device success (mDeviceIndex == (mSendDataEnableMap.size() - 1))(response == 1)");
                                                                                            void v9_52 = this.clearAllMessages();
                                                                                            v9_52.isMessageSuccess = 1;
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((v9_52.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(v9_52.mILedClockProgramData.size(), v9_52.mILedClockProgramData.size())));
                                                                                            v9_52.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$18(v9_52), 1000);
                                                                                        }
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("response == 0>>>send startILedClockProgramData>>>(response == 0need send from 0 package)>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(this.mILedClockProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                                this.mMaxRetryTimesForPackage = 3;
                                                                                this.mMaxRetryTimesForAll = 3;
                                                                                void v9_53 = this.clearAllMessages();
                                                                                v9_53.sendILedClockProgramData(v9_53.mSendIndex).mHandler.sendEmptyMessageDelayed(1004, 5000);
                                                                            }
                                                                        }
                                                                        if ((Integer.parseInt(((String) p24.get(v8_107)), 16) != Integer.parseInt("0c", 16)) && (Integer.parseInt(((String) p24.get(v8_107)), 16) != Integer.parseInt("1c", 16))) {
                                                                            if (Integer.parseInt(((String) p24.get(v8_107)), 16) == Integer.parseInt("09", 16)) {
                                                                                com.jtkj.led1248.light.device.DeviceManager$19 v0_3 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder(">>>ILedClockManager. synchronizeTimeResult>>>").append(v0_3).toString());
                                                                                if (v0_3 != null) {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, ">>>ILedClockManager. synchronizeTimeResult>>>failure");
                                                                                    return;
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, ">>>ILedClockManager. synchronizeTimeResult>>>success");
                                                                                    return;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            com.jtkj.led1248.light.device.ILedClockManager.rotate = Integer.parseInt(((String) p24.get(1)), 16);
                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getILedCLockdeviceInfo>>>ILedClockManager.rotate>>>").append(com.jtkj.led1248.light.device.ILedClockManager.rotate).toString());
                                                                            return;
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (Integer.parseInt(((String) p24.get(0)), 16) != Integer.parseInt("03", 16)) {
                                                                        if (Integer.parseInt(((String) p24.get(0)), 16) == Integer.parseInt("ff", 16)) {
                                                                            boolean v2_11 = Integer.parseInt(((String) p24.get(4)), 16);
                                                                            this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("OTAresponse>>>").append(v2_11).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                                                                            if (v2_11) {
                                                                                if (v2_11 != 1) {
                                                                                    if (v2_11 != 2) {
                                                                                        if (v2_11 != 3) {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("OTAresponse ==").append(v2_11).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                                                                            return;
                                                                                        } else {
                                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "OTAresponse == 3>>>DATA_ERROR");
                                                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                                            return;
                                                                                        }
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "OTAresponse == 2>>>DEVICE_ERROR");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                                                                                        return;
                                                                                    }
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, "OTAresponse == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForILedClock>>>1");
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                                                                                    return;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mILedClockOTAUpgradeData.size()>>>").append(this.mILedClockOTAUpgradeData.size()).toString());
                                                                                if (this.mSendIndex != (this.mILedClockOTAUpgradeData.size() - 1)) {
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mILedClockOTAUpgradeData.size())));
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                                    this.mMaxRetryTimesForAll = 3;
                                                                                    void v9_0 = this.clearAllMessages();
                                                                                    com.jtkj.led1248.light.device.DeviceManager$19 v0_56 = (v9_0.mSendIndex + 1);
                                                                                    v9_0.mSendIndex = v0_56;
                                                                                    v9_0.sendILedClockOtaUpgradeData(v0_56).mHandler.sendEmptyMessageDelayed(1006, 5000);
                                                                                    return;
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("send data to the last package success>>>(mSendIndex == (mILedClockOTAUpgradeData.size() - 1))>>").append((this.mILedClockOTAUpgradeData.size() - 1)).toString());
                                                                                    if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockOTAUpgradeData.size(), this.mILedClockOTAUpgradeData.size())));
                                                                                        this.isMessageSuccess = 1;
                                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                                        this.mMaxRetryTimesForAll = 3;
                                                                                        void v9_2 = this.clearAllMessages();
                                                                                        v9_2.mDeviceIndex = (v9_2.mDeviceIndex + 1);
                                                                                        v9_2.mSendIndex = 0;
                                                                                        v9_2.isMessageSuccess = 0;
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("send data to the next device from 0 package>>>mSendIndex>>> ").append(v9_2.mSendIndex).append(">>> mDeviceIndex>>").append(v9_2.mDeviceIndex).toString());
                                                                                        v9_2.sendILedClockStartSendOTAUpgradeData();
                                                                                        return;
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent(0, com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockOTAUpgradeData.size(), this.mILedClockOTAUpgradeData.size())));
                                                                                        void v9_3 = this.clearAllMessages();
                                                                                        v9_3.isMessageSuccess = 1;
                                                                                        v9_3.mDeviceIndex = 0;
                                                                                        v9_3.mSendIndex = 0;
                                                                                        v9_3.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$17(v9_3), 1000);
                                                                                        return;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    } else {
                                                                        boolean v2_22 = Integer.parseInt(((String) p24.get(4)), 16);
                                                                        this.mSendIndex = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("response>>>").append(v2_22).append(">>>mSendIndex>>>").append(this.mSendIndex).toString());
                                                                        if (v2_22) {
                                                                            if (v2_22 != 1) {
                                                                                if (v2_22 != 2) {
                                                                                    if (v2_22 != 3) {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("response ==").append(v2_22).append(">>>DEVICE_SEND_UNKNOWN_ERROR").toString());
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(7));
                                                                                        return;
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "response == 3>>>DATA_ERROR");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                                                                                        return;
                                                                                    }
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, "response == 2>>>DEVICE_ERROR");
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(6));
                                                                                    return;
                                                                                }
                                                                            } else {
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, "response == 1>>>DEVICE_SEND_SEND_ERROR>>>checkRetryTimesSendProgramDataForILedClock>>>1");
                                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(5));
                                                                                return;
                                                                            }
                                                                        } else {
                                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("mSendIndex>>>").append(this.mSendIndex).append(">>>mILedClockProgramData.size()>>>").append(this.mILedClockProgramData.size()).append(">>>mILedClockProgramIndex>>>").append(this.mILedClockProgramIndex).append(">>>mILedClockProgramCount>>>").append(this.mILedClockProgramCount).toString());
                                                                            if (this.mSendIndex != (this.mILedClockProgramData.size() - 1)) {
                                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent((this.mSendIndex + 1), this.mILedClockProgramData.size())));
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("sendingData>>>continue to send from the next package>>>mSendIndex>>>").append(this.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(this.mILedClockProgramIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                                                                                this.mMaxRetryTimesForPackage = 3;
                                                                                this.mMaxRetryTimesForAll = 3;
                                                                                void v9_4 = this.clearAllMessages();
                                                                                com.jtkj.led1248.light.device.DeviceManager$19 v0_127 = (v9_4.mSendIndex + 1);
                                                                                v9_4.mSendIndex = v0_127;
                                                                                v9_4.sendILedClockProgramData(v0_127).mHandler.sendEmptyMessageDelayed(1004, 5000);
                                                                                return;
                                                                            } else {
                                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("send data to the last package success>>>(mSendIndex == (mILedClockProgramData.size() - 1))>>").append((this.mILedClockProgramData.size() - 1)).toString());
                                                                                if (this.mILedClockProgramIndex != (this.mILedClockProgramCount - 1)) {
                                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockProgramData.size(), this.mILedClockProgramData.size())));
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, "send data to  not  the last program (mILedClockProgramIndex /= (mILedClockProgramCount - 1)))");
                                                                                    this.mMaxRetryTimesForPackage = 3;
                                                                                    this.mMaxRetryTimesForAll = 3;
                                                                                    void v9_6 = this.clearAllMessages();
                                                                                    v9_6.mILedClockProgramIndex = (v9_6.mILedClockProgramIndex + 1);
                                                                                    v9_6.mSendIndex = 0;
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("sendingData to the next program from 0package>>>mSendIndex>>> ").append(v9_6.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(v9_6.mILedClockProgramIndex).append(">>> mDeviceIndex>>").append(v9_6.mDeviceIndex).toString());
                                                                                    v9_6.sendILedClockStartSendProgramData(v9_6.mILedClockProgramList, v9_6.mILedClockProgramIndex, v9_6.mILedClockProgramCount);
                                                                                    return;
                                                                                } else {
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("send last package to the last program (mILedClockProgramIndex == (mILedClockProgramCount - 1)>>>mILedClockProgramIndex>>>").append(this.mILedClockProgramIndex).append(">>>mILedClockProgramCount>>>").append(this.mILedClockProgramCount).toString());
                                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("mDeviceIndex>>>").append(this.mDeviceIndex).append(">>>deviceSize>>>").append(this.mSendDataEnableMap.size()).toString());
                                                                                    if (this.mDeviceIndex != (this.mSendDataEnableMap.size() - 1)) {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "send to not the  last device (mDeviceIndex /= (mSendDataEnableMap.size() - 1))");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockProgramData.size(), this.mILedClockProgramData.size())));
                                                                                        this.isMessageSuccess = 1;
                                                                                        this.mMaxRetryTimesForPackage = 3;
                                                                                        this.mMaxRetryTimesForAll = 3;
                                                                                        void v9_7 = this.clearAllMessages();
                                                                                        v9_7.mDeviceIndex = (v9_7.mDeviceIndex + 1);
                                                                                        v9_7.mILedClockProgramIndex = 0;
                                                                                        v9_7.mSendIndex = 0;
                                                                                        v9_7.isMessageSuccess = 0;
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("send data to the next device from 0 program and 0 package>>>mSendIndex>>> ").append(v9_7.mSendIndex).append(">>>mILedClockProgramIndex>>>").append(v9_7.mILedClockProgramIndex).append(">>> mDeviceIndex>>").append(v9_7.mDeviceIndex).toString());
                                                                                        v9_7.sendILedClockStartSendProgramData(v9_7.mILedClockProgramList, v9_7.mILedClockProgramIndex, v9_7.mILedClockProgramCount);
                                                                                        return;
                                                                                    } else {
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "send to the last  device>>>(mDeviceIndex == (mSendDataEnableMap.size() - 1))");
                                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressCoolLEDEvent((this.mILedClockProgramIndex + 1), com.jtkj.library.commom.tools.NumberUitls.getPercent(this.mILedClockProgramData.size(), this.mILedClockProgramData.size())));
                                                                                        void v9_8 = this.clearAllMessages();
                                                                                        v9_8.isMessageSuccess = 1;
                                                                                        v9_8.mDeviceIndex = 0;
                                                                                        v9_8.mILedClockProgramIndex = 0;
                                                                                        v9_8.mSendIndex = 0;
                                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "onEvent>>>checktime2");
                                                                                        v9_8.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$16(v9_8), 1000);
                                                                                        return;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                int v1_126 = Integer.parseInt(((String) p24.get(1)), 16);
                                                                if (v1_126 != 0) {
                                                                    if (v1_126 == 1) {
                                                                        com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported = 1;
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("get ota info>>> response>>>otaFlag>>").append(v1_126).append(">>>isILedClockHardwareUpdateSupported>>>").append(com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported).toString());
                                                                        com.jtkj.led1248.light.device.DeviceManager.ILedClockLocalOTAVersion = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("get ota info>>> response>>>ILedClockLocalOTAVersion>>").append(com.jtkj.led1248.light.device.DeviceManager.ILedClockLocalOTAVersion).toString());
                                                                        int v1_143 = Integer.parseInt(((String) p24.get(4)), 16);
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("get ota info>>> response>>>fileNameLength>>").append(v1_143).toString());
                                                                        com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME = "";
                                                                        boolean v2_56 = 5;
                                                                        while (v2_56 < (v1_143 + 5)) {
                                                                            com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME = new StringBuilder().append(com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME).append(((char) Integer.parseInt(((String) p24.get(v2_56)), 16))).toString();
                                                                            v2_56++;
                                                                        }
                                                                        com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME = com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME.trim();
                                                                        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("get ota info>>> response>>>ILedClock_REMOTE_OTA_FILE_NAME>>").append(com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME).toString());
                                                                        com.jtkj.led1248.base.OkHttpUtils.getInstance().checkRemoteOtaInfo(com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME);
                                                                        return;
                                                                    }
                                                                } else {
                                                                    com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported = 0;
                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("get ota info>>> response>>>otaFlag>>").append(v1_126).append(">>>isILedClockHardwareUpdateSupported>>>").append(com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported).toString());
                                                                    return;
                                                                }
                                                            }
                                                        } else {
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("ILedClock syncTime response>>>action>>").append(((String) p24.get(0))).append(">>>ack>>>").append(((String) p24.get(1))).toString());
                                                            return;
                                                        }
                                                    } else {
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("ILedClock color response>>>action>>").append(((String) p24.get(1))).append(">>>ack>>>").append(((String) p24.get(2))).toString());
                                                        return;
                                                    }
                                                } else {
                                                    if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("01", 16)) {
                                                        if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("02", 16)) {
                                                            if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("03", 16)) {
                                                                if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("04", 16)) {
                                                                    if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("05", 16)) {
                                                                        int v8_22;
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "scoreBoard>>>value>>>05>>>finished");
                                                                        int v1_175 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEventResponse();
                                                                        boolean v2_81 = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                                                                        Boolean v3_46 = Integer.parseInt(new StringBuilder().append(((String) p24.get(4))).append(((String) p24.get(5))).toString(), 16);
                                                                        int v4_19 = Integer.parseInt(((String) p24.get(6)), 16);
                                                                        int v6_26 = Integer.parseInt(((String) p24.get(7)), 16);
                                                                        int v8_21 = Integer.parseInt(((String) p24.get(8)), 16);
                                                                        int v10_19 = Integer.parseInt(((String) p24.get(9)), 16);
                                                                        int v11_6 = Integer.parseInt(((String) p24.get(10)), 16);
                                                                        int v12_4 = Integer.parseInt(((String) p24.get(11)), 16);
                                                                        int v13_6 = Integer.parseInt(((String) p24.get(12)), 16);
                                                                        com.jtkj.led1248.light.device.DeviceManager$19 v0_200 = Integer.parseInt(((String) p24.get(13)), 16);
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>hostScoreValue>>>").append(v2_81).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>visitScoreValue>>>").append(v3_46).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>hostTotalScoreValue>>>").append(v4_19).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>visitTotalScoreValue>>>").append(v6_26).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>deviceMinuteValue>>>").append(v8_21).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>deviceSecondsValue>>>").append(v10_19).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>statusValue>>>").append(v11_6).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>setMinuteValue>>>").append(v12_4).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>setSecondsValue>>>").append(v13_6).toString());
                                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>timeModeValue>>>").append(v0_200).toString());
                                                                        v1_175.hostScore = v2_81;
                                                                        v1_175.visitScore = v3_46;
                                                                        v1_175.hostTotalScore = v4_19;
                                                                        v1_175.visitTotalScore = v6_26;
                                                                        v1_175.deviceMinute = v8_21;
                                                                        v1_175.deviceSeconds = v10_19;
                                                                        if (v11_6 != 1) {
                                                                            v8_22 = 0;
                                                                            v1_175.isStartOrStop = 0;
                                                                        } else {
                                                                            v1_175.isStartOrStop = 1;
                                                                            v8_22 = 0;
                                                                        }
                                                                        v1_175.setMinute = v12_4;
                                                                        v1_175.setSeconds = v13_6;
                                                                        if (v0_200 != 1) {
                                                                            v1_175.isCountDown = v8_22;
                                                                        } else {
                                                                            v1_175.isCountDown = 1;
                                                                        }
                                                                        v1_175.actionType = 5;
                                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_175);
                                                                        return;
                                                                    }
                                                                } else {
                                                                    int v1_177 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEventResponse();
                                                                    com.jtkj.led1248.light.device.DeviceManager$19 v0_203 = Integer.parseInt(((String) p24.get(2)), 16);
                                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>value>>>").append(v0_203).toString());
                                                                    if (v0_203 != null) {
                                                                        v1_177.response = 0;
                                                                    } else {
                                                                        v1_177.response = 1;
                                                                    }
                                                                    v1_177.actionType = 4;
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_177);
                                                                    return;
                                                                }
                                                            } else {
                                                                int v1_179 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEventResponse();
                                                                com.jtkj.led1248.light.device.DeviceManager$19 v0_206 = Integer.parseInt(((String) p24.get(2)), 16);
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>value>>>").append(v0_206).toString());
                                                                if (v0_206 != null) {
                                                                    v1_179.response = 0;
                                                                } else {
                                                                    v1_179.response = 1;
                                                                }
                                                                v1_179.actionType = 3;
                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_179);
                                                                return;
                                                            }
                                                        } else {
                                                            int v1_181 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEventResponse();
                                                            com.jtkj.led1248.light.device.DeviceManager$19 v0_209 = Integer.parseInt(((String) p24.get(2)), 16);
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>value>>>").append(v0_209).toString());
                                                            if (v0_209 != null) {
                                                                v1_181.response = 0;
                                                            } else {
                                                                v1_181.response = 1;
                                                            }
                                                            v1_181.actionType = 2;
                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_181);
                                                            return;
                                                        }
                                                    } else {
                                                        int v8_30;
                                                        int v1_183 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEventResponse();
                                                        boolean v2_103 = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                                                        Boolean v3_61 = Integer.parseInt(new StringBuilder().append(((String) p24.get(4))).append(((String) p24.get(5))).toString(), 16);
                                                        int v4_28 = Integer.parseInt(((String) p24.get(6)), 16);
                                                        int v6_32 = Integer.parseInt(((String) p24.get(7)), 16);
                                                        int v8_29 = Integer.parseInt(((String) p24.get(8)), 16);
                                                        int v10_23 = Integer.parseInt(((String) p24.get(9)), 16);
                                                        int v11_18 = Integer.parseInt(((String) p24.get(10)), 16);
                                                        int v12_12 = Integer.parseInt(((String) p24.get(11)), 16);
                                                        int v13_16 = Integer.parseInt(((String) p24.get(12)), 16);
                                                        com.jtkj.led1248.light.device.DeviceManager$19 v0_212 = Integer.parseInt(((String) p24.get(13)), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>hostScoreValue>>>").append(v2_103).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>visitScoreValue>>>").append(v3_61).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>hostTotalScoreValue>>>").append(v4_28).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>visitTotalScoreValue>>>").append(v6_32).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>deviceMinuteValue>>>").append(v8_29).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>deviceSecondsValue>>>").append(v10_23).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>statusValue>>>").append(v11_18).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>setMinuteValue>>>").append(v12_12).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>setSecondsValue>>>").append(v13_16).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("scoreBoard>>>timeModeValue>>>").append(v0_212).toString());
                                                        v1_183.hostScore = v2_103;
                                                        v1_183.visitScore = v3_61;
                                                        v1_183.hostTotalScore = v4_28;
                                                        v1_183.visitTotalScore = v6_32;
                                                        v1_183.deviceMinute = v8_29;
                                                        v1_183.deviceSeconds = v10_23;
                                                        if (v11_18 != 1) {
                                                            v8_30 = 0;
                                                            v1_183.isStartOrStop = 0;
                                                        } else {
                                                            v1_183.isStartOrStop = 1;
                                                            v8_30 = 0;
                                                        }
                                                        v1_183.setMinute = v12_12;
                                                        v1_183.setSeconds = v13_16;
                                                        if (v0_212 != 1) {
                                                            v1_183.isCountDown = v8_30;
                                                        } else {
                                                            v1_183.isCountDown = 1;
                                                        }
                                                        v1_183.actionType = 1;
                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_183);
                                                        return;
                                                    }
                                                }
                                            } else {
                                                if (p24.size() != 3) {
                                                    if (p24.size() == 9) {
                                                        if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("01", 16)) {
                                                            if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("03", 16)) {
                                                                if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("04", 16)) {
                                                                    com.jtkj.led1248.light.device.DeviceManager$19 v0_222 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockCountDownEventResponse();
                                                                    v0_222.actionType = 4;
                                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v0_222);
                                                                    return;
                                                                }
                                                            } else {
                                                                int v1_195 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockCountDownEventResponse();
                                                                boolean v2_109 = Integer.parseInt(((String) p24.get(2)), 16);
                                                                Boolean v3_65 = Integer.parseInt(((String) p24.get(3)), 16);
                                                                int v4_37 = Integer.parseInt(((String) p24.get(4)), 16);
                                                                int v6_37 = Integer.parseInt(((String) p24.get(5)), 16);
                                                                int v8_34 = Integer.parseInt(((String) p24.get(6)), 16);
                                                                int v10_27 = Integer.parseInt(((String) p24.get(7)), 16);
                                                                com.jtkj.led1248.light.device.DeviceManager$19 v0_225 = Integer.parseInt(((String) p24.get(8)), 16);
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>statusValue>>>").append(v2_109).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setHourValue>>>").append(v3_65).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setMinuteValue>>>").append(v4_37).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setSecondsValue>>>").append(v6_37).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftHourValue>>>").append(v8_34).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftMinuteValue>>>").append(v10_27).toString());
                                                                com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftSecondsValue>>>").append(v0_225).toString());
                                                                v1_195.setHour = v3_65;
                                                                v1_195.setMinute = v4_37;
                                                                v1_195.setSeconds = v6_37;
                                                                v1_195.leftHour = v8_34;
                                                                v1_195.leftMinute = v10_27;
                                                                v1_195.leftSeconds = v0_225;
                                                                if (v2_109 != 1) {
                                                                    v1_195.isStartOrStop = 0;
                                                                } else {
                                                                    v1_195.isStartOrStop = 1;
                                                                }
                                                                v1_195.actionType = 3;
                                                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_195);
                                                                return;
                                                            }
                                                        } else {
                                                            int v1_197 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockCountDownEventResponse();
                                                            boolean v2_113 = Integer.parseInt(((String) p24.get(2)), 16);
                                                            Boolean v3_70 = Integer.parseInt(((String) p24.get(3)), 16);
                                                            int v4_42 = Integer.parseInt(((String) p24.get(4)), 16);
                                                            int v6_41 = Integer.parseInt(((String) p24.get(5)), 16);
                                                            int v8_39 = Integer.parseInt(((String) p24.get(6)), 16);
                                                            int v10_31 = Integer.parseInt(((String) p24.get(7)), 16);
                                                            com.jtkj.led1248.light.device.DeviceManager$19 v0_233 = Integer.parseInt(((String) p24.get(8)), 16);
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>statusValue>>>").append(v2_113).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setHourValue>>>").append(v3_70).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setMinuteValue>>>").append(v4_42).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>setSecondsValue>>>").append(v6_41).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftHourValue>>>").append(v8_39).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftMinuteValue>>>").append(v10_31).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>leftSecondsValue>>>").append(v0_233).toString());
                                                            v1_197.setHour = v3_70;
                                                            v1_197.setMinute = v4_42;
                                                            v1_197.setSeconds = v6_41;
                                                            v1_197.leftHour = v8_39;
                                                            v1_197.leftMinute = v10_31;
                                                            v1_197.leftSeconds = v0_233;
                                                            if (v2_113 != 1) {
                                                                v1_197.isStartOrStop = 0;
                                                            } else {
                                                                v1_197.isStartOrStop = 1;
                                                            }
                                                            v1_197.actionType = 1;
                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_197);
                                                            return;
                                                        }
                                                    }
                                                } else {
                                                    if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("02", 16)) {
                                                        com.jtkj.led1248.light.device.DeviceManager$19 v0_236 = Integer.parseInt(((String) p24.get(2)), 16);
                                                        int v1_202 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockCountDownEventResponse();
                                                        v1_202.actionType = 2;
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("coutdown>>>value>>>").append(v0_236).toString());
                                                        if (v0_236 != null) {
                                                            v1_202.response = 0;
                                                        } else {
                                                            v1_202.response = 1;
                                                        }
                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_202);
                                                        return;
                                                    }
                                                }
                                            }
                                        } else {
                                            if (p24.size() != 3) {
                                                if (p24.size() == 6) {
                                                    if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("01", 16)) {
                                                        if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("03", 16)) {
                                                            int v1_212 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockStopWatchEventResponse();
                                                            boolean v2_127 = Integer.parseInt(((String) p24.get(2)), 16);
                                                            Boolean v3_77 = Integer.parseInt(((String) p24.get(3)), 16);
                                                            int v4_50 = Integer.parseInt(((String) p24.get(4)), 16);
                                                            com.jtkj.led1248.light.device.DeviceManager$19 v0_241 = Integer.parseInt(((String) p24.get(5)), 16);
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>statusValue>>>").append(v2_127).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>hourValue>>>").append(v3_77).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>minuteValue>>>").append(v4_50).toString());
                                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>secondsValue>>>").append(v0_241).toString());
                                                            v1_212.hour = v3_77;
                                                            v1_212.minute = v4_50;
                                                            v1_212.seconds = v0_241;
                                                            if (v2_127 != 1) {
                                                                v1_212.isStartOrStop = 0;
                                                            } else {
                                                                v1_212.isStartOrStop = 1;
                                                            }
                                                            v1_212.actionType = 3;
                                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_212);
                                                            return;
                                                        }
                                                    } else {
                                                        int v1_214 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockStopWatchEventResponse();
                                                        boolean v2_131 = Integer.parseInt(((String) p24.get(2)), 16);
                                                        Boolean v3_81 = Integer.parseInt(((String) p24.get(3)), 16);
                                                        int v4_54 = Integer.parseInt(((String) p24.get(4)), 16);
                                                        com.jtkj.led1248.light.device.DeviceManager$19 v0_244 = Integer.parseInt(((String) p24.get(5)), 16);
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>statusValue>>>").append(v2_131).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>hourValue>>>").append(v3_81).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>minuteValue>>>").append(v4_54).toString());
                                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>secondsValue>>>").append(v0_244).toString());
                                                        v1_214.hour = v3_81;
                                                        v1_214.minute = v4_54;
                                                        v1_214.seconds = v0_244;
                                                        if (v2_131 != 1) {
                                                            v1_214.isStartOrStop = 0;
                                                        } else {
                                                            v1_214.isStartOrStop = 1;
                                                        }
                                                        v1_214.actionType = 1;
                                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_214);
                                                        return;
                                                    }
                                                }
                                            } else {
                                                if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("02", 16)) {
                                                    com.jtkj.led1248.light.device.DeviceManager$19 v0_247 = Integer.parseInt(((String) p24.get(2)), 16);
                                                    boolean v2_136 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockStopWatchEventResponse();
                                                    v2_136.actionType = 2;
                                                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("stopwatch>>>value>>>").append(v0_247).toString());
                                                    if (v0_247 != null) {
                                                        v2_136.response = 0;
                                                    } else {
                                                        v2_136.response = 1;
                                                    }
                                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v2_136);
                                                    return;
                                                }
                                            }
                                        }
                                    } else {
                                        int v1_223 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTimerSwitchEventResponse();
                                        boolean v2_139 = Integer.parseInt(((String) p24.get(1)), 16);
                                        if (v2_139) {
                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "getTimerSwitch  number>>>0");
                                        } else {
                                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getTimerSwitch  number>>>").append(v2_139).toString());
                                            Boolean v3_88 = new java.util.ArrayList();
                                            int v4_56 = 0;
                                            while (v4_56 < v2_139) {
                                                int v7_213;
                                                int v8_70;
                                                String v5_2 = new com.jtkj.led1248.light.device.DeviceManager$TimerSwitchItem();
                                                int v6_76 = (v4_56 * 6);
                                                int v7_211 = Integer.parseInt(((String) p24.get((v6_76 + 2))), 16);
                                                void v9_15 = Integer.parseInt(((String) p24.get((v6_76 + 3))), 16);
                                                int v10_35 = Integer.parseInt(((String) p24.get((v6_76 + 4))), 16);
                                                int v11_38 = Integer.parseInt(((String) p24.get((v6_76 + 5))), 16);
                                                int v12_16 = Integer.parseInt(((String) p24.get((v6_76 + 6))), 16);
                                                Integer.parseInt(((String) p24.get((v6_76 + 7))), 16);
                                                int v6_80 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  enableValue>>>").append(v7_211).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  hourValue>>>").append(v9_15).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  minuteValue>>>").append(v10_35).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  repeatValue>>>").append(v11_38).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  switchValue>>>").append(v12_16).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  actionValue>>>").append(v12_16).toString());
                                                if (v7_211 != 0) {
                                                    v7_213 = 1;
                                                    v8_70 = 0;
                                                    v5_2.enable = 1;
                                                    com.jtkj.library.commom.logger.CLog.i(v6_80, "getTimerSwitch  enable>>>true");
                                                } else {
                                                    v8_70 = 0;
                                                    v5_2.enable = 0;
                                                    com.jtkj.library.commom.logger.CLog.i(v6_80, "getTimerSwitch  enable>>>false");
                                                    v7_213 = 1;
                                                }
                                                v5_2.hour = v9_15;
                                                v5_2.minute = v10_35;
                                                if (v12_16 != 0) {
                                                    v5_2.isSetDeviceOn = v7_213;
                                                    com.jtkj.library.commom.logger.CLog.i(v6_80, "getTimerSwitch  isSetDeviceOn>>>true");
                                                } else {
                                                    v5_2.isSetDeviceOn = v8_70;
                                                    com.jtkj.library.commom.logger.CLog.i(v6_80, "getTimerSwitch  isSetDeviceOn>>>false");
                                                }
                                                int v10_36 = this.getBit(v11_38, v8_70);
                                                int v8_71 = this.getBit(v11_38, v7_213);
                                                int v12_17 = this.getBit(v11_38, 2);
                                                int v13_24 = this.getBit(v11_38, 3);
                                                String v14_22 = this.getBit(v11_38, 4);
                                                int v15_1 = this.getBit(v11_38, 5);
                                                int v11_39 = this.getBit(v11_38, 6);
                                                String v17_0 = v2_139;
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  monValue>>>").append(v10_36).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  tueValue>>>").append(v8_71).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  wedValue>>>").append(v12_17).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  thurValue>>>").append(v13_24).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  friValue>>>").append(v14_22).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  satValue>>>").append(v15_1).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  sunValue>>>").append(v11_39).toString());
                                                v5_2.isMondayOn = v10_36;
                                                v5_2.isTuesdayOn = v8_71;
                                                v5_2.isWednesdayOn = v12_17;
                                                v5_2.isThursdayOn = v13_24;
                                                v5_2.isFridayOn = v14_22;
                                                v5_2.isSaturdayOn = v15_1;
                                                v5_2.isSundayOn = v11_39;
                                                if ((v10_36 == 0) && ((v8_71 == 0) && ((v12_17 == 0) && ((v13_24 == 0) && ((v14_22 == null) && ((v15_1 == 0) && (v11_39 == 0))))))) {
                                                    v5_2.isNever = 1;
                                                } else {
                                                    v5_2.isNever = 0;
                                                }
                                                com.jtkj.library.commom.logger.CLog.i(v6_80, new StringBuilder("getTimerSwitch  isNever>>>").append(v5_2.isNever).toString());
                                                v3_88.add(v5_2);
                                                v4_56++;
                                                v2_139 = v17_0;
                                            }
                                            v1_223.timerSwitchItemList = v3_88;
                                        }
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_223);
                                        return;
                                    }
                                } else {
                                    int v1_226 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockSetTimerSwitchEventResponse();
                                    if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("00", 16)) {
                                        v1_226.isSuccess = 0;
                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "setTimerSwitch  response>>>value>>>!=00>>>failure");
                                    } else {
                                        v1_226.isSuccess = 1;
                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "setTimerSwitch  response>>>value>>>00>>>success");
                                    }
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v1_226);
                                    return;
                                }
                            } else {
                                if (Integer.parseInt(((String) p24.get(1)), 16) != Integer.parseInt("02", 16)) {
                                    if (Integer.parseInt(((String) p24.get(1)), 16) == Integer.parseInt("01", 16)) {
                                        if (Integer.parseInt(((String) p24.get(2)), 16) != Integer.parseInt("00", 16)) {
                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "setAlarmClock response>>>value>>>!=00>>>failure");
                                            return;
                                        } else {
                                            com.jtkj.library.commom.logger.CLog.i(v5_18, "setAlarmClock  response>>>value>>>00>>>success");
                                            return;
                                        }
                                    }
                                } else {
                                    boolean v2_180 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetAlarmClockResponseEvent();
                                    Boolean v3_94 = Integer.parseInt(((String) p24.get(2)), 16);
                                    if (v3_94 <= null) {
                                        com.jtkj.library.commom.logger.CLog.i(v5_18, "getAlarmClock  number>>>0");
                                    } else {
                                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("getAlarmClock  number>>>").append(v3_94).toString());
                                        int v4_62 = new java.util.ArrayList();
                                        String v5_3 = 0;
                                        while (v5_3 < v3_94) {
                                            int v8_97;
                                            void v9_29;
                                            int v6_83 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockAlarmClockItem();
                                            int v10_38 = (v5_3 * 7);
                                            int v11_44 = Integer.parseInt(((String) p24.get((v10_38 + 3))), v9_10);
                                            String v14_26 = Integer.parseInt(((String) p24.get((v10_38 + 4))), v9_10);
                                            int v15_5 = Integer.parseInt(((String) p24.get((v10_38 + 5))), v9_10);
                                            int v7_236 = Integer.parseInt(((String) p24.get((v10_38 + 6))), v9_10);
                                            int v12_24 = Integer.parseInt(new StringBuilder().append(((String) p24.get((v10_38 + 7)))).append(((String) p24.get((v10_38 + 8)))).toString(), v9_10);
                                            int v10_42 = Integer.parseInt(((String) p24.get((v10_38 + 9))), v9_10);
                                            int v13_30 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  enableValue>>>").append(v11_44).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  hourValue>>>").append(v14_26).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  minuteValue>>>").append(v15_5).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  repeatValue>>>").append(v7_236).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  duration>>>").append(v12_24).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  reminderDuration>>>").append(v10_42).toString());
                                            if (v11_44 != 0) {
                                                v8_97 = 0;
                                                v9_29 = 1;
                                                v6_83.enable = 1;
                                                com.jtkj.library.commom.logger.CLog.i(v13_30, "getAlarmClock  enable>>>true");
                                            } else {
                                                v8_97 = 0;
                                                v6_83.enable = 0;
                                                com.jtkj.library.commom.logger.CLog.i(v13_30, "getAlarmClock  enable>>>false");
                                                v9_29 = 1;
                                            }
                                            v6_83.hour = v14_26;
                                            v6_83.minute = v15_5;
                                            int v11_46 = v1_0.getBit(v7_236, v8_97);
                                            int v8_98 = v1_0.getBit(v7_236, v9_29);
                                            String v14_27 = v1_0.getBit(v7_236, 2);
                                            int v15_6 = v1_0.getBit(v7_236, 3);
                                            String v17_1 = v3_94;
                                            Boolean v3_97 = v1_0.getBit(v7_236, 4);
                                            com.jtkj.led1248.light.device.DeviceManager$TimerSwitchItem v18 = v5_3;
                                            String v5_4 = v1_0.getBit(v7_236, 5);
                                            int v7_237 = v1_0.getBit(v7_236, 6);
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  monValue>>>").append(v11_46).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  tueValue>>>").append(v8_98).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  wedValue>>>").append(v14_27).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  thurValue>>>").append(v15_6).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  friValue>>>").append(v3_97).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  satValue>>>").append(v5_4).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  sunValue>>>").append(v7_237).toString());
                                            v6_83.isMondayOn = v11_46;
                                            v6_83.isTuesdayOn = v8_98;
                                            v6_83.isWednesdayOn = v14_27;
                                            v6_83.isThursdayOn = v15_6;
                                            v6_83.isFridayOn = v3_97;
                                            v6_83.isSaturdayOn = v5_4;
                                            v6_83.isSundayOn = v7_237;
                                            if ((v11_46 == 0) && ((v8_98 == 0) && ((v14_27 == null) && ((v15_6 == 0) && ((v3_97 == null) && ((v5_4 == null) && (v7_237 == 0))))))) {
                                                v6_83.isNever = 1;
                                            } else {
                                                v6_83.isNever = 0;
                                            }
                                            v6_83.duration = v12_24;
                                            v6_83.reminderDuration = v10_42;
                                            com.jtkj.library.commom.logger.CLog.i(v13_30, new StringBuilder("getAlarmClock  isNever>>>").append(v6_83.isNever).toString());
                                            v4_62.add(v6_83);
                                            v5_3 = (v18 + 1);
                                            v9_10 = 16;
                                            int v13 = 3;
                                            v1_0 = this;
                                            v3_94 = v17_1;
                                        }
                                        v2_180.alarmClockItems = v4_62;
                                    }
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v2_180);
                                    return;
                                }
                            }
                        } else {
                            if (Integer.parseInt(((String) p24.get(1)), 16) == 2) {
                                boolean v2_186 = Integer.parseInt(((String) p24.get(2)), 16);
                                Boolean v3_101 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTomatoClockResponseEvent();
                                int v4_64 = new java.util.ArrayList();
                                if (p24.size() == (v2_186 + 3)) {
                                    int v7_238 = 0;
                                    while (v7_238 < v2_186) {
                                        v4_64.add(new com.jtkj.led1248.light.device.ILedClockManager$TomatoClockItem(Integer.parseInt(((String) p24.get((v7_238 + 3))), 16)));
                                        v7_238++;
                                    }
                                }
                                v3_101.tomatoClockItems = v4_64;
                                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("get tomatoClockItems  tomatoClockItems>>>").append(v4_64).toString());
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(v3_101);
                                return;
                            }
                        }
                    } else {
                        if (Integer.parseInt(((String) p24.get(1)), 16) == 1) {
                            boolean v2_199 = Integer.parseInt(new StringBuilder().append(((String) p24.get(2))).append(((String) p24.get(3))).toString(), 16);
                            int v10_44 = (((double) ((v2_199 & 32752) >> 4)) + (((double) (v2_199 & 15)) * 4591870180066957722));
                            if (((32768 & v2_199) >> 15) == 1) {
                                v10_44 = (- v10_44);
                            }
                            com.jtkj.led1248.light.device.DeviceManager$19 v0_270 = Integer.parseInt(((String) p24.get(4)), 16);
                            boolean v2_202 = new com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTemperatureAndHumidityResponseEvent();
                            v2_202.type = 1;
                            v2_202.temperature = v10_44;
                            v2_202.humidity = v0_270;
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v2_202);
                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("get current temperature humidity  temperature>>>").append(v10_44).append(">>>humidity>>>").append(v0_270).toString());
                        }
                        return;
                    }
                } else {
                    boolean v2_209 = Integer.parseInt(((String) p24.get(1)), 16);
                    if (v2_209 != 1) {
                        if (v2_209 == 2) {
                            boolean v2_212 = Integer.parseInt(((String) p24.get(2)), 16);
                            Boolean v3_113 = Integer.parseInt(((String) p24.get(3)), 16);
                            int v4_69 = Integer.parseInt(((String) p24.get(4)), 16);
                            int v6_89 = Integer.parseInt(((String) p24.get(5)), 16);
                            int v7_241 = Integer.parseInt(((String) p24.get(6)), 16);
                            int v8_103 = Integer.parseInt(((String) p24.get(7)), 16);
                            int v10_48 = Integer.parseInt(((String) p24.get(8)), 16);
                            int v11_51 = Integer.parseInt(((String) p24.get(9)), 16);
                            int v12_30 = Integer.parseInt(((String) p24.get(10)), 16);
                            com.jtkj.led1248.light.device.DeviceManager$19 v0_276 = Integer.parseInt(((String) p24.get(11)), 16);
                            void v9_46 = new com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetNightModeEventResponse();
                            v9_46.nightModeEnabled = v2_212;
                            v9_46.startTimeHour = v3_113;
                            v9_46.startTimeMinute = v4_69;
                            v9_46.endTimeHour = v6_89;
                            v9_46.endTimeMinute = v7_241;
                            v9_46.brightness = v10_48;
                            v9_46.deviceStateEnabled = v8_103;
                            v9_46.wakeUpDuration = v12_30;
                            v9_46.voiceControlEnabled = v11_51;
                            v9_46.voiceSensitivity = v0_276;
                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("GetNightModeEventResponse>>>").append(v9_46.toString()).toString());
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(v9_46);
                            return;
                        }
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("SetNightModeEventResponse>>>result>>>").append(Integer.parseInt(((String) p24.get(2)), 16)).toString());
                        return;
                    }
                }
            } else {
                boolean v2_219 = Integer.parseInt(((String) p24.get(1)), 16);
                if (v2_219 != 1) {
                    if (v2_219 != 2) {
                        if (v2_219 == 3) {
                            com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("DeleteReminderResponseEvent reponse>>>").append(Integer.parseInt(((String) p24.get(2)), 16)).toString());
                            return;
                        }
                    } else {
                        boolean v2_223 = new com.jtkj.led1248.light.device.ILedClockManager$ReminderItem();
                        v2_223.id = Integer.parseInt(((String) p24.get(2)), 16);
                        v2_223.sound = Integer.parseInt(((String) p24.get(3)), 16);
                        v2_223.year = Integer.parseInt(((String) p24.get(4)), 16);
                        v2_223.month = Integer.parseInt(((String) p24.get(5)), 16);
                        v2_223.day = Integer.parseInt(((String) p24.get(6)), 16);
                        v2_223.hour = Integer.parseInt(((String) p24.get(7)), 16);
                        v2_223.minute = Integer.parseInt(((String) p24.get(8)), 16);
                        v2_223.repeatType = Integer.parseInt(((String) p24.get(9)), 16);
                        Integer.parseInt(((String) p24.get(10)), 16);
                        v2_223.duration = Integer.parseInt(new StringBuilder().append(((String) p24.get(11))).append(((String) p24.get(12))).toString(), 16);
                        Boolean v3_156 = Integer.parseInt(((String) p24.get(13)), 16);
                        int v4_76 = new byte[v3_156];
                        String v5_11 = 14;
                        int v7_243 = 0;
                        while ((v7_243 < v3_156) && (v5_11 < p24.size())) {
                            int v6_91 = (v5_11 + 1);
                            v4_76[v7_243] = com.jtkj.led1248.light.utils.LightUtils.hexToByte(((String) p24.get(v5_11)));
                            v7_243++;
                            v5_11 = v6_91;
                        }
                        v2_223.content = new String(v4_76, java.nio.charset.StandardCharsets.UTF_8);
                        com.jtkj.led1248.light.device.DeviceManager$19 v0_297 = new com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetReminderDetailResponseEvent();
                        v0_297.reminderItem = v2_223;
                        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("GetReminderlDetaiResponseEvent item>>>").append(v2_223.toString()).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(v0_297);
                        return;
                    }
                } else {
                    boolean v2_231 = new com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetReminderResponseEvent();
                    Boolean v3_161 = Integer.parseInt(((String) p24.get(2)), 16);
                    com.jtkj.library.commom.logger.CLog.i(v5_18, new StringBuilder("GetReminderResponseEvent>>>number>>>").append(v3_161).toString());
                    if (v3_161 <= null) {
                        com.jtkj.library.commom.logger.CLog.i(v5_18, "GetReminderResponseEvent  number>>>0");
                    } else {
                        int v4_85 = new java.util.ArrayList();
                        int v7_244 = 0;
                        while (v7_244 < v3_161) {
                            String v5_17 = new com.jtkj.led1248.light.device.ILedClockManager$ReminderItem();
                            v5_17.id = Integer.parseInt(((String) p24.get((v7_244 + 3))), 16);
                            v4_85.add(v5_17);
                            v7_244++;
                        }
                        v2_231.reminderItems = v4_85;
                    }
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(v2_231);
                    return;
                }
            }
        }
        return;
    }

    private void checkMultiDevice(boolean p7)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkMultiDevice>>>isMultiDeviceFlag>>>").append(p7).toString());
        this.isMultiDevice = p7;
        java.util.Iterator v7_1 = this.getBleDeviceItems();
        this.mSendDataEnableMap.clear();
        this.mBleDeviceMap.clear();
        com.jtkj.library.fastble.data.BleDevice v0_3 = this.isMultiDevice;
        Boolean v1_2 = Boolean.valueOf(1);
        if (v0_3 == null) {
            java.util.Iterator v7_2 = v7_1.iterator();
            while (v7_2.hasNext()) {
                com.jtkj.library.fastble.data.BleDevice v0_6 = ((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v7_2.next());
                this.mSendDataEnableMap.put(v0_6.deviceMac, v1_2);
                this.mBleDeviceMap.put(v0_6.deviceMac, v0_6.bleDevice);
            }
        } else {
            java.util.Iterator v7_3 = v7_1.iterator();
            while (v7_3.hasNext()) {
                com.jtkj.library.fastble.data.BleDevice v0_10 = ((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v7_3.next());
                java.util.Map v2_4 = this.getDeviceSendEnable(v0_10.deviceMac);
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkMultiDevice>>>isSendEnable>>>").append(v2_4).append(">>>deviceMac>>>").append(v0_10.deviceMac).toString());
                if (v2_4 != null) {
                    this.mSendDataEnableMap.put(v0_10.deviceMac, v1_2);
                    this.mBleDeviceMap.put(v0_10.deviceMac, v0_10.bleDevice);
                }
            }
        }
        return;
    }

    private void checkPassWordAfterConnectSuccess(com.jtkj.library.fastble.data.BleDevice p8)
    {
        if (p8.getName() != null) {
            if (!p8.getName().equalsIgnoreCase("CoolLEDS")) {
                if ((p8.getName().equalsIgnoreCase("CoolLEDX")) && ((com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE != 3) && (Boolean.valueOf(com.jtkj.led1248.CoolLED.getInstance().readBoolean("DeviceManager_IS_COOLLEDX_EXCEPT_1632_PASSWORD_ENABLE", 0)).booleanValue()))) {
                    String v0_33 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                    com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>CoolLEDX>>>").append(v0_33).toString());
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_33, p8));
                }
            } else {
                String v0_35 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>CoolLEDS>>>").append(v0_35).toString());
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_35, p8));
            }
            if (!p8.getName().equalsIgnoreCase("CoolLEDM")) {
                if (!p8.getName().equalsIgnoreCase("CoolLEDU")) {
                    if ((!p8.getName().equalsIgnoreCase("CoolLEDUX")) && ((!p8.getName().equalsIgnoreCase("iDevilEyes")) && ((!p8.getName().equalsIgnoreCase("iLedHat")) && ((!p8.getName().equalsIgnoreCase("iLedHatC")) && ((!p8.getName().equalsIgnoreCase("iLedOpen")) && (!p8.getName().equalsIgnoreCase("iLedCar"))))))) {
                        if (!p8.getName().equalsIgnoreCase("iLedBike")) {
                            if (p8.getName().equalsIgnoreCase("iLedClock")) {
                                String v0_16 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>ILED_CLOCK>>>").append(v0_16).toString());
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_16, p8));
                                return;
                            }
                        } else {
                            String v0_19 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>CoolLEDUD>>>").append(v0_19).toString());
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_19, p8));
                            return;
                        }
                    } else {
                        String v0_22 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>CoolLEDUX>>>").append(v0_22).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_22, p8));
                    }
                } else {
                    String v0_25 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                    com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>password>>>CoolLEDU>>>").append(v0_25).toString());
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_25, p8));
                    return;
                }
            } else {
                String v0_27 = com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p8.getMac()).toString(), "000000");
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("checkPassword>>>checkPassWordAfterConnectSuccess>>onNotifySuccess>>>password>>>CoolLEDM>>>").append(v0_27).toString());
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent(1, v0_27, p8));
                return;
            }
        }
        return;
    }

    private void checkRetryTimesForDeviceForCoolLEDX()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesForDeviceForCoolLEDXisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendTextIconData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1002, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendTextIconData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1002, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendTextIconData(0);
                    this.mHandler.sendEmptyMessageDelayed(1002, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendCooleduOtaUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendCooleduOtaUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCooleduOtaUpgradeData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCooleduOtaUpgradeData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendCooleduOtaUpgradeData(0);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendCooleduxOtaUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendCooleduxOtaUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCooleduxOtaUpgradeData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCooleduxOtaUpgradeData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendCooleduxOtaUpgradeData(0);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendCoolleduStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendCoolleduStartSendOTAUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_8 = this.mMaxRetryTimesForAll;
            if ((v1_8 > 3) || (v1_8 <= null)) {
                if (v1_8 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCoolleduStartSendOTAUpgradeData();
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCoolleduStartSendOTAUpgradeData();
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.sendCoolleduStartSendOTAUpgradeData();
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendCoolleduxStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendCoolleduxStartSendOTAUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_8 = this.mMaxRetryTimesForAll;
            if ((v1_8 > 3) || (v1_8 <= null)) {
                if (v1_8 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCoolleduxStartSendOTAUpgradeData();
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCoolleduxStartSendOTAUpgradeData();
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.sendCoolleduxStartSendOTAUpgradeData();
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendILedClockOtaUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendILedClockOtaUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendILedClockOtaUpgradeData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendILedClockOtaUpgradeData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendILedClockOtaUpgradeData(0);
                    this.mHandler.sendEmptyMessageDelayed(1006, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendILedClockStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendILedClockStartSendOTAUpgradeDataisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_8 = this.mMaxRetryTimesForAll;
            if ((v1_8 > 3) || (v1_8 <= null)) {
                if (v1_8 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendILedClockStartSendOTAUpgradeData();
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendILedClockStartSendOTAUpgradeData();
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.sendILedClockStartSendOTAUpgradeData();
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendProgramDataForCoolLEDM()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendProgramDataForCoolLEDMisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCoolledmProgramData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCoolledmProgramData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendCoolledmProgramData(0);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendProgramDataForCoolLEDU()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendProgramDataForCoolLEDUisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCooleduProgramData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCooleduProgramData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendCooleduProgramData(0);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendProgramDataForCoolLEDUX()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendProgramDataForCoolLEDUXisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendCooleduxProgramData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendCooleduxProgramData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendCooleduxProgramData(0);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendProgramDataForILedClock()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendProgramDataForILedClockisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_10 = this.mMaxRetryTimesForAll;
            if ((v1_10 > 3) || (v1_10 <= null)) {
                if (v1_10 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.sendILedClockProgramData(this.mSendIndex);
                        this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.sendILedClockProgramData(this.mSendIndex);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.mSendIndex = 0;
                    this.sendILedClockProgramData(0);
                    this.mHandler.sendEmptyMessageDelayed(1004, 5000);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendStartSendProgramDataForCoolLEDM()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendStartSendProgramDataForCoolLEDMisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_9 = this.mMaxRetryTimesForAll;
            if ((v1_9 > 3) || (v1_9 <= null)) {
                if (v1_9 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.retrySendCoolledmStartSendProgramData(this.mCoolledmProgramList, this.mCoolledmProgramIndex, this.mCoolledmProgramCount);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.retrySendCoolledmStartSendProgramData(this.mCoolledmProgramList, this.mCoolledmProgramIndex, this.mCoolledmProgramCount);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.retrySendCoolledmStartSendProgramData(this.mCoolledmProgramList, this.mCoolledmProgramIndex, this.mCoolledmProgramCount);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendStartSendProgramDataForCoolLEDU()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendStartSendProgramDataForCoolLEDUisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_9 = this.mMaxRetryTimesForAll;
            if ((v1_9 > 3) || (v1_9 <= null)) {
                if (v1_9 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.retrySendCoolleduStartSendProgramData(this.mCoolleduProgramList, this.mCoolleduProgramIndex, this.mCoolleduProgramCount);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.retrySendCoolleduStartSendProgramData(this.mCoolleduProgramList, this.mCoolleduProgramIndex, this.mCoolleduProgramCount);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.retrySendCoolleduStartSendProgramData(this.mCoolleduProgramList, this.mCoolleduProgramIndex, this.mCoolleduProgramCount);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendStartSendProgramDataForCoolLEDUX()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendStartSendProgramDataForCoolLEDUXisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_9 = this.mMaxRetryTimesForAll;
            if ((v1_9 > 3) || (v1_9 <= null)) {
                if (v1_9 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.retrySendCoolleduxStartSendProgramData(this.mCoolleduxProgramList, this.mCoolleduxProgramIndex, this.mCoolleduxProgramCount);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.retrySendCoolleduxStartSendProgramData(this.mCoolleduxProgramList, this.mCoolleduxProgramIndex, this.mCoolleduxProgramCount);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.retrySendCoolleduxStartSendProgramData(this.mCoolleduxProgramList, this.mCoolleduxProgramIndex, this.mCoolleduxProgramCount);
                    return;
                }
            }
        }
        return;
    }

    private void checkRetryTimesSendStartSendProgramDataForILedClock()
    {
        com.jtkj.led1248.light.device.DeviceManager$ResponseEvent v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendingData>>>checkResponse checkOverTime  checkRetryTimesSendStartSendProgramDataForILedClockisMessageSuccess>>").append(this.isMessageSuccess).toString());
        if (!this.isMessageSuccess) {
            String v1_9 = this.mMaxRetryTimesForAll;
            if ((v1_9 > 3) || (v1_9 <= null)) {
                if (v1_9 <= null) {
                    if ((this.mDeviceIndex + 1) > (this.mSendDataEnableMap.size() - 1)) {
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> fail Stop to send>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(1));
                    } else {
                        this.mDeviceIndex = (this.mDeviceIndex + 1);
                        this.mSendIndex = 0;
                        this.mMaxRetryTimesForPackage = 3;
                        this.mMaxRetryTimesForAll = 3;
                        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>fail and send to the next device form 0 package>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                        this.retrySendILedClockStartSendProgramData(this.mILedClockProgramList, this.mILedClockProgramIndex, this.mILedClockProgramCount);
                        return;
                    }
                }
            } else {
                if (this.mMaxRetryTimesForPackage > 0) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>>send package failure package retry 0<times <3 >>> mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForPackage = (this.mMaxRetryTimesForPackage - 1);
                    this.clearAllMessages();
                    this.retrySendILedClockStartSendProgramData(this.mILedClockProgramList, this.mILedClockProgramIndex, this.mILedClockProgramCount);
                    return;
                } else {
                    this.clearAllMessages();
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("resend>>>sendingData>>> send package failure over 3 times>>>mMaxRetryTimesForPackage>>").append(this.mMaxRetryTimesForPackage).append(">>>mMaxRetryTimesForAll>>>").append(this.mMaxRetryTimesForAll).append("+>>>SendIndex>>>").append(this.mSendIndex).append(">>>mDeviceIndex>>>").append(this.mDeviceIndex).toString());
                    this.mMaxRetryTimesForAll = (this.mMaxRetryTimesForAll - 1);
                    this.mMaxRetryTimesForPackage = 3;
                    this.retrySendILedClockStartSendProgramData(this.mILedClockProgramList, this.mILedClockProgramIndex, this.mILedClockProgramCount);
                    return;
                }
            }
        }
        return;
    }

    private void clearAllMessages()
    {
        this.mHandler.removeMessages(1001);
        this.mHandler.removeMessages(1002);
        this.mHandler.removeMessages(1003);
        this.mHandler.removeMessages(1004);
        this.mHandler.removeMessages(1005);
        this.mHandler.removeMessages(1006);
        return;
    }

    private void deleteDeviceDisconnectOrConnectFailure(com.jtkj.library.fastble.data.BleDevice p5)
    {
        if (this.mBleDeviceMap.containsKey(p5.getMac())) {
            this.mBleDeviceMap.remove(p5.getMac());
        }
        if (this.mSendDataEnableMap.containsKey(p5.getMac())) {
            this.mSendDataEnableMap.remove(p5.getMac());
        }
        if (this.mVerifyPasswordMap.containsKey(p5.getMac())) {
            this.mVerifyPasswordMap.remove(p5.getMac());
        }
        this.mDeviceConnectTimeMap.put(p5.getMac(), Long.valueOf(System.currentTimeMillis()));
        if (this.mConnectSuccessAddress.addresses.contains(p5.getMac())) {
            this.mConnectSuccessAddress.addresses.remove(p5.getMac());
        }
        com.jtkj.library.commom.cache.CacheManager.writeObject(this.mConnectSuccessAddress, "DeviceManager_CONNECT_SUCCESS_ADDRESS_KEY");
        return;
    }

    private void exitToClearData()
    {
        this.isExit = 1;
        this.mConnectSuccessMap.clear();
        this.mSendDataEnableMap.clear();
        this.mBleDeviceMap.clear();
        this.mDataStrings.clear();
        return;
    }

    private boolean getBit(int p1, int p2)
    {
        if (((p1 >> p2) & 1) != 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem getBleDeviceItem(com.jtkj.library.fastble.data.BleDevice p2)
    {
        com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem v0_1 = new com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem();
        v0_1.deviceMac = p2.getMac();
        v0_1.deviceName = p2.getName();
        v0_1.rssi = p2.getRssi();
        v0_1.scanRecord = p2.getScanRecord();
        v0_1.bleDevice = p2;
        v0_1.bluetoothDevice = p2.getDevice();
        return v0_1;
    }

    public static int getDeviceColorTye(com.jtkj.library.fastble.data.BleDevice p1)
    {
        return Integer.parseInt(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p1.getScanRecord()[20] & 255)), 16);
    }

    public static int getDeviceColumn(com.jtkj.library.fastble.data.BleDevice p3)
    {
        return Integer.parseInt(new StringBuilder().append(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p3.getScanRecord()[18] & 255))).append(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p3.getScanRecord()[19] & 255))).toString(), 16);
    }

    public static int getDeviceColumn(byte[] p2)
    {
        return Integer.parseInt(new StringBuilder().append(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p2[18] & 255))).append(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p2[19] & 255))).toString(), 16);
    }

    public static String getDeviceId(com.jtkj.library.fastble.data.BleDevice p3)
    {
        return new StringBuilder().append(com.jtkj.led1248.light.utils.Light1248Utils.getHexStringForInt((p3.getScanRecord()[10] & 255)).toUpperCase()).append(com.jtkj.led1248.light.utils.Light1248Utils.getHexStringForInt((p3.getScanRecord()[9] & 255)).toUpperCase()).toString();
    }

    public static String getDeviceId(byte[] p2)
    {
        return new StringBuilder().append(com.jtkj.led1248.light.utils.Light1248Utils.getHexStringForInt((p2[10] & 255)).toUpperCase()).append(com.jtkj.led1248.light.utils.Light1248Utils.getHexStringForInt((p2[9] & 255)).toUpperCase()).toString();
    }

    private void getDeviceInfo(com.jtkj.library.fastble.data.BleDevice p23)
    {
        int v1_6 = p23.getName();
        com.jtkj.led1248.light.device.DeviceManager.DEVICE_NAME = v1_6;
        if (!android.text.TextUtils.isEmpty(v1_6)) {
            int v2_49 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>deviceName>>>").append(v1_6).toString());
            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_NAME_KEY", com.jtkj.led1248.light.device.DeviceManager.DEVICE_NAME);
            if (!v1_6.equalsIgnoreCase("CoolLEDX")) {
                if (!v1_6.equalsIgnoreCase("CoolLEDS")) {
                    if (!v1_6.equalsIgnoreCase("CoolLEDA")) {
                        if (!v1_6.equalsIgnoreCase("CoolLED")) {
                            if (!v1_6.equalsIgnoreCase("CoolLED536")) {
                                if (!v1_6.equalsIgnoreCase("CoolLEDM")) {
                                    if (!v1_6.equalsIgnoreCase("CoolLEDU")) {
                                        if (!v1_6.equalsIgnoreCase("iLedBike")) {
                                            if ((!v1_6.equalsIgnoreCase("CoolLEDUX")) && ((!v1_6.equalsIgnoreCase("iDevilEyes")) && ((!v1_6.equalsIgnoreCase("iLedHat")) && ((!v1_6.equalsIgnoreCase("iLedHatC")) && ((!v1_6.equalsIgnoreCase("iLedOpen")) && (!v1_6.equalsIgnoreCase("iLedCar"))))))) {
                                                if (v1_6.equalsIgnoreCase("iLedClock")) {
                                                    com.jtkj.led1248.light.device.DeviceManager.DeviceVersion = com.jtkj.led1248.light.device.DeviceManager.getDeviceVersion(p23);
                                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.DeviceVersion).toString());
                                                    com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 4;
                                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                                    this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 50;
                                                }
                                            } else {
                                                if (!v1_6.equalsIgnoreCase("iLedCar")) {
                                                    com.jtkj.led1248.light.device.DeviceManager.isILedCar = 0;
                                                } else {
                                                    com.jtkj.led1248.light.device.DeviceManager.isILedCar = 1;
                                                }
                                                Integer v3_31 = com.jtkj.led1248.light.device.DeviceManager.getDeviceVersion(p23);
                                                this.setUxDeviceVersion(p23.getMac(), v3_31);
                                                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>CoolleduxDeviceVersion>>>").append(v3_31).toString());
                                                this.clearCoolLEDUXOtaLocaInfo();
                                                com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 2;
                                                com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                                                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                                                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                                                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                                                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                                this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                                                int v1_12 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW;
                                                if (v1_12 != 16) {
                                                    if (v1_12 != 32) {
                                                        if (v1_12 != 24) {
                                                            if (v1_12 == 20) {
                                                                int v1_13 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                                if (v1_13 > 288) {
                                                                    if (v1_13 > 288) {
                                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 49;
                                                                    }
                                                                } else {
                                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 48;
                                                                }
                                                            }
                                                        } else {
                                                            int v1_15 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                            if (v1_15 > 288) {
                                                                if (v1_15 > 288) {
                                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 45;
                                                                }
                                                            } else {
                                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 43;
                                                            }
                                                        }
                                                    } else {
                                                        int v1_18 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                        if (v1_18 > 288) {
                                                            if (v1_18 > 288) {
                                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 42;
                                                            }
                                                        } else {
                                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 40;
                                                        }
                                                    }
                                                } else {
                                                    int v1_21 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                    if (v1_21 > 288) {
                                                        if (v1_21 > 288) {
                                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 39;
                                                        }
                                                    } else {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 37;
                                                    }
                                                }
                                            }
                                        } else {
                                            com.jtkj.led1248.light.device.DeviceManager.DeviceVersion = com.jtkj.led1248.light.device.DeviceManager.getDeviceVersion(p23);
                                            com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.DeviceVersion).toString());
                                            com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 2;
                                            com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                                            com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                                            com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                                            com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                                            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                            this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 30;
                                        }
                                    } else {
                                        com.jtkj.led1248.light.device.DeviceManager.DeviceVersion = com.jtkj.led1248.light.device.DeviceManager.getDeviceVersion(p23);
                                        com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.DeviceVersion).toString());
                                        com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 2;
                                        com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                                        com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                                        com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                                        com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                                        com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                        com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                        this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                                        int v1_35 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW;
                                        if (v1_35 != 16) {
                                            if (v1_35 != 32) {
                                                if (v1_35 != 24) {
                                                    if (v1_35 == 20) {
                                                        int v1_36 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                        if (v1_36 > 256) {
                                                            if (v1_36 > 256) {
                                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 47;
                                                            }
                                                        } else {
                                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 46;
                                                        }
                                                    }
                                                } else {
                                                    int v1_39 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                    if (v1_39 > 256) {
                                                        if (v1_39 > 256) {
                                                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 29;
                                                        }
                                                    } else {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 27;
                                                    }
                                                }
                                            } else {
                                                int v1_42 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                                if (v1_42 > 256) {
                                                    if (v1_42 > 256) {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 26;
                                                    }
                                                } else {
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 24;
                                                }
                                            }
                                        } else {
                                            int v1_44 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                            if (v1_44 > 256) {
                                                if (v1_44 > 256) {
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 23;
                                                }
                                            } else {
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 21;
                                            }
                                        }
                                    }
                                } else {
                                    com.jtkj.led1248.light.device.DeviceManager.DeviceVersion = com.jtkj.led1248.light.device.DeviceManager.getDeviceVersion(p23);
                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.DeviceVersion).toString());
                                    com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = com.jtkj.led1248.light.device.DeviceManager.getDeviceColorTye(p23);
                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                    this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                                    int v1_52 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW;
                                    if (v1_52 != 16) {
                                        if (v1_52 == 32) {
                                            int v1_53 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                            if (v1_53 > 96) {
                                                if ((v1_53 <= 96) || (v1_53 > 192)) {
                                                    if (v1_53 > 192) {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 20;
                                                    }
                                                } else {
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 19;
                                                }
                                            } else {
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 14;
                                            }
                                        }
                                    } else {
                                        int v1_56 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                                        if (v1_56 > 96) {
                                            if ((v1_56 <= 96) || (v1_56 > 192)) {
                                                if (v1_56 > 192) {
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 13;
                                                }
                                            } else {
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 12;
                                            }
                                        } else {
                                            if (v1_56 != 96) {
                                                if (v1_56 != 64) {
                                                    if (v1_56 != 32) {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 14;
                                                    } else {
                                                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 15;
                                                    }
                                                } else {
                                                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 16;
                                                }
                                            } else {
                                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 17;
                                            }
                                        }
                                    }
                                }
                            } else {
                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = 5;
                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = 36;
                                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                                this.mDeviceInfo = v1_6;
                                com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 2;
                            }
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 0;
                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = 12;
                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = 48;
                            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                            com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = 0;
                            com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                            this.mDeviceInfo = new StringBuilder().append(v1_6).append("12*48").toString();
                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 1;
                        }
                    } else {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = 16;
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = 32;
                        com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                        com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                        this.mDeviceInfo = new StringBuilder().append(v1_6).append("16*32").toString();
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 7;
                    }
                } else {
                    com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = com.jtkj.led1248.light.device.DeviceManager.getDeviceColorTye(p23);
                    com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                    com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                    com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                    this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                    int v1_73 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW;
                    if ((v1_73 == 16) && (com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN == 32)) {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 10;
                    }
                    if ((v1_73 == 16) && (com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN == 64)) {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 9;
                    }
                    int v1_76 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                    if (v1_76 > 64) {
                        if (v1_76 != 96) {
                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 11;
                        } else {
                            com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 8;
                        }
                    }
                }
            } else {
                com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = com.jtkj.led1248.light.device.DeviceManager.getDeviceColorTye(p23);
                com.jtkj.led1248.CoolLED.getInstance().savePreference("COOL_LED_DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE));
                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>COOL_LED_DEVICE_COLOR_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE).toString());
                com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.light.device.DeviceManager.getDeviceRow(p23);
                com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.light.device.DeviceManager.getDeviceColumn(p23);
                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_ROW>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).toString());
                com.jtkj.library.commom.logger.CLog.i(v2_49, new StringBuilder("getDeviceInfo>>>DEVICE_COLUMN>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString());
                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_ROW_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW));
                com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_COLUMN_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                this.mDeviceInfo = new StringBuilder().append(v1_6).append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW).append("*").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN).toString();
                int v1_84 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW;
                if ((v1_84 != 16) || (com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN != 32)) {
                    if ((v1_84 == 16) && (com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN == 64)) {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 4;
                    }
                } else {
                    com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 3;
                }
                int v1_88 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN;
                if (v1_88 > 64) {
                    if (v1_88 != 96) {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 5;
                    } else {
                        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = 6;
                    }
                }
            }
            com.jtkj.led1248.CoolLED.getInstance().savePreference("DEVICE_TYPE_KEY", Integer.valueOf(com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE));
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckDeviceType(com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE));
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckDeviceInfoSuccessEvent());
            if (!android.text.TextUtils.isEmpty(this.mDeviceInfo)) {
                com.jtkj.led1248.CoolLED.getInstance().savePreference("CONNECTED_DEVICE_INFO", this.mDeviceInfo);
            }
        }
        return;
    }

    public static int getDeviceRow(com.jtkj.library.fastble.data.BleDevice p1)
    {
        return Integer.parseInt(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p1.getScanRecord()[17] & 255)), 16);
    }

    public static int getDeviceRow(byte[] p1)
    {
        return Integer.parseInt(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p1[17] & 255)), 16);
    }

    public static int getDeviceVersion(com.jtkj.library.fastble.data.BleDevice p1)
    {
        return Integer.parseInt(com.jtkj.led1248.light.utils.LightUtils.getHexStringForInt((p1.getScanRecord()[21] & 255)), 20);
    }

    public static com.jtkj.led1248.light.device.DeviceManager getInstance()
    {
        if (com.jtkj.led1248.light.device.DeviceManager.mInstance == null) {
            try {
                if (com.jtkj.led1248.light.device.DeviceManager.mInstance == null) {
                    com.jtkj.led1248.light.device.DeviceManager.mInstance = new com.jtkj.led1248.light.device.DeviceManager();
                }
            } catch (com.jtkj.led1248.light.device.DeviceManager v1_3) {
                throw v1_3;
            }
        }
        return com.jtkj.led1248.light.device.DeviceManager.mInstance;
    }

    private int getOtaPackageSize()
    {
        return Math.min(1024, this.UX_PACKAGE_SIZE);
    }

    private int getUxDevicePackageSize(String p4)
    {
        int v4_1;
        if (!this.mUxPackageSizeMap.containsKey(p4)) {
            v4_1 = 1004;
        } else {
            v4_1 = ((Integer) this.mUxPackageSizeMap.get(p4)).intValue();
        }
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("getUxDevicePackageSize>>>uxpackSize>>>").append(v4_1).toString());
        return v4_1;
    }

    private int getUxDeviceVersion(String p4)
    {
        int v4_1;
        if (!this.mUxDeviceVersionMap.containsKey(p4)) {
            v4_1 = -1;
        } else {
            v4_1 = ((Integer) this.mUxDeviceVersionMap.get(p4)).intValue();
        }
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("getUxDeviceVersion>>>version>>>").append(v4_1).toString());
        return v4_1;
    }

    private void initBleManager()
    {
        com.jtkj.library.fastble.BleManager.getInstance().enableLog(0).setReConnectCount(5, 1000).setConnectOverTime(5000).setOperateTimeout(5000);
        java.util.UUID[] v2_1 = new java.util.UUID[1];
        v2_1[0] = java.util.UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
        String[] v3_3 = new String[15];
        v3_3[0] = "CoolLED536";
        v3_3[1] = "CoolLED";
        v3_3[2] = "CoolLEDX";
        v3_3[3] = "CoolLEDA";
        v3_3[4] = "CoolLEDS";
        v3_3[5] = "CoolLEDM";
        v3_3[6] = "CoolLEDU";
        v3_3[7] = "iLedBike";
        v3_3[8] = "CoolLEDUX";
        v3_3[9] = "iDevilEyes";
        v3_3[10] = "iLedHat";
        v3_3[11] = "iLedHatC";
        v3_3[12] = "iLedOpen";
        v3_3[13] = "iLedCar";
        v3_3[14] = "iLedClock";
        com.jtkj.library.fastble.BleManager.getInstance().initScanRule(new com.jtkj.library.fastble.scan.BleScanRuleConfig$Builder().setServiceUuids(v2_1).setDeviceName(0, v3_3).setAutoConnect(0).setScanTimeOut(3000).build());
        return;
    }

    private void monitorSendData(java.util.List p20)
    {
        String v1_0 = com.jtkj.led1248.light.utils.LightUtils.recoverDataList(p20);
        if ((v1_0 != null) && (v1_0.size() > 0)) {
            String v1_88 = v1_0.iterator();
            while (v1_88.hasNext()) {
                java.util.List v2_1 = ((java.util.List) v1_88.next());
                String v3_3 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                java.util.Iterator v17 = v1_88;
                if ((v3_3 != 12) && ((v3_3 != 13) && ((v3_3 != 14) && ((v3_3 != 15) && ((v3_3 != 16) && ((v3_3 != 17) && ((v3_3 != 18) && ((v3_3 != 19) && (v3_3 != 20))))))))) {
                    if ((v3_3 != 21) && ((v3_3 != 22) && ((v3_3 != 23) && ((v3_3 != 47) && ((v3_3 != 46) && ((v3_3 != 24) && ((v3_3 != 25) && ((v3_3 != 26) && ((v3_3 != 27) && ((v3_3 != 28) && ((v3_3 != 29) && (v3_3 != 30)))))))))))) {
                        if ((v3_3 != 37) && ((v3_3 != 38) && ((v3_3 != 39) && ((v3_3 != 40) && ((v3_3 != 41) && ((v3_3 != 42) && ((v3_3 != 43) && ((v3_3 != 44) && ((v3_3 != 45) && ((v3_3 != 48) && (v3_3 != 49))))))))))) {
                            if (v3_3 != 50) {
                                String v3_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                                com.jtkj.library.commom.logger.CLog.i(v3_0, new StringBuilder("monitorSendData>>>item>>>").append(v2_1).toString());
                                String v9_4 = ((String) v2_1.get(0));
                                com.jtkj.library.commom.logger.CLog.i(v3_0, new StringBuilder("monitorSendData>>>messageType>>>").append(v9_4).toString());
                                String v3_2 = new java.util.ArrayList();
                                if (Integer.parseInt(v9_4, 16) != Integer.parseInt("02", 16)) {
                                    if (Integer.parseInt(v9_4, 16) != Integer.parseInt("03", 16)) {
                                        if (Integer.parseInt(v9_4, 16) != Integer.parseInt("04", 16)) {
                                            if (Integer.parseInt(v9_4, 16) != Integer.parseInt("0d", 16)) {
                                                if (Integer.parseInt(v9_4, 16) != Integer.parseInt("0e", 16)) {
                                                    if (Integer.parseInt(v9_4, 16) == Integer.parseInt("1e", 16)) {
                                                        v3_2.add("1e");
                                                        v3_2.add(((String) v2_1.get(1)));
                                                        v3_2.add("00");
                                                    }
                                                } else {
                                                    v3_2.add("0e");
                                                    v3_2.add("00");
                                                }
                                            } else {
                                                v3_2.add("0d");
                                                v3_2.add("00");
                                            }
                                        } else {
                                            v3_2.add("04");
                                            v3_2.add("00");
                                            v3_2.add(((String) v2_1.get(4)));
                                            v3_2.add(((String) v2_1.get(5)));
                                            v3_2.add("00");
                                        }
                                    } else {
                                        v3_2.add("03");
                                        v3_2.add("00");
                                        v3_2.add(((String) v2_1.get(4)));
                                        v3_2.add(((String) v2_1.get(5)));
                                        v3_2.add("00");
                                    }
                                } else {
                                    v3_2.add("02");
                                    v3_2.add("00");
                                    v3_2.add(((String) v2_1.get(4)));
                                    v3_2.add(((String) v2_1.get(5)));
                                    v3_2.add("00");
                                }
                                this.checkCoolLEDXMessages(v3_2);
                            } else {
                                String v3_4 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                                com.jtkj.library.commom.logger.CLog.i(v3_4, new StringBuilder("monitorSendData>>>item>>>").append(v2_1).toString());
                                String v9_10 = ((String) v2_1.get(0));
                                com.jtkj.library.commom.logger.CLog.i(v3_4, new StringBuilder("monitorSendData>>>messageType>>>").append(v9_10).toString());
                                String v3_6 = new java.util.ArrayList();
                                if (Integer.parseInt(v9_10, 16) != Integer.parseInt("02", 16)) {
                                    if (Integer.parseInt(v9_10, 16) != Integer.parseInt("03", 16)) {
                                        if (Integer.parseInt(v9_10, 16) != Integer.parseInt("04", 16)) {
                                            if (Integer.parseInt(v9_10, 16) != Integer.parseInt("05", 16)) {
                                                if (Integer.parseInt(v9_10, 16) != Integer.parseInt("06", 16)) {
                                                    if (Integer.parseInt(v9_10, 16) != Integer.parseInt("09", 16)) {
                                                        if (Integer.parseInt(v9_10, 16) != Integer.parseInt("0a", 16)) {
                                                            if (Integer.parseInt(v9_10, 16) != Integer.parseInt("0c", 16)) {
                                                                if (Integer.parseInt(v9_10, 16) != Integer.parseInt("0d", 16)) {
                                                                    if (Integer.parseInt(v9_10, 16) != Integer.parseInt("0e", 16)) {
                                                                        if (Integer.parseInt(v9_10, 16) == Integer.parseInt("1e", 16)) {
                                                                            v3_6.add("1e");
                                                                            v3_6.add(((String) v2_1.get(1)));
                                                                            v3_6.add("00");
                                                                        }
                                                                    } else {
                                                                        v3_6.add("0e");
                                                                        v3_6.add("00");
                                                                    }
                                                                } else {
                                                                    v3_6.add("0d");
                                                                    v3_6.add("00");
                                                                }
                                                            } else {
                                                                v3_6.add("0c");
                                                                v3_6.add(((String) v2_1.get(1)));
                                                            }
                                                        } else {
                                                            v3_6.add("0a");
                                                            v3_6.add(((String) v2_1.get(1)));
                                                        }
                                                    } else {
                                                        v3_6.add("09");
                                                        v3_6.add("00");
                                                    }
                                                } else {
                                                    v3_6.add("06");
                                                    v3_6.add(((String) v2_1.get(1)));
                                                }
                                            } else {
                                                v3_6.add("05");
                                                v3_6.add(((String) v2_1.get(1)));
                                            }
                                        } else {
                                            v3_6.add("04");
                                            v3_6.add(((String) v2_1.get(1)));
                                        }
                                    } else {
                                        v3_6.add("03");
                                        v3_6.add("00");
                                        v3_6.add(((String) v2_1.get(6)));
                                        v3_6.add(((String) v2_1.get(7)));
                                        v3_6.add("00");
                                    }
                                } else {
                                    v3_6.add("02");
                                    v3_6.add("00");
                                }
                                this.checkILedClockMessages(v3_6);
                            }
                        } else {
                            void v15_11 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                            com.jtkj.library.commom.logger.CLog.i(v15_11, new StringBuilder("monitorSendData>>>item>>>").append(v2_1).toString());
                            String v3_13 = ((String) v2_1.get(0));
                            com.jtkj.library.commom.logger.CLog.i(v15_11, new StringBuilder("monitorSendData>>>messageType>>>").append(v3_13).toString());
                            int v7_12 = new java.util.ArrayList();
                            if (Integer.parseInt(v3_13, 16) != Integer.parseInt("02", 16)) {
                                if (Integer.parseInt(v3_13, 16) != Integer.parseInt("03", 16)) {
                                    if (Integer.parseInt(v3_13, 16) != Integer.parseInt("04", 16)) {
                                        if (Integer.parseInt(v3_13, 16) != Integer.parseInt("05", 16)) {
                                            if (Integer.parseInt(v3_13, 16) != Integer.parseInt("06", 16)) {
                                                if (Integer.parseInt(v3_13, 16) != Integer.parseInt("09", 16)) {
                                                    if (Integer.parseInt(v3_13, 16) != Integer.parseInt("0a", 16)) {
                                                        if (Integer.parseInt(v3_13, 16) != Integer.parseInt("0c", 16)) {
                                                            if (Integer.parseInt(v3_13, 16) != Integer.parseInt("0d", 16)) {
                                                                if (Integer.parseInt(v3_13, 16) != Integer.parseInt("0e", 16)) {
                                                                    if (Integer.parseInt(v3_13, 16) == Integer.parseInt("1e", 16)) {
                                                                        v7_12.add("1e");
                                                                        v7_12.add(((String) v2_1.get(1)));
                                                                        v7_12.add("00");
                                                                    }
                                                                } else {
                                                                    v7_12.add("0e");
                                                                    v7_12.add("00");
                                                                }
                                                            } else {
                                                                v7_12.add("0d");
                                                                v7_12.add("00");
                                                            }
                                                        } else {
                                                            v7_12.add("0c");
                                                            v7_12.add(((String) v2_1.get(1)));
                                                        }
                                                    } else {
                                                        v7_12.add("0a");
                                                        v7_12.add(((String) v2_1.get(1)));
                                                    }
                                                } else {
                                                    v7_12.add("09");
                                                    v7_12.add("00");
                                                }
                                            } else {
                                                v7_12.add("06");
                                                v7_12.add(((String) v2_1.get(1)));
                                            }
                                        } else {
                                            v7_12.add("05");
                                            v7_12.add(((String) v2_1.get(1)));
                                        }
                                    } else {
                                        v7_12.add("04");
                                        v7_12.add(((String) v2_1.get(1)));
                                    }
                                } else {
                                    v7_12.add("03");
                                    v7_12.add("00");
                                    v7_12.add(((String) v2_1.get(6)));
                                    v7_12.add(((String) v2_1.get(7)));
                                    v7_12.add("00");
                                }
                            } else {
                                v7_12.add("02");
                                v7_12.add("00");
                            }
                            this.checkCoolLEDUXMessages(v7_12);
                        }
                    } else {
                        void v15_22 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                        com.jtkj.library.commom.logger.CLog.i(v15_22, new StringBuilder("monitorSendData>>>item>>>").append(v2_1).toString());
                        String v3_21 = ((String) v2_1.get(0));
                        com.jtkj.library.commom.logger.CLog.i(v15_22, new StringBuilder("monitorSendData>>>messageType>>>").append(v3_21).toString());
                        int v7_16 = new java.util.ArrayList();
                        if (Integer.parseInt(v3_21, 16) != Integer.parseInt("02", 16)) {
                            if (Integer.parseInt(v3_21, 16) != Integer.parseInt("03", 16)) {
                                if (Integer.parseInt(v3_21, 16) != Integer.parseInt("04", 16)) {
                                    if (Integer.parseInt(v3_21, 16) != Integer.parseInt("05", 16)) {
                                        if (Integer.parseInt(v3_21, 16) != Integer.parseInt("06", 16)) {
                                            if (Integer.parseInt(v3_21, 16) != Integer.parseInt("09", 16)) {
                                                if (Integer.parseInt(v3_21, 16) != Integer.parseInt("0a", 16)) {
                                                    if (Integer.parseInt(v3_21, 16) != Integer.parseInt("0c", 16)) {
                                                        if (Integer.parseInt(v3_21, 16) != Integer.parseInt("0d", 16)) {
                                                            if (Integer.parseInt(v3_21, 16) != Integer.parseInt("0e", 16)) {
                                                                if (Integer.parseInt(v3_21, 16) == Integer.parseInt("1e", 16)) {
                                                                    v7_16.add("1e");
                                                                    v7_16.add(((String) v2_1.get(1)));
                                                                    v7_16.add("00");
                                                                }
                                                            } else {
                                                                v7_16.add("0e");
                                                                v7_16.add("00");
                                                            }
                                                        } else {
                                                            v7_16.add("0d");
                                                            v7_16.add("00");
                                                        }
                                                    } else {
                                                        v7_16.add("0c");
                                                        v7_16.add(((String) v2_1.get(1)));
                                                    }
                                                } else {
                                                    v7_16.add("0a");
                                                    v7_16.add(((String) v2_1.get(1)));
                                                }
                                            } else {
                                                v7_16.add("09");
                                                v7_16.add("00");
                                            }
                                        } else {
                                            v7_16.add("06");
                                            v7_16.add(((String) v2_1.get(1)));
                                        }
                                    } else {
                                        v7_16.add("05");
                                        v7_16.add(((String) v2_1.get(1)));
                                    }
                                } else {
                                    v7_16.add("04");
                                    v7_16.add(((String) v2_1.get(1)));
                                }
                            } else {
                                v7_16.add("03");
                                v7_16.add("00");
                                v7_16.add(((String) v2_1.get(6)));
                                v7_16.add(((String) v2_1.get(7)));
                                v7_16.add("00");
                            }
                        } else {
                            v7_16.add("02");
                            v7_16.add("00");
                        }
                        this.checkCoolLEDUMessages(v7_16);
                    }
                } else {
                    void v15_33 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                    com.jtkj.library.commom.logger.CLog.i(v15_33, new StringBuilder("monitorSendData>>>item>>>").append(v2_1).toString());
                    String v3_29 = ((String) v2_1.get(0));
                    com.jtkj.library.commom.logger.CLog.i(v15_33, new StringBuilder("monitorSendData>>>messageType>>>").append(v3_29).toString());
                    int v7_20 = new java.util.ArrayList();
                    if (Integer.parseInt(v3_29, 16) != Integer.parseInt("02", 16)) {
                        if (Integer.parseInt(v3_29, 16) != Integer.parseInt("03", 16)) {
                            if (Integer.parseInt(v3_29, 16) != Integer.parseInt("04", 16)) {
                                if (Integer.parseInt(v3_29, 16) != Integer.parseInt("05", 16)) {
                                    if (Integer.parseInt(v3_29, 16) != Integer.parseInt("06", 16)) {
                                        if (Integer.parseInt(v3_29, 16) != Integer.parseInt("09", 16)) {
                                            if (Integer.parseInt(v3_29, 16) != Integer.parseInt("0a", 16)) {
                                                if (Integer.parseInt(v3_29, 16) != Integer.parseInt("0c", 16)) {
                                                    if (Integer.parseInt(v3_29, 16) != Integer.parseInt("0d", 16)) {
                                                        if (Integer.parseInt(v3_29, 16) != Integer.parseInt("0e", 16)) {
                                                            if (Integer.parseInt(v3_29, 16) == Integer.parseInt("1e", 16)) {
                                                                v7_20.add("1e");
                                                                v7_20.add(((String) v2_1.get(1)));
                                                                v7_20.add("00");
                                                            }
                                                        } else {
                                                            v7_20.add("0e");
                                                            v7_20.add("00");
                                                        }
                                                    } else {
                                                        v7_20.add("0d");
                                                        v7_20.add("00");
                                                    }
                                                } else {
                                                    v7_20.add("0c");
                                                    v7_20.add(((String) v2_1.get(1)));
                                                }
                                            } else {
                                                v7_20.add("0a");
                                                v7_20.add(((String) v2_1.get(1)));
                                            }
                                        } else {
                                            v7_20.add("09");
                                            v7_20.add("00");
                                        }
                                    } else {
                                        v7_20.add("06");
                                        v7_20.add(((String) v2_1.get(1)));
                                    }
                                } else {
                                    v7_20.add("05");
                                    v7_20.add(((String) v2_1.get(1)));
                                }
                            } else {
                                v7_20.add("04");
                                v7_20.add(((String) v2_1.get(1)));
                            }
                        } else {
                            v7_20.add("03");
                            v7_20.add("00");
                            v7_20.add(((String) v2_1.get(6)));
                            v7_20.add(((String) v2_1.get(7)));
                            v7_20.add("00");
                        }
                    } else {
                        v7_20.add("02");
                        v7_20.add("00");
                    }
                    this.checkCoolLEDMMessages(v7_20);
                }
                v1_88 = v17;
            }
        }
        return;
    }

    private void processMessage(android.os.Message p17)
    {
        void v1 = this;
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("processMessage>>>DEVICE_TYPE>>>").append(com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE).toString());
        int v3_1 = 27;
        switch (p17.what) {
            case 1000:
                this.sendDataToDevice();
                break;
            case 1001:
                try {
                    java.util.Iterator v0_5 = com.jtkj.led1248.light.utils.LightUtils.recoverDataList(((java.util.List) p17.obj));
                } catch (java.util.Iterator v0_8) {
                    com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("processMessage>>> catch (Exception e)>>>").append(v0_8.getMessage()).toString());
                    com.jtkj.led1248.CoolLED.reportError(v0_8);
                }
                if ((v0_5 == null) || (v0_5.size() <= 0)) {
                } else {
                    java.util.Iterator v0_6 = v0_5.iterator();
                    while (v0_6.hasNext()) {
                        int v2_47 = ((java.util.List) v0_6.next());
                        int v12_1 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                        if ((v12_1 == 12) || ((v12_1 == 13) || ((v12_1 == 14) || ((v12_1 == 15) || ((v12_1 == 16) || ((v12_1 == 17) || ((v12_1 == 18) || (v12_1 == 19)))))))) {
                            v1 = v1.checkCoolLEDMMessages(v2_47);
                        } else {
                            if (v12_1 != 20) {
                                if ((v12_1 == 21) || ((v12_1 == 22) || ((v12_1 == 23) || ((v12_1 == 47) || ((v12_1 == 46) || ((v12_1 == 24) || ((v12_1 == 25) || ((v12_1 == 26) || ((v12_1 == v3_1) || ((v12_1 == 28) || (v12_1 == 29))))))))))) {
                                } else {
                                    if (v12_1 != 30) {
                                        if ((v12_1 != 37) && ((v12_1 != 38) && ((v12_1 != 39) && ((v12_1 != 40) && ((v12_1 != 41) && ((v12_1 != 42) && ((v12_1 != 43) && ((v12_1 != 44) && ((v12_1 != 45) && (v12_1 != 48)))))))))) {
                                            if (v12_1 != 49) {
                                                if (v12_1 != 50) {
                                                    v1 = v1.checkCoolLEDXMessages(v2_47);
                                                    v3_1 = 27;
                                                } else {
                                                    v1 = v1.checkILedClockMessages(v2_47);
                                                }
                                            } else {
                                            }
                                        }
                                        v1 = v1.checkCoolLEDUXMessages(v2_47);
                                    } else {
                                    }
                                }
                                v1 = v1.checkCoolLEDUMessages(v2_47);
                            } else {
                            }
                        }
                    }
                }
                break;
            case 1002:
                this.checkRetryTimesForDeviceForCoolLEDX();
                return;
            case 1003:
                java.util.Iterator v0_2 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                if ((v0_2 != 12) && ((v0_2 != 13) && ((v0_2 != 14) && ((v0_2 != 15) && ((v0_2 != 16) && ((v0_2 != 17) && ((v0_2 != 18) && ((v0_2 != 19) && (v0_2 != 20))))))))) {
                    if ((v0_2 != 21) && ((v0_2 != 22) && ((v0_2 != 23) && ((v0_2 != 47) && ((v0_2 != 46) && ((v0_2 != 24) && ((v0_2 != 25) && ((v0_2 != 26) && ((v0_2 != 27) && ((v0_2 != 28) && ((v0_2 != 29) && (v0_2 != 30)))))))))))) {
                        if ((v0_2 != 37) && ((v0_2 != 38) && ((v0_2 != 39) && ((v0_2 != 40) && ((v0_2 != 41) && ((v0_2 != 42) && ((v0_2 != 43) && ((v0_2 != 44) && ((v0_2 != 45) && ((v0_2 != 48) && (v0_2 != 49))))))))))) {
                            if (v0_2 != 50) {
                            } else {
                                this.checkRetryTimesSendStartSendProgramDataForILedClock();
                                return;
                            }
                        } else {
                            this.checkRetryTimesSendStartSendProgramDataForCoolLEDUX();
                            return;
                        }
                    } else {
                        this.checkRetryTimesSendStartSendProgramDataForCoolLEDU();
                        return;
                    }
                } else {
                    this.checkRetryTimesSendStartSendProgramDataForCoolLEDM();
                    return;
                }
            case 1004:
                java.util.Iterator v0_1 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                if ((v0_1 != 12) && ((v0_1 != 13) && ((v0_1 != 14) && ((v0_1 != 15) && ((v0_1 != 16) && ((v0_1 != 17) && ((v0_1 != 18) && ((v0_1 != 19) && (v0_1 != 20))))))))) {
                    if ((v0_1 != 21) && ((v0_1 != 22) && ((v0_1 != 23) && ((v0_1 != 47) && ((v0_1 != 46) && ((v0_1 != 24) && ((v0_1 != 25) && ((v0_1 != 26) && ((v0_1 != 27) && ((v0_1 != 28) && ((v0_1 != 29) && (v0_1 != 30)))))))))))) {
                        if ((v0_1 != 37) && ((v0_1 != 38) && ((v0_1 != 39) && ((v0_1 != 40) && ((v0_1 != 41) && ((v0_1 != 42) && ((v0_1 != 43) && ((v0_1 != 44) && ((v0_1 != 45) && ((v0_1 != 48) && (v0_1 != 49))))))))))) {
                            if (v0_1 != 50) {
                            } else {
                                this.checkRetryTimesSendProgramDataForILedClock();
                                return;
                            }
                        } else {
                            this.checkRetryTimesSendProgramDataForCoolLEDUX();
                            return;
                        }
                    } else {
                        this.checkRetryTimesSendProgramDataForCoolLEDU();
                        return;
                    }
                } else {
                    this.checkRetryTimesSendProgramDataForCoolLEDM();
                    return;
                }
            case 1005:
                java.util.Iterator v0_9 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                if ((v0_9 != 21) && ((v0_9 != 22) && ((v0_9 != 23) && ((v0_9 != 47) && ((v0_9 != 46) && ((v0_9 != 24) && ((v0_9 != 25) && ((v0_9 != 26) && ((v0_9 != 27) && ((v0_9 != 28) && ((v0_9 != 29) && (v0_9 != 30)))))))))))) {
                    if ((v0_9 != 37) && ((v0_9 != 38) && ((v0_9 != 39) && ((v0_9 != 40) && ((v0_9 != 41) && ((v0_9 != 42) && ((v0_9 != 43) && ((v0_9 != 44) && ((v0_9 != 45) && ((v0_9 != 48) && (v0_9 != 49))))))))))) {
                        if (v0_9 != 50) {
                        } else {
                            this.checkRetryTimesSendILedClockStartSendOTAUpgradeData();
                            return;
                        }
                    } else {
                        this.checkRetryTimesSendCoolleduxStartSendOTAUpgradeData();
                        return;
                    }
                } else {
                    this.checkRetryTimesSendCoolleduStartSendOTAUpgradeData();
                    return;
                }
            case 1006:
                java.util.Iterator v0_7 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
                if ((v0_7 != 21) && ((v0_7 != 22) && ((v0_7 != 23) && ((v0_7 != 47) && ((v0_7 != 46) && ((v0_7 != 24) && ((v0_7 != 25) && ((v0_7 != 26) && ((v0_7 != 27) && ((v0_7 != 28) && ((v0_7 != 29) && (v0_7 != 30)))))))))))) {
                    if ((v0_7 != 37) && ((v0_7 != 38) && ((v0_7 != 39) && ((v0_7 != 40) && ((v0_7 != 41) && ((v0_7 != 42) && ((v0_7 != 43) && ((v0_7 != 44) && ((v0_7 != 45) && ((v0_7 != 48) && (v0_7 != 49))))))))))) {
                        if (v0_7 != 50) {
                        } else {
                            this.checkRetryTimesSendILedClockOtaUpgradeData();
                            return;
                        }
                    } else {
                        this.checkRetryTimesSendCooleduxOtaUpgradeData();
                        return;
                    }
                } else {
                    this.checkRetryTimesSendCooleduOtaUpgradeData();
                    return;
                }
            default:
        }
        return;
    }

    private void saveDeviceConnectSuccess(com.jtkj.library.fastble.data.BleDevice p5)
    {
        this.mBleDeviceMap.put(p5.getMac(), p5);
        this.mSendDataEnableMap.put(p5.getMac(), Boolean.valueOf(1));
        if (this.mDeviceConnectTimeMap.containsKey(p5.getMac())) {
            this.mDeviceConnectTimeMap.remove(p5.getMac());
        }
        this.mDeviceConnectTimeMap.put(p5.getMac(), Long.valueOf(System.currentTimeMillis()));
        if (!this.mConnectSuccessAddress.addresses.contains(p5.getMac())) {
            this.mConnectSuccessAddress.addresses.add(p5.getMac());
        }
        com.jtkj.library.commom.cache.CacheManager.writeObject(this.mConnectSuccessAddress, "DeviceManager_CONNECT_SUCCESS_ADDRESS_KEY");
        return;
    }

    private void sendCooleduOtaUpgradeData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduOtaUpgradeData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mCoolleduOTAUpgradeData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mCoolleduOTAUpgradeData size>>>").append(this.mCoolleduOTAUpgradeData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mCoolleduOTAUpgradeData package data>>>").append(((java.util.List) this.mCoolleduOTAUpgradeData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mCoolleduOTAUpgradeData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendCooleduProgramData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduProgramData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mCoolleduProgramData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduProgramData>>>coolleduProgram index>>>").append(p5).append(">>>mCoolleduProgramData size>>>").append(this.mCoolleduProgramData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduProgramData>>>sendIndex>>>").append(p5).append(">>>mCoolleduProgramData package data>>>").append(((java.util.List) this.mCoolleduProgramData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mCoolleduProgramData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendCooleduxOtaUpgradeData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxOtaUpgradeData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mCoolleduxOTAUpgradeData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mCoolleduxOTAUpgradeData size>>>").append(this.mCoolleduxOTAUpgradeData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mCoolleduxOTAUpgradeData package data>>>").append(((java.util.List) this.mCoolleduxOTAUpgradeData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mCoolleduxOTAUpgradeData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendCooleduxProgramData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxProgramData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mCoolleduxProgramData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxProgramData>>>coolleduxProgram index>>>").append(p5).append(">>>mCoolleduxProgramData size>>>").append(this.mCoolleduxProgramData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCooleduxProgramData>>>sendIndex>>>").append(p5).append(">>>mCoolleduxProgramData package data>>>").append(((java.util.List) this.mCoolleduxProgramData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mCoolleduxProgramData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendCoolledmProgramData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCoolledmProgramData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mCoolledmProgramData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCoolledmProgramData>>>program index>>>").append(p5).append(">>>programData size>>>").append(this.mCoolledmProgramData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendCoolledmProgramData>>>sendIndex>>>").append(p5).append(">>>programData package data>>>").append(((java.util.List) this.mCoolledmProgramData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mCoolledmProgramData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendDataToDevice()
    {
        String v0_9 = this.mDataStrings;
        if ((v0_9 != null) && (v0_9.size() > 0)) {
            try {
                String v0_4 = ((java.util.List) this.mDataStrings.take());
                String v5_2 = this.mBleDeviceMap.entrySet().iterator();
            } catch (String v0_13) {
                String v5_3 = com.jtkj.led1248.light.device.DeviceManager.TAG;
                com.jtkj.library.commom.logger.CLog.i(v5_3, new StringBuilder("sendingData>>>DataSendingThread Exception e>>>").append(v0_13.getLocalizedMessage()).toString());
                com.jtkj.led1248.CoolLED.reportError(v0_13);
                if (this.mDataStrings.size() <= 0) {
                    com.jtkj.library.commom.logger.CLog.i(v5_3, "sendingData end");
                } else {
                    this.mHandler.sendEmptyMessage(1000);
                    com.jtkj.library.commom.logger.CLog.i(v5_3, "sendingData continue");
                }
            }
            while (v5_2.hasNext()) {
                java.util.Map$Entry v6_4 = ((java.util.Map$Entry) v5_2.next());
                if ((this.mSendDataEnableMap.containsKey(v6_4.getKey())) && (((Boolean) this.mSendDataEnableMap.get(v6_4.getKey())).booleanValue())) {
                    com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder().append("sendingData to blueAddress>>>").append(((String) v6_4.getKey())).append(">>>datasize>>>").append(v0_4.size()).append(">>>data>>").append(v0_4).toString());
                    com.jtkj.library.fastble.BleManager.getInstance().write(((com.jtkj.library.fastble.data.BleDevice) v6_4.getValue()), "0000fff0-0000-1000-8000-00805f9b34fb", "0000fff1-0000-1000-8000-00805f9b34fb", com.jtkj.led1248.light.utils.LightUtils.fromListStringToByteArray(v0_4), 1, this.sendNextWhenLastSuccess, 15, new com.jtkj.led1248.light.device.DeviceManager$7(this, v6_4));
                }
            }
            if (this.mDataStrings.size() <= 0) {
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "sendingData end");
                return;
            } else {
                this.mHandler.sendEmptyMessage(1000);
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "sendingData continue");
                return;
            }
        }
        return;
    }

    private void sendILedClockOtaUpgradeData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockOtaUpgradeData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mILedClockOTAUpgradeData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mILedClockOTAUpgradeData size>>>").append(this.mILedClockOTAUpgradeData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockOtaUpgradeData>>>sendIndex>>>").append(p5).append(">>>mILedClockOTAUpgradeData package data>>>").append(((java.util.List) this.mILedClockOTAUpgradeData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mILedClockOTAUpgradeData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendILedClockProgramData(int p5)
    {
        if (this.isDeviceConnectedSuccess()) {
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            java.util.List v0_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
            com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockProgramData>>>sendIndex>>>").append(p5).toString());
            if (p5 < this.mILedClockProgramData.size()) {
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockProgramData>>>iLedClockProgram index>>>").append(p5).append(">>>mILedClockProgramData size>>>").append(this.mILedClockProgramData.size()).toString());
                com.jtkj.library.commom.logger.CLog.i(v0_2, new StringBuilder("sendILedClockProgramData>>>sendIndex>>>").append(p5).append(">>>mILedClockProgramData package data>>>").append(((java.util.List) this.mILedClockProgramData.get(p5)).toString()).toString());
                this.addDataStrings(((java.util.List) this.mILedClockProgramData.get(p5)));
            }
            return;
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    private void sendTextIconData(int p4)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("sendingData>>>sendTextIconData>>>index>>>").append(p4).toString());
        this.setDeviceEnableToSendData(this.mDeviceIndex);
        if (p4 < this.mCoolledxTextIconData.size()) {
            this.addDataStrings(((java.util.List) this.mCoolledxTextIconData.get(p4)));
        }
        return;
    }

    private void setAllDeviceEnableToSendData()
    {
        java.util.Iterator v0_0 = this.getBleDeviceItems();
        this.mSendDataEnableMap.clear();
        this.mBleDeviceMap.clear();
        java.util.Iterator v0_1 = v0_0.iterator();
        while (v0_1.hasNext()) {
            com.jtkj.library.fastble.data.BleDevice v1_1 = ((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v0_1.next());
            this.mSendDataEnableMap.put(v1_1.deviceMac, Boolean.valueOf(1));
            this.mBleDeviceMap.put(v1_1.deviceMac, v1_1.bleDevice);
        }
        return;
    }

    private void setBleResponse(com.jtkj.library.fastble.data.BleDevice p3, String p4, String p5)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "setBleResponse");
        com.jtkj.led1248.CoolLED.getInstance().getExecutorService().submit(new com.jtkj.led1248.light.device.DeviceManager$6(this, p3, p4, p5));
        return;
    }

    private void setDeviceEnableToSendData(int p7)
    {
        if ((this.mBleDeviceMap.size() > 0) && (p7 < this.mBleDeviceMap.size())) {
            java.util.ArrayList v0_5 = new java.util.ArrayList();
            int v1_2 = this.mBleDeviceMap.entrySet().iterator();
            while (v1_2.hasNext()) {
                v0_5.add(((String) ((java.util.Map$Entry) v1_2.next()).getKey()));
            }
            int v2_1 = 0;
            while (v2_1 < this.mBleDeviceMap.size()) {
                if (v2_1 != p7) {
                    this.mSendDataEnableMap.put(((String) v0_5.get(v2_1)), Boolean.valueOf(0));
                } else {
                    this.mSendDataEnableMap.put(((String) v0_5.get(v2_1)), Boolean.valueOf(1));
                    this.checkDeviceUxVersionMoreThan30(((String) v0_5.get(v2_1)));
                }
                v2_1++;
            }
        }
        return;
    }

    private void setMtu(com.jtkj.library.fastble.data.BleDevice p3)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "setMtu");
        com.jtkj.led1248.CoolLED.getInstance().getExecutorService().submit(new com.jtkj.led1248.light.device.DeviceManager$5(this, p3));
        return;
    }

    private void setOnlyTheDeviceForCheckOrSetPasswordCanSendData(com.jtkj.library.fastble.data.BleDevice p5)
    {
        java.util.Iterator v0_2 = this.mSendDataEnableMap.entrySet().iterator();
        while (v0_2.hasNext()) {
            String v1_1 = ((java.util.Map$Entry) v0_2.next());
            if (!((String) v1_1.getKey()).equalsIgnoreCase(p5.getMac())) {
                this.mSendDataEnableMap.put(((String) v1_1.getKey()), Boolean.valueOf(0));
            } else {
                this.mSendDataEnableMap.put(((String) v1_1.getKey()), Boolean.valueOf(1));
            }
        }
        return;
    }

    private void setUxDevicePackageSize(String p4, int p5)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("setUxDevicePackageSize>>>macAddress>>>").append(p4).append(">>>packageSize>>>").append(p5).toString());
        this.mUxPackageSizeMap.put(p4, Integer.valueOf(p5));
        return;
    }

    private void updateDeviceInfo(com.jtkj.library.fastble.data.BleDevice p3)
    {
        if (!p3.getName().equalsIgnoreCase("CoolLEDM")) {
            if (!p3.getName().equalsIgnoreCase("CoolLEDU")) {
                if ((!p3.getName().equalsIgnoreCase("CoolLEDUX")) && ((!p3.getName().equalsIgnoreCase("iDevilEyes")) && ((!p3.getName().equalsIgnoreCase("iLedHat")) && ((!p3.getName().equalsIgnoreCase("iLedHatC")) && ((!p3.getName().equalsIgnoreCase("iLedOpen")) && (!p3.getName().equalsIgnoreCase("iLedCar"))))))) {
                    if (!p3.getName().equalsIgnoreCase("iLedBike")) {
                        if (p3.getName().equalsIgnoreCase("iLedClock")) {
                            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>getDeviceInfo>>>ILED_CLOCK");
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.ILedClockManager$GetILedClockDeviceInfoEvent(com.jtkj.led1248.light.utils.ILedClockUtils.getDeviceInfo()));
                        }
                        return;
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>getDeviceInfo>>>CoolLEDUD");
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent(com.jtkj.led1248.light.utils.CoolledUDUtils.getDeviceInfo()));
                        return;
                    }
                } else {
                    com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>getDeviceInfo>>>CoolLEDUX");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUXDeviceInfoEvent(com.jtkj.led1248.light.utils.CoolledUXUtils.getDeviceInfo()));
                    return;
                }
            } else {
                com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>getDeviceInfo>>>CoolLEDU");
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent(com.jtkj.led1248.light.utils.CoolledUUtils.getDeviceInfo()));
                return;
            }
        } else {
            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "checkPassWordAfterConnectSuccess>>>onNotifySuccess>>>getDeviceInfo>>>CoolLEDM");
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$GetDeviceCoollEDMInfoEvent(com.jtkj.led1248.light.utils.CoolledMUtils.getDeviceInfo()));
            return;
        }
    }

    public void addDataStrings(java.util.List p3)
    {
        boolean v0_1 = this.mDataStrings.isEmpty();
        this.mDataStrings.offer(p3);
        if (v0_1) {
            this.sendDataToDevice();
        }
        return;
    }

    public void clearCoolLEDUXOtaLocaInfo()
    {
        com.jtkj.led1248.light.device.DeviceManager.CoolleduxRemoteOTAVersion = -1;
        com.jtkj.led1248.light.device.DeviceManager.CoolleduxLocalOTAVersion = -1;
        com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareNeedForceUpgrade = 0;
        com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported = 0;
        com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_NAME = "";
        com.jtkj.led1248.light.device.DeviceManager.Coolledux_REMOTE_OTA_FILE_URL = "";
        return;
    }

    public void clearILedClockOtaLocaInfo()
    {
        com.jtkj.led1248.light.device.DeviceManager.ILedClockRemoteOTAVersion = -1;
        com.jtkj.led1248.light.device.DeviceManager.ILedClockLocalOTAVersion = -1;
        com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareNeedForceUpgrade = 0;
        com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported = 0;
        com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_NAME = "";
        com.jtkj.led1248.light.device.DeviceManager.ILedClock_REMOTE_OTA_FILE_URL = "";
        return;
    }

    public declared_synchronized void connectDevice(com.jtkj.library.fastble.data.BleDevice p5)
    {
        java.util.concurrent.ExecutorService v0_1;
        com.jtkj.led1248.base.OkHttpUtils.getInstance().getDeviceConfig(p5.getName());
        if (!this.mDeviceConnectTimeMap.containsKey(p5.getMac())) {
            v0_1 = 0;
        } else {
            v0_1 = ((Long) this.mDeviceConnectTimeMap.get(p5.getMac())).longValue();
        }
        if ((System.currentTimeMillis() - v0_1) < 1000) {
            this.mHandler.postDelayed(new com.jtkj.led1248.light.device.DeviceManager$3(this, p5), 1000);
        } else {
            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "onStartConnect>>1");
            com.jtkj.led1248.CoolLED.getInstance().getExecutorService().submit(new com.jtkj.led1248.light.device.DeviceManager$2(this, p5));
        }
        return;
    }

    public void disConnectDevice(com.jtkj.library.fastble.data.BleDevice p4)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("disConnectDevice bleDevice: ").append(p4.toString()).toString());
        if (com.jtkj.library.fastble.BleManager.getInstance().isConnected(p4)) {
            com.jtkj.library.fastble.BleManager.getInstance().disconnect(p4);
        }
        this.deleteDeviceDisconnectOrConnectFailure(p4);
        return;
    }

    public declared_synchronized java.util.List getBleDeviceItems()
    {
        Throwable v0_1 = new java.util.ArrayList();
        java.util.Iterator v1_0 = this.mBleDeviceItems;
        if ((v1_0 != null) && (v1_0.size() > 0)) {
            java.util.Iterator v1_3 = this.mBleDeviceItems.iterator();
            while (v1_3.hasNext()) {
                com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem v2_2 = ((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v1_3.next());
                if (this.isDeviceConnected(v2_2.bleDevice)) {
                    v0_1.add(v2_2);
                }
            }
        }
        return v0_1;
    }

    public int getConnectedDeviceNumber()
    {
        return this.mSendDataEnableMap.size();
    }

    public boolean getDeviceSendEnable(String p3)
    {
        if (!this.mChooseMultDeviceMap.containsKey(p3)) {
            this.mChooseMultDeviceMap.put(p3, Boolean.valueOf(1));
        }
        return ((Boolean) this.mChooseMultDeviceMap.get(p3)).booleanValue();
    }

    public int getDeviceSendEnableNumber()
    {
        java.util.Iterator v0_0 = this.getBleDeviceItems();
        int v1 = 0;
        if ((v0_0 != null) && (v0_0.size() > 0)) {
            java.util.Iterator v0_1 = v0_0.iterator();
            while (v0_1.hasNext()) {
                if (this.getDeviceSendEnable(((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v0_1.next()).deviceMac)) {
                    v1++;
                }
            }
        }
        return v1;
    }

    public int getSendEnableDeviceCount()
    {
        int v0_1 = new java.util.ArrayList();
        java.util.Iterator v1_0 = this.mBleDeviceItems;
        if ((v1_0 != null) && (v1_0.size() > 0)) {
            java.util.Iterator v1_3 = this.mBleDeviceItems.iterator();
            while (v1_3.hasNext()) {
                com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem v2_2 = ((com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem) v1_3.next());
                if (this.isDeviceConnected(v2_2.bleDevice)) {
                    v0_1.add(v2_2);
                }
            }
        }
        return v0_1.size();
    }

    public void init()
    {
        String v0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0, "init");
        com.jtkj.library.infrastructure.eventbus.EventAgent.register(this);
        this.initBleManager();
        String v1_21 = ((com.jtkj.led1248.light.device.DeviceManager$ConnectSuccessAddress) com.jtkj.library.commom.cache.CacheManager.readObject("DeviceManager_CONNECT_SUCCESS_ADDRESS_KEY"));
        this.mConnectSuccessAddress = v1_21;
        if (v1_21 == null) {
            this.mConnectSuccessAddress = new com.jtkj.led1248.light.device.DeviceManager$ConnectSuccessAddress(new java.util.ArrayList());
        }
        com.jtkj.led1248.light.device.DeviceManager.isLocalMicSupported = com.jtkj.led1248.CoolLED.getInstance().readBoolean("LOCAL_MIC_SUPPORTED_KEY", 0);
        com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE = com.jtkj.led1248.CoolLED.getInstance().readInt("DEVICE_TYPE_KEY", -1);
        com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE = com.jtkj.led1248.CoolLED.getInstance().readInt("COOL_LED_DEVICE_TYPE_KEY", 1);
        com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN = com.jtkj.led1248.CoolLED.getInstance().readInt("DEVICE_COLUMN_KEY", 48);
        com.jtkj.led1248.light.device.DeviceManager.DEVICE_ROW = com.jtkj.led1248.CoolLED.getInstance().readInt("DEVICE_ROW_KEY", 12);
        com.jtkj.led1248.light.device.DeviceManager.DEVICE_NAME = com.jtkj.led1248.CoolLED.getInstance().readString("DEVICE_NAME_KEY", 0);
        com.jtkj.library.commom.logger.CLog.i(v0, new StringBuilder("mConnectSuccessAddress>>>").append(this.mConnectSuccessAddress).toString());
        return;
    }

    public boolean isDeviceConnected(com.jtkj.library.fastble.data.BleDevice p2)
    {
        return com.jtkj.library.fastble.BleManager.getInstance().isConnected(p2);
    }

    public boolean isDeviceConnectedAndPasswordVerifySuccess(com.jtkj.library.fastble.data.BleDevice p3)
    {
        if ((!this.isDeviceConnected(p3)) || ((!this.mVerifyPasswordMap.containsKey(p3.getMac())) || (!((Boolean) this.mVerifyPasswordMap.get(p3.getMac())).booleanValue()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceConnectedSuccess()
    {
        int v0_0 = this.getBleDeviceItems();
        if ((v0_0 == 0) || (v0_0.size() <= 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceCoolleduHardwareNeedUpgrade()
    {
        if (this.CoolleduLocalOTAVersion <= com.jtkj.led1248.light.device.DeviceManager.DeviceVersion) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceCoolleduxHardwareUpgradeSupported()
    {
        return com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported;
    }

    public boolean isDeviceCoolleduxNeedHardwareUpgrade()
    {
        if ((com.jtkj.led1248.light.device.DeviceManager.CoolleduxRemoteOTAVersion <= com.jtkj.led1248.light.device.DeviceManager.CoolleduxLocalOTAVersion) || (!com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareUpdateSupported)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceCoooleduNeedHardwareForceUpgrade()
    {
        if ((!this.isCoolleduHardwareNeedForceUpgrade) && (com.jtkj.led1248.light.device.DeviceManager.DeviceVersion != 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceCoooleduxNeedHardwareForceUpgrade()
    {
        if ((!com.jtkj.led1248.light.device.DeviceManager.isCoolleduxHardwareNeedForceUpgrade) && (com.jtkj.led1248.light.device.DeviceManager.CoolleduxRemoteOTAVersion != 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceILedClockHardwareUpgradeSupported()
    {
        return com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported;
    }

    public boolean isDeviceILedClockNeedHardwareForceUpgrade()
    {
        if ((!com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareNeedForceUpgrade) && (com.jtkj.led1248.light.device.DeviceManager.ILedClockRemoteOTAVersion != 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDeviceILedClockNeedHardwareUpgrade()
    {
        if ((com.jtkj.led1248.light.device.DeviceManager.ILedClockRemoteOTAVersion <= com.jtkj.led1248.light.device.DeviceManager.ILedClockLocalOTAVersion) || (!com.jtkj.led1248.light.device.DeviceManager.isILedClockHardwareUpdateSupported)) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isDevicePasswordDefault(com.jtkj.library.fastble.data.BleDevice p4)
    {
        return com.jtkj.led1248.CoolLED.getInstance().readString(new StringBuilder("DeviceManager_DEVICE_PASSWORD_FOR_>>>").append(p4.getMac()).toString(), "000000").equalsIgnoreCase("000000");
    }

    public boolean isDevicePasswordVerifySuccess(com.jtkj.library.fastble.data.BleDevice p3)
    {
        if ((!this.mVerifyPasswordMap.containsKey(p3.getMac())) || (!((Boolean) this.mVerifyPasswordMap.get(p3.getMac())).booleanValue())) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isNeedAutoConnect(com.jtkj.library.fastble.data.BleDevice p2)
    {
        java.util.List v0_0 = this.mConnectSuccessAddress;
        if ((v0_0 == null) || (!v0_0.addresses.contains(p2.getMac()))) {
            return 0;
        } else {
            return 1;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$BeginTransferEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>BeginTransferEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$BrightCoolLEDMSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>BrightCoolLEDMSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$BrightCoolLEDUSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>BrightCoolLEDUSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$BrightCoolLEDUXSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>BrightCoolLEDUXSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$BrightDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>BrightDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CheckDeviceEvent p4)
    {
        int v4_1 = this.mBleDeviceMap.size();
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("onEvent>>>CheckDeviceEvent connectedDeviceNumber: ").append(v4_1).toString());
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$CheckConnectedDeviceEvent(v4_1));
        return;
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CheckPasswordEvent p4)
    {
        String v0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0, new StringBuilder("checkPassword>>>onEvent>>>CheckPasswordEvent>>>").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.mCheckPasswordKind = p4.checkPassWordKind;
            this.mPasswordToCheck = p4.password;
            java.util.ArrayList v4_1 = p4.bleDevice;
            this.mDeviceCheckOrSetPassword = v4_1;
            this.setOnlyTheDeviceForCheckOrSetPasswordCanSendData(v4_1);
            java.util.ArrayList v4_4 = new java.util.ArrayList();
            if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDM"))) {
                if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDU"))) {
                    if (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDUX"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iDevilEyes"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedHat"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedHatC"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedOpen"))) && ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedCar")))))))) {
                        if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedClock"))) {
                            if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedBike"))) {
                                if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDX"))) {
                                    if ((this.mDeviceCheckOrSetPassword.getName() != null) && (this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDS"))) {
                                        v4_4.addAll(com.jtkj.led1248.light.utils.Light1696Utils.getCheckPasswordData(this.mPasswordToCheck));
                                    }
                                } else {
                                    v4_4.addAll(com.jtkj.led1248.light.utils.Light1696Utils.getCheckPasswordData(this.mPasswordToCheck));
                                }
                            } else {
                                v4_4.addAll(com.jtkj.led1248.light.utils.CoolledUDUtils.getCheckPasswordData(this.mPasswordToCheck));
                            }
                        } else {
                            v4_4.addAll(com.jtkj.led1248.light.utils.ILedClockUtils.getCheckPasswordData(this.mPasswordToCheck));
                        }
                    } else {
                        v4_4.addAll(com.jtkj.led1248.light.utils.CoolledUXUtils.getCheckPasswordData(this.mPasswordToCheck));
                    }
                } else {
                    v4_4.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getCheckPasswordData(this.mPasswordToCheck));
                }
            } else {
                v4_4.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getCheckPasswordData(this.mPasswordToCheck));
            }
            com.jtkj.library.commom.logger.CLog.i(v0, new StringBuilder("checkPassword>>>onEvent>>>CheckPasswordEvent>>>Result>>>").append(v4_4).append(">>>device>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString());
            this.addDataStrings(v4_4);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolLEDMProgramDataEvent p5)
    {
        this.checkMultiDevice(p5.isMultiDevice);
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mCoolledmProgramData.clear();
        int v1_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_0, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                java.util.List v5_1 = p5.data;
                this.mCoolledmProgramList = v5_1;
                this.mCoolledmProgramCount = v5_1.size();
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolledmProgramIndex = 0;
                com.jtkj.library.commom.logger.CLog.i(v1_0, "onEvent>>>sendCoolledmStartSendProgramData");
                this.sendCoolledmStartSendProgramData(this.mCoolledmProgramList, this.mCoolledmProgramIndex, this.mCoolledmProgramCount);
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolLEDMSwitchEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>CoolLEDMSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolLEDUSwitchEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>CoolLEDUSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolLEDUXSwitchEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>CoolLEDUXSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolleduOTAUpgradeEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolleduOTADataResult = com.jtkj.led1248.light.utils.CoolledUUtils.getOtaDataResult();
                this.sendCoolleduStartSendOTAUpgradeData();
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolleduProgramDataEvent p5)
    {
        this.checkMultiDevice(p5.isMultiDevice);
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mCoolleduProgramData.clear();
        int v1_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_0, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                java.util.List v5_1 = p5.data;
                this.mCoolleduProgramList = v5_1;
                this.mCoolleduProgramCount = v5_1.size();
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolleduProgramIndex = 0;
                com.jtkj.library.commom.logger.CLog.i(v1_0, "onEvent>>>sendCoolleduStartSendProgramData");
                com.jtkj.library.commom.logger.CLog.i(v1_0, "onEvent>>>checktime1");
                this.sendCoolleduStartSendProgramData(this.mCoolleduProgramList, this.mCoolleduProgramIndex, this.mCoolleduProgramCount);
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolleduxOTAUpgradeEvent p5)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v1_3 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_3, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v1_3, "onEvent>>>CoolleduxOTAUpgradeEvent");
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolleduxOTADataResult = com.jtkj.led1248.light.utils.CoolledUXUtils.getOtaDataResult(p5.fileBytes, this.getOtaPackageSize());
                this.sendCoolleduxStartSendOTAUpgradeData();
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CoolleduxProgramDataEvent p5)
    {
        this.checkMultiDevice(p5.isMultiDevice);
        this.mGroupType = p5.groupType;
        com.jtkj.led1248.light.device.DeviceManager.mDriveState = p5.driveState;
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mCoolleduxProgramData.clear();
        int v1_2 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_2, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                java.util.List v5_1 = p5.data;
                this.mCoolleduxProgramList = v5_1;
                this.mCoolleduxProgramCount = v5_1.size();
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolleduxProgramIndex = 0;
                com.jtkj.library.commom.logger.CLog.i(v1_2, "onEvent>>>sendCoolleduxStartSendProgramData");
                com.jtkj.library.commom.logger.CLog.i(v1_2, "onEvent>>>checktime1");
                this.sendCoolleduxStartSendProgramData(this.mCoolleduxProgramList, this.mCoolleduxProgramIndex, this.mCoolleduxProgramCount);
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$CountDownEvent p5)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>CountDownEvent").append(p5.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p5.actionType != 1) {
                if (p5.actionType != 2) {
                    if (p5.actionType == 3) {
                        com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>CountDownEvent>>>SET_START_OR_STOP>>>");
                        this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getCountDownStartOrStop(p5.isStartOrStop));
                    }
                    return;
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>CountDownEvent>>>RESET>>>");
                    this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getCountDownReset(p5.setHour, p5.setMinute, p5.setSeconds));
                    return;
                }
            } else {
                com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>CountDownEvent>>>GET_STATUS>>>");
                this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getCountDownStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$DeviceMicEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>DeviceMicEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledMUtils.getSetRyhthmType(p4.type));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$DrawDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>DrawDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUDeviceInfoEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>GetCoolLEDUDeviceInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUXDeviceInfoEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>GetCoolLEDUXDeviceInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetCoolLEDUXDeviceOTAVersionEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        String v0_4 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("onEvent>>>GetCoolLEDUXDeviceOTAVersionEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getDeviceOTAVersion());
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetDeviceCoollEDMInfoEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>GetDeviceCoollEDMInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetDriveStateEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>GetDriveStateEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$GetTimerSwitchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>GetTimerSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getTimerSwitch());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$Icon536DataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>Icon536DataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$MirrorCoolLEDMSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>MirrorCoolLEDMSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$MirrorCoolLEDUSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>MirrorCoolLEDUSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$MirrorSetEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>MirrorSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>ModeDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$MusicDataEvent p4)
    {
        boolean v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (com.jtkj.led1248.light.device.DeviceManager.isMusic) {
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("onEvent>>>MusicDataEvent").append(p4.toString()).toString());
            if (this.isDeviceConnectedSuccess()) {
                this.setAllDeviceEnableToSendData();
                this.addDataStrings(p4.data);
                return;
            } else {
                this.mDataStrings.clear();
                return;
            }
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$RhythmEvent p4)
    {
        boolean v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (com.jtkj.led1248.light.device.DeviceManager.isMusic) {
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("onEvent>>>RhythmEvent").append(p4.toString()).toString());
            if (this.isDeviceConnectedSuccess()) {
                this.setAllDeviceEnableToSendData();
                this.addDataStrings(p4.data);
                return;
            } else {
                this.mDataStrings.clear();
                return;
            }
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$RotateCoolLEDUXSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>RotateCoolLEDUXSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            com.jtkj.led1248.light.device.DeviceManager.mRotate = p4.action;
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.setRotate(p4.action));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$ScoreBoardEvent p5)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ScoreBoardEvent").append(p5.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p5.actionType != 1) {
                if (p5.actionType != 2) {
                    if (p5.actionType != 3) {
                        if (p5.actionType == 4) {
                            com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ScoreBoardEvent>>>SET_START_OR_STOP>>>");
                            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getScoreBoardStartOrStop(p5.isStartOrStop));
                        }
                        return;
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ScoreBoardEvent>>>SET_TIME>>>");
                        this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getScoreBoardSetTime(p5.setMinute, p5.setSeconds, p5.isCountDown));
                        return;
                    }
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ScoreBoardEvent>>>SET_SCORE>>>");
                    this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getScoreBoardSetCore(p5.hostScore, p5.visitScore, p5.hostTotalScore, p5.visitTotalScore));
                    return;
                }
            } else {
                com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ScoreBoardEvent>>>GET_STATUS>>>");
                this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getScoreBoardStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SendSpeedEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>SendSpeedEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SetDeviceInfoEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>SetDeviceInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            java.util.List v4_2 = com.jtkj.led1248.light.utils.CoolledUXUtils.setDeviceInfo(p4.action, p4.param);
            com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>SetDeviceInfoEvent>>data>>").append(v4_2.toString()).toString());
            this.addDataStrings(v4_2);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SetDriveStateCoolleduProgramDataEvent p5)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mCoolleduProgramData.clear();
        int v1_3 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_3, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                int v2_6 = p5.data;
                this.mCoolleduProgramList = v2_6;
                this.mCoolleduProgramCount = v2_6.size();
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mCoolleduProgramIndex = 0;
                com.jtkj.library.commom.logger.CLog.i(v1_3, "onEvent>>>sendCoolleduStartSendProgramData");
                com.jtkj.library.commom.logger.CLog.i(v1_3, "onEvent>>>checktime1");
                this.sendCoolleduStartSendProgramData(this.mCoolleduProgramList, this.mCoolleduProgramIndex, this.mCoolleduProgramCount, p5.drivateState);
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SetDriveStateEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>SetDriveStateEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SetPasswordEvent p4)
    {
        int v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("onEvent>>>SetPasswordEvent>>>").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.mPasswordToSet = p4.password;
            java.util.ArrayList v4_1 = p4.bleDevice;
            this.mDeviceCheckOrSetPassword = v4_1;
            this.setOnlyTheDeviceForCheckOrSetPasswordCanSendData(v4_1);
            java.util.ArrayList v4_3 = new java.util.ArrayList();
            if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDM"))) {
                if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDU"))) {
                    if (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDUX"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iDevilEyes"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedHat"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedHatC"))) && (((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedOpen"))) && ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedCar")))))))) {
                        if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedClock"))) {
                            if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("iLedBike"))) {
                                if ((this.mDeviceCheckOrSetPassword.getName() == null) || (!this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDX"))) {
                                    if ((this.mDeviceCheckOrSetPassword.getName() != null) && (this.mDeviceCheckOrSetPassword.getName().equalsIgnoreCase("CoolLEDS"))) {
                                        v4_3.addAll(com.jtkj.led1248.light.utils.Light1696Utils.getSetPasswordData(this.mPasswordToSet));
                                    }
                                } else {
                                    v4_3.addAll(com.jtkj.led1248.light.utils.Light1696Utils.getSetPasswordData(this.mPasswordToSet));
                                }
                            } else {
                                v4_3.addAll(com.jtkj.led1248.light.utils.CoolledUDUtils.getSetPasswordData(this.mPasswordToSet));
                            }
                        } else {
                            v4_3.addAll(com.jtkj.led1248.light.utils.ILedClockUtils.getSetPasswordData(this.mPasswordToSet));
                        }
                    } else {
                        v4_3.addAll(com.jtkj.led1248.light.utils.CoolledUXUtils.getSetPasswordData(this.mPasswordToSet));
                    }
                } else {
                    v4_3.addAll(com.jtkj.led1248.light.utils.CoolledUUtils.getSetPasswordData(this.mPasswordToSet));
                }
            } else {
                v4_3.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getSetPasswordData(this.mPasswordToSet));
            }
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("onEvent>>>SetPasswordEvent>>>Result>>>").append(v4_3.toString()).append(">>>device>>").append(this.mDeviceCheckOrSetPassword.getMac()).toString());
            this.addDataStrings(v4_3);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SetTimerSwitchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>SetTimerSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.setTimerSwitch(p4.timerSwitchItemList));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SpeedDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>SpeedDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$StopWatchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>StopWatchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p4.actionType != 1) {
                if (p4.actionType != 2) {
                    if (p4.actionType == 3) {
                        this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getStopwatchStartOrStop(p4.isStartOrStop));
                    }
                    return;
                } else {
                    this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getStopwatchReset());
                    return;
                }
            } else {
                this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getStopwatchStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SwitchDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>SwitchDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$SynchronizeTimeEvent p4)
    {
        this.mDataStrings.clear();
        String v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>SynchronizeTimeEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getSynchronizeTime());
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$TextDataEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>TextDataEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$TextIconEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mCoolledxTextIconData.clear();
        this.mCoolledxTextIconData.addAll(p4.data);
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.mDeviceIndex = 0;
            this.mSendIndex = 0;
            if (this.mCoolledxTextIconData.size() >= 0) {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ProgressEvent(com.jtkj.library.commom.tools.NumberUitls.getPercent(0, this.mCoolledxTextIconData.size())));
            }
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.isMessageSuccess = 0;
            this.clearAllMessages();
            this.sendTextIconData(this.mSendIndex);
            this.mHandler.sendEmptyMessageDelayed(1002, 5000);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.DeviceManager$UxColorEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>UxColorEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p4.actionType != 2) {
                if (p4.actionType != 1) {
                    if (p4.actionType != 3) {
                        if (p4.actionType == 4) {
                            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getSetBrightness(p4.bright));
                        }
                        return;
                    } else {
                        this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.setColorMode(p4.modeIndex));
                        return;
                    }
                } else {
                    this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.setColorSpeed(p4.speed));
                    return;
                }
            } else {
                this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.setColor(p4.color, com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedCarManager$ILedCarGetDriveStateEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        String v0_4 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("onEvent>>>ILedCarManager.ILedCarGetDriveStateEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getDriveState());
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedCarManager$ILedCarSetDriveStateEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>ILedCarManager.ILedCarSetDriveStateEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.CoolledUXUtils.getSetDriveState(p4.state));
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$BrightILedClockSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.BrightILedClockSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$GetILedClockDeviceInfoEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v0_5 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_5, new StringBuilder("onEvent>>>GetILedClockDeviceInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$GetILedClockDeviceOTAVersionEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        String v0_4 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_4, new StringBuilder("onEvent>>>ILedClockManager.GetILedClockDeviceOTAVersionEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getDeviceOTAVersion());
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedCLockDeleteReminderEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedCLockDeleteReminderEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getDeleteReminder(p4.reminderId));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetNightModeEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedCLockGetNightModeEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getNightMode());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetReminderDetailEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedCLockGetReminderDetailEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getReminderDetail(p4.reminderId));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedCLockGetReminderEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedCLockGetReminderEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getReminder());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedCLockSetNightModeEvent p12)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedCLockSetNightModeEvent").append(p12.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getSetNightMode(p12.nightModeEnabled, p12.startTimeHour, p12.startTimeMinute, p12.endTimeHour, p12.endTimeMinute, p12.deviceStateEnabled, p12.brightness, p12.voiceControlEnabled, p12.wakeUpDuration, p12.voiceSensitivity));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockColorEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockColorEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p4.actionType != 2) {
                if (p4.actionType != 1) {
                    if (p4.actionType != 3) {
                        if (p4.actionType == 4) {
                            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getSetBrightness(p4.bright));
                        }
                        return;
                    } else {
                        this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.setColorMode(p4.modeIndex));
                        return;
                    }
                } else {
                    this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.setColorSpeed(p4.speed));
                    return;
                }
            } else {
                this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.setColor(p4.color, com.jtkj.led1248.light.device.DeviceManager.DEVICE_COLUMN));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockCountDownEvent p5)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockCountDownEvent").append(p5.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p5.actionType != 1) {
                if (p5.actionType != 2) {
                    if (p5.actionType == 3) {
                        com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockCountDownEvent>>>SET_START_OR_STOP>>>");
                        this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getCountDownStartOrStop(p5.isStartOrStop));
                    }
                    return;
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockCountDownEvent>>>RESET>>>");
                    this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getCountDownReset(p5.setHour, p5.setMinute, p5.setSeconds));
                    return;
                }
            } else {
                com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockCountDownEvent>>>GET_STATUS>>>");
                this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getCountDownStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetAlarmClockEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockGetAlarmClockEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getAlarmClockTime());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTemperatureAndHumidityEvent p4)
    {
        this.mDataStrings.clear();
        boolean v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockGetTemperatureAndHumidityEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getTemperatureAndHumidity(p4.type));
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTimerSwitchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockGetTimerSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getTimerSwitch());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockGetTomatoClockEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockGetTomatoClockEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getTomatoClockTime());
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockOTAUpgradeEvent p5)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        boolean v1_3 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_3, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v1_3, "onEvent>>>ILedClockManager.ILedClockOTAUpgradeEvent");
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mILedClockOTADataResult = com.jtkj.led1248.light.utils.ILedClockUtils.getOtaDataResult(p5.fileBytes, this.getOtaPackageSize());
                this.sendILedClockStartSendOTAUpgradeData();
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockProgramDataEvent p5)
    {
        this.checkMultiDevice(p5.isMultiDevice);
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        this.mILedClockProgramData.clear();
        int v1_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v1_0, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        if (this.isDeviceConnectedSuccess()) {
            if (com.jtkj.led1248.light.device.DeviceManager.isSwitchOnOff) {
                java.util.List v5_1 = p5.data;
                this.mILedClockProgramList = v5_1;
                this.mILedClockProgramCount = v5_1.size();
                this.mDeviceIndex = 0;
                this.mSendIndex = 0;
                this.mILedClockProgramIndex = 0;
                com.jtkj.library.commom.logger.CLog.i(v1_0, "onEvent>>>sendILedClockStartSendProgramData");
                com.jtkj.library.commom.logger.CLog.i(v1_0, "onEvent>>>checktime1");
                this.sendILedClockStartSendProgramData(this.mILedClockProgramList, this.mILedClockProgramIndex, this.mILedClockProgramCount);
                return;
            } else {
                this.mDataStrings.clear();
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(8));
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockScoreBoardEvent p5)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockScoreBoardEvent").append(p5.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p5.actionType != 1) {
                if (p5.actionType != 2) {
                    if (p5.actionType != 3) {
                        if (p5.actionType == 4) {
                            com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockScoreBoardEvent>>>SET_START_OR_STOP>>>");
                            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getScoreBoardStartOrStop(p5.isStartOrStop));
                        }
                        return;
                    } else {
                        com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockScoreBoardEvent>>>SET_TIME>>>");
                        this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getScoreBoardSetTime(p5.setMinute, p5.setSeconds, p5.isCountDown));
                        return;
                    }
                } else {
                    com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockScoreBoardEvent>>>SET_SCORE>>>");
                    this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getScoreBoardSetCore(p5.hostScore, p5.visitScore, p5.hostTotalScore, p5.visitTotalScore));
                    return;
                }
            } else {
                com.jtkj.library.commom.logger.CLog.i(v0_1, "onEvent>>>ILedClockManager.ILedClockScoreBoardEvent>>>GET_STATUS>>>");
                this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getScoreBoardStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockSetAlarmClockEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockSetAlarmClockEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getSetAlarmClockTime(p4.alarmClockItems));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockSetTimerSwitchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockSetTimerSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.setTimerSwitch(p4.timerSwitchItemList));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockSetTomatoClockEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockSetTomatoClockEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getSetTomatoClockTime(p4.tomatoClockItems));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockStopWatchEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockStopWatchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            if (p4.actionType != 1) {
                if (p4.actionType != 2) {
                    if (p4.actionType == 3) {
                        this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getStopwatchStartOrStop(p4.isStartOrStop));
                    }
                    return;
                } else {
                    this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getStopwatchReset());
                    return;
                }
            } else {
                this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getStopwatchStatus());
                return;
            }
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockSwitchEvent p4)
    {
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.music.LocalMusicManager$StopPlayEvent());
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        this.mDataStrings.clear();
        int v0_6 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_6, new StringBuilder("onEvent>>>ILedClockManager.ILedClockSwitchEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(p4.data);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$ILedClockSynchronizeTimeEvent p4)
    {
        this.mDataStrings.clear();
        String v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.ILedClockSynchronizeTimeEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.getSynchronizeTime());
            return;
        } else {
            this.mDataStrings.clear();
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$RotateILedClockSetEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.RotateILedClockSetEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            com.jtkj.led1248.light.device.DeviceManager.mRotate = p4.action;
            this.addDataStrings(com.jtkj.led1248.light.utils.ILedClockUtils.setRotate(p4.action));
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$SetILedClockDeviceInfoEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.SetILedClockDeviceInfoEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            java.util.List v4_2 = com.jtkj.led1248.light.utils.ILedClockUtils.setDeviceInfo(p4.action, p4.param);
            com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.SetILedClockDeviceInfoEvent>>data>>").append(v4_2.toString()).toString());
            this.addDataStrings(v4_2);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void onEvent(com.jtkj.led1248.light.device.ILedClockManager$SetILedClockVolumeEvent p4)
    {
        this.mDataStrings.clear();
        int v0_1 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("isMusic>>>").append(com.jtkj.led1248.light.device.DeviceManager.isMusic).toString());
        com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.SetILedClockVolumeEvent").append(p4.toString()).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.setAllDeviceEnableToSendData();
            java.util.List v4_2 = com.jtkj.led1248.light.utils.ILedClockUtils.setDeviceVolume(p4.value);
            com.jtkj.library.commom.logger.CLog.i(v0_1, new StringBuilder("onEvent>>>ILedClockManager.SetILedClockVolumeEvent>>data>>").append(v4_2.toString()).toString());
            this.addDataStrings(v4_2);
            return;
        } else {
            this.mDataStrings.clear();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void release()
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "release");
        com.jtkj.library.infrastructure.eventbus.EventAgent.unregister(this);
        this.exitToClearData();
        this.mHandler.removeCallbacksAndMessages(0);
        com.jtkj.led1248.light.device.DeviceManager.mInstance = 0;
        com.jtkj.library.fastble.BleManager.getInstance().destroy();
        return;
    }

    public void retrySendCoolledmStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendCoolledmStartSendProgramData>>>programIndex>>>").append(p5).append("programCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolledmProgramIndex = p5;
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$Program) p4.get(p5)), p5, p6);
            this.mCoolledmDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolledmDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "retrySendCoolledmStartSendProgramData>>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolledmProgramData.clear();
                    this.mCoolledmProgramData.addAll(this.mCoolledmDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendCoolledmStartSendProgramData>>>mCoolledmProgramData size>>>").append(this.mCoolledmProgramData.size()).append(">>>mCoolledmDataResult.beginDataForProgram>>>").append(this.mCoolledmDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolledmDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void retrySendCoolleduStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduStartSendProgramData>>>coolleduProgramIndex>>>").append(p5).append("coolleduProgramCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolleduProgramIndex = p5;
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram) p4.get(p5)), p5, p6);
            this.mCoolleduDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolleduDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolleduStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduProgramData.clear();
                    this.mCoolleduProgramData.addAll(this.mCoolleduDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduStartSendProgramData>>>mCoolledmProgramData size>>>").append(this.mCoolleduProgramData.size()).append(">>>mCoolleduDataResult.beginDataForProgram>>>").append(this.mCoolleduDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolleduDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void retrySendCoolleduxStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendCoolleduxStartSendProgramData>>>coolleduxProgramIndex>>>").append(p5).append("coolleduxProgramCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolleduxProgramIndex = p5;
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendCoolleduxStartSendProgramData>>>UX_PACKAGE_SIZE>>>").append(this.UX_PACKAGE_SIZE).toString());
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledUXUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduxProgram) p4.get(p5)), p5, p6, this.UX_PACKAGE_SIZE);
            this.mCoolleduxDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolleduxDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "retrySendCoolleduxStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduxProgramData.clear();
                    this.mCoolleduxProgramData.addAll(this.mCoolleduxDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendCoolleduxStartSendProgramData>>>mCoolleduxProgramData size>>>").append(this.mCoolleduxProgramData.size()).append(">>>mCoolleduxDataResult.beginDataForProgram>>>").append(this.mCoolleduxDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolleduxDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void retrySendILedClockStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendILedClockStartSendProgramData>>>iLedClockProgramIndex>>>").append(p5).append("iLedClockProgramCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mILedClockProgramIndex = p5;
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendILedClockStartSendProgramData>>>ILedClock_PACKAGE_SIZE>>>").append(this.ILedClock_PACKAGE_SIZE).toString());
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.ILedClockUtils.getDataResult(((com.jtkj.led1248.light.device.ILedClockManager$ILedClockProgram) p4.get(p5)), p5, p6, this.ILedClock_PACKAGE_SIZE);
            this.mILedClockDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mILedClockDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "retrySendILedClockStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mILedClockProgramData.clear();
                    this.mILedClockProgramData.addAll(this.mILedClockDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("retrySendILedClockStartSendProgramData>>>mILedClockProgramData size>>>").append(this.mILedClockProgramData.size()).append(">>>mILedClockDataResult.beginDataForProgram>>>").append(this.mILedClockDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mILedClockDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCooledxTextData(com.jtkj.led1248.light.emoji.TextEmojiManager$TextEmojiItems p12)
    {
        java.util.List v12_1;
        com.jtkj.led1248.light.device.DeviceManager.isMusic = 0;
        com.jtkj.led1248.light.utils.FontUtils v0_12 = com.jtkj.led1248.light.device.DeviceManager.DEVICE_TYPE;
        if (((v0_12 != 3) && ((v0_12 != 10) && ((v0_12 != 4) && ((v0_12 != 9) && ((v0_12 != 6) && ((v0_12 != 8) && ((v0_12 != 5) && (v0_12 != 11)))))))) || (com.jtkj.led1248.light.device.DeviceManager.COOL_LED_DEVICE_COLOR_TYPE != 1)) {
            v12_1 = 0;
        } else {
            if (v0_12 != 3) {
                if (v0_12 != 10) {
                    if (v0_12 != 4) {
                        if (v0_12 != 9) {
                            if (v0_12 != 6) {
                                if (v0_12 != 8) {
                                    if (v0_12 != 5) {
                                        if (v0_12 != 11) {
                                        } else {
                                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light16192Utils.getModeDataString(p12.mode)));
                                            v12_1 = com.jtkj.led1248.light.utils.Light16192Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                                        }
                                    } else {
                                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light16192Utils.getModeDataString(p12.mode)));
                                        v12_1 = com.jtkj.led1248.light.utils.Light16192Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                                    }
                                } else {
                                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1696Utils.getModeDataString(p12.mode)));
                                    v12_1 = com.jtkj.led1248.light.utils.Light1696Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                                }
                            } else {
                                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1696Utils.getModeDataString(p12.mode)));
                                v12_1 = com.jtkj.led1248.light.utils.Light1696Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                            }
                        } else {
                            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1664Utils.getModeDataString(p12.mode)));
                            v12_1 = com.jtkj.led1248.light.utils.Light1664Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                        }
                    } else {
                        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1664Utils.getModeDataString(p12.mode)));
                        v12_1 = com.jtkj.led1248.light.utils.Light1664Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                    }
                } else {
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1632Utils.getModeDataString(p12.mode)));
                    v12_1 = com.jtkj.led1248.light.utils.Light1632Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ModeDataEvent(com.jtkj.led1248.light.utils.Light1632Utils.getModeDataString(p12.mode)));
                v12_1 = com.jtkj.led1248.light.utils.Light1632Utils.getTextDataSevenColorStringsForEmoji(p12, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
            }
        }
        com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$TextIconEvent(v12_1));
        return;
    }

    public void sendCoolledmStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolledmStartSendProgramData>>>programIndex>>>").append(p5).append("programCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolledmProgramIndex = p5;
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$Program) p4.get(p5)), p5, p6);
            this.mCoolledmDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolledmDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolledmStartSendProgramData>>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolledmProgramData.clear();
                    this.mCoolledmProgramData.addAll(this.mCoolledmDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolledmStartSendProgramData>>>mCoolledmProgramData size>>>").append(this.mCoolledmProgramData.size()).append(">>>mCoolledmDataResult.beginDataForProgram>>>").append(this.mCoolledmDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolledmDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCoolleduStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolleduStartSendOTAUpgradeData");
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            int v1_2 = this.mCoolleduOTADataResult;
            if (v1_2 != 0) {
                if ((v1_2.beginDataForOTAUpgrade == null) || (this.mCoolleduOTADataResult.dataForForOTAUpgrade == null)) {
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduOTAUpgradeData.clear();
                    this.mCoolleduOTAUpgradeData.addAll(this.mCoolleduOTADataResult.dataForForOTAUpgrade);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "start sendCoolleduStartSendOTAUpgradeData>>>");
                    this.addDataStrings(this.mCoolleduOTADataResult.beginDataForOTAUpgrade);
                    this.mHandler.sendEmptyMessageDelayed(1005, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCoolleduStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduStartSendProgramData>>>coolleduProgramIndex>>>").append(p5).append("coolleduProgramCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolleduProgramIndex = p5;
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram) p4.get(p5)), p5, p6);
            this.mCoolleduDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolleduDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolleduStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduProgramData.clear();
                    this.mCoolleduProgramData.addAll(this.mCoolleduDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduStartSendProgramData>>>mCoolledmProgramData size>>>").append(this.mCoolleduProgramData.size()).append(">>>mCoolleduDataResult.beginDataForProgram>>>").append(this.mCoolleduDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolleduDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCoolleduStartSendProgramData(java.util.List p4, int p5, int p6, int p7)
    {
        String v0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0, new StringBuilder("sendCoolleduStartSendProgramData>>>coolleduProgramIndex>>>").append(p5).append(">>>coolleduProgramCount>>>").append(p6).append(">>>driveState>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolleduProgramIndex = p5;
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_3 = com.jtkj.led1248.light.utils.CoolledUUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduProgram) p4.get(p5)), p7);
            this.mCoolleduDataResult = v4_3;
            if (v4_3 != null) {
                if ((v4_3.beginDataForProgram == null) || (this.mCoolleduDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0, "sendCoolleduStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduProgramData.clear();
                    this.mCoolleduProgramData.addAll(this.mCoolleduDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0, new StringBuilder("sendCoolleduStartSendProgramData>>>mCoolledmProgramData size>>>").append(this.mCoolleduProgramData.size()).append(">>>mCoolleduDataResult.beginDataForProgram>>>").append(this.mCoolleduDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolleduDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCoolleduxStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolleduStartSendOTAUpgradeData");
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            int v1_2 = this.mCoolleduxOTADataResult;
            if (v1_2 != 0) {
                if ((v1_2.beginDataForOTAUpgrade == null) || (this.mCoolleduxOTADataResult.dataForForOTAUpgrade == null)) {
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduxOTAUpgradeData.clear();
                    this.mCoolleduxOTAUpgradeData.addAll(this.mCoolleduxOTADataResult.dataForForOTAUpgrade);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "start sendCoolleduxStartSendOTAUpgradeData>>>");
                    this.addDataStrings(this.mCoolleduxOTADataResult.beginDataForOTAUpgrade);
                    this.mHandler.sendEmptyMessageDelayed(1005, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendCoolleduxStartSendProgramData(java.util.List p8, int p9, int p10)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduxStartSendProgramData>>>coolleduxProgramIndex>>>").append(p9).append("coolleduxProgramCount>>>").append(p10).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mCoolleduxProgramIndex = p9;
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduxStartSendProgramData>>>UX_PACKAGE_SIZE>>>").append(this.UX_PACKAGE_SIZE).toString());
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduxStartSendProgramData>>>CoolleduxDeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.CoolleduxDeviceVersion).toString());
            if (!com.jtkj.led1248.light.device.DeviceManager.isILedCar) {
                this.mCoolleduxDataResult = com.jtkj.led1248.light.utils.CoolledUXUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduxProgram) p8.get(p9)), p9, p10, this.UX_PACKAGE_SIZE);
            } else {
                this.mCoolleduxDataResult = com.jtkj.led1248.light.utils.CoolledUXUtils.getDataResult(((com.jtkj.led1248.light.device.DeviceManager$CoolleduxProgram) p8.get(p9)), p9, p10, this.UX_PACKAGE_SIZE, this.mGroupType, com.jtkj.led1248.light.device.DeviceManager.mDriveState);
            }
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v8_16 = this.mCoolleduxDataResult;
            if (v8_16 != null) {
                if ((v8_16.beginDataForProgram == null) || (this.mCoolleduxDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "sendCoolleduxStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mCoolleduxProgramData.clear();
                    this.mCoolleduxProgramData.addAll(this.mCoolleduxDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendCoolleduxStartSendProgramData>>>mCoolleduxProgramData size>>>").append(this.mCoolleduxProgramData.size()).append(">>>mCoolleduxDataResult.beginDataForProgram>>>").append(this.mCoolleduxDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mCoolleduxDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendILedClockStartSendOTAUpgradeData()
    {
        com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, "sendILedClockStartSendOTAUpgradeData");
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            int v1_2 = this.mILedClockOTADataResult;
            if (v1_2 != 0) {
                if ((v1_2.beginDataForOTAUpgrade == null) || (this.mILedClockOTADataResult.dataForForOTAUpgrade == null)) {
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mILedClockOTAUpgradeData.clear();
                    this.mILedClockOTAUpgradeData.addAll(this.mILedClockOTADataResult.dataForForOTAUpgrade);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "start sendILedClockStartSendOTAUpgradeData>>>");
                    this.addDataStrings(this.mILedClockOTADataResult.beginDataForOTAUpgrade);
                    this.mHandler.sendEmptyMessageDelayed(1005, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void sendILedClockStartSendProgramData(java.util.List p4, int p5, int p6)
    {
        long v0_0 = com.jtkj.led1248.light.device.DeviceManager.TAG;
        com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendILedClockStartSendProgramData>>>iledClockProgramIndex>>>").append(p5).append("iledClockProgramCount>>>").append(p6).toString());
        if (this.isDeviceConnectedSuccess()) {
            this.isMessageSuccess = 0;
            this.mMaxRetryTimesForAll = 3;
            this.mMaxRetryTimesForPackage = 3;
            this.clearAllMessages();
            this.setDeviceEnableToSendData(this.mDeviceIndex);
            this.mILedClockProgramIndex = p5;
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendILedClockStartSendProgramData>>>ILedClock_PACKAGE_SIZE>>>").append(this.ILedClock_PACKAGE_SIZE).toString());
            com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendILedClockStartSendProgramData>>>ILedClockDeviceVersion>>>").append(com.jtkj.led1248.light.device.DeviceManager.ILedClockDeviceVersion).toString());
            com.jtkj.led1248.light.device.DeviceManager$DeviceHandler v4_6 = com.jtkj.led1248.light.utils.ILedClockUtils.getDataResult(((com.jtkj.led1248.light.device.ILedClockManager$ILedClockProgram) p4.get(p5)), p5, p6, this.ILedClock_PACKAGE_SIZE);
            this.mILedClockDataResult = v4_6;
            if (v4_6 != null) {
                if ((v4_6.beginDataForProgram == null) || (this.mILedClockDataResult.dataForProgram == null)) {
                    com.jtkj.library.commom.logger.CLog.i(v0_0, "sendILedClockStartSendProgramData>>error>>>");
                    com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                    return;
                } else {
                    this.mILedClockProgramData.clear();
                    this.mILedClockProgramData.addAll(this.mILedClockDataResult.dataForProgram);
                    com.jtkj.library.commom.logger.CLog.i(v0_0, new StringBuilder("sendILedClockStartSendProgramData>>>mILedClockProgramData size>>>").append(this.mILedClockProgramData.size()).append(">>>mmILedClockDataResult.beginDataForProgram>>>").append(this.mILedClockDataResult.beginDataForProgram.toString()).toString());
                    this.addDataStrings(this.mILedClockDataResult.beginDataForProgram);
                    this.mHandler.sendEmptyMessageDelayed(1003, 5000);
                    return;
                }
            } else {
                com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(4));
                return;
            }
        } else {
            this.mDataStrings.clear();
            this.clearAllMessages();
            com.jtkj.library.infrastructure.eventbus.EventAgent.post(new com.jtkj.led1248.light.device.DeviceManager$ResponseEvent(2));
            return;
        }
    }

    public void setBleDeviceItems(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        this.mBleDeviceItems = v0_1;
        v0_1.addAll(p2);
        return;
    }

    public void setDeviceSendEnable(String p1, boolean p2, com.jtkj.led1248.light.device.DeviceManager$BleDeviceItem p3)
    {
        this.mChooseMultDeviceMap.put(p1, Boolean.valueOf(p2));
        return;
    }

    public void setUxDeviceVersion(String p2, int p3)
    {
        this.mUxDeviceVersionMap.put(p2, Integer.valueOf(p3));
        return;
    }

    public void startSearchDevice()
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.device.DeviceManager.TAG, "startSearchDevice");
        com.jtkj.led1248.CoolLED.getInstance().getExecutorService().submit(new com.jtkj.led1248.light.device.DeviceManager$4(this));
        return;
    }
}
