package com.jtkj.led1248.light.utils;
public class CoolledMUtils extends com.jtkj.led1248.light.utils.LightUtils {
    private static final String TAG = "CoolledMUtils";
    private static final java.util.List colorFulFrameTypeOne = None;
    private static final java.util.List colorFulFrameTypeThree = None;
    private static final java.util.List colorFulFrameTypeTwo = None;
    private static final java.util.List colorType15to28 = None;
    private static final java.util.List colorTypeEight = None;
    private static final java.util.List colorTypeEleven = None;
    private static final java.util.List colorTypeFive = None;
    private static final java.util.List colorTypeFour = None;
    private static final java.util.List colorTypeFourTeen = None;
    private static final java.util.List colorTypeNine = None;
    private static final java.util.List colorTypeOne = None;
    private static final java.util.List colorTypeSeven = None;
    private static final java.util.List colorTypeSix = None;
    private static final java.util.List colorTypeTen = None;
    private static final java.util.List colorTypeThirteen = None;
    private static final java.util.List colorTypeThree = None;
    private static final java.util.List colorTypeTwelve = None;
    private static final java.util.List colorTypeTwo = None;
    private static final String fourColorFrame1 = "0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80";
    private static final String fourColorFrame2 = "0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00";
    private static final String fourColorFrame3 = "0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80";
    private static final String fourColorFrame4 = "0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00";
    private static final java.util.List redColorFrameTypeOne;
    private static final java.util.List redColorFrameTypeThree;
    private static final java.util.List redColorFrameTypeTwo;
    private static final java.util.List redFrame1;
    private static final java.util.List redFrame2;
    private static final java.util.List redFrame3;
    private static final java.util.List threeColorFrameTypeOne;
    private static final java.util.List threeColorFrameTypeThree;
    private static final java.util.List threeColorFrameTypeTwo;
    private static final java.util.List yellow1;
    private static final java.util.List yellow2;
    private static final java.util.List yellow3;

    static CoolledMUtils()
    {
        com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledMUtils$1();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledMUtils$2();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledMUtils$3();
        com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledMUtils$4();
        com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledMUtils$5();
        com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledMUtils$6();
        com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeOne = new com.jtkj.led1248.light.utils.CoolledMUtils$7();
        com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeTwo = new com.jtkj.led1248.light.utils.CoolledMUtils$8();
        com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeThree = new com.jtkj.led1248.light.utils.CoolledMUtils$9();
        com.jtkj.led1248.light.utils.CoolledMUtils.redFrame1 = new com.jtkj.led1248.light.utils.CoolledMUtils$10();
        com.jtkj.led1248.light.utils.CoolledMUtils.redFrame2 = new com.jtkj.led1248.light.utils.CoolledMUtils$11();
        com.jtkj.led1248.light.utils.CoolledMUtils.redFrame3 = new com.jtkj.led1248.light.utils.CoolledMUtils$12();
        com.jtkj.led1248.light.utils.CoolledMUtils.yellow1 = new com.jtkj.led1248.light.utils.CoolledMUtils$13();
        com.jtkj.led1248.light.utils.CoolledMUtils.yellow2 = new com.jtkj.led1248.light.utils.CoolledMUtils$14();
        com.jtkj.led1248.light.utils.CoolledMUtils.yellow3 = new com.jtkj.led1248.light.utils.CoolledMUtils$15();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeOne = new com.jtkj.led1248.light.utils.CoolledMUtils$16();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTwo = new com.jtkj.led1248.light.utils.CoolledMUtils$17();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeThree = new com.jtkj.led1248.light.utils.CoolledMUtils$18();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFour = new com.jtkj.led1248.light.utils.CoolledMUtils$19();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFive = new com.jtkj.led1248.light.utils.CoolledMUtils$20();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeSix = new com.jtkj.led1248.light.utils.CoolledMUtils$21();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeSeven = new com.jtkj.led1248.light.utils.CoolledMUtils$22();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeEight = new com.jtkj.led1248.light.utils.CoolledMUtils$23();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeNine = new com.jtkj.led1248.light.utils.CoolledMUtils$24();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTen = new com.jtkj.led1248.light.utils.CoolledMUtils$25();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeEleven = new com.jtkj.led1248.light.utils.CoolledMUtils$26();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTwelve = new com.jtkj.led1248.light.utils.CoolledMUtils$27();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeThirteen = new com.jtkj.led1248.light.utils.CoolledMUtils$28();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFourTeen = new com.jtkj.led1248.light.utils.CoolledMUtils$29();
        com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28 = new com.jtkj.led1248.light.utils.CoolledMUtils$30();
        return;
    }

    public CoolledMUtils()
    {
        return;
    }

    private static java.util.List convertData(java.util.List p4, int p5)
    {
        while (p5 < p4.size()) {
            int v0_1 = Integer.valueOf(((String) p4.get(p5)), 16).intValue();
            if ((v0_1 <= Integer.parseInt("00", 16)) || (v0_1 >= Integer.valueOf("04", 16).intValue())) {
                p5++;
            } else {
                p4.add(p5, "02");
                p4.set((p5 + 1), com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt((v0_1 ^ Integer.valueOf("04", 16).intValue())));
                int v5_1 = (p5 + 2);
                if (v5_1 > (p4.size() - 1)) {
                    break;
                }
                return com.jtkj.led1248.light.utils.CoolledMUtils.convertData(p4, v5_1);
            }
        }
        return p4;
    }

    public static java.util.List convertEnd(java.util.List p3)
    {
        int v0_1 = Integer.valueOf("00", 16).intValue();
        java.util.List v3_2 = p3.iterator();
        while (v3_2.hasNext()) {
            v0_1 ^= Integer.valueOf(((String) v3_2.next()), 16).intValue();
        }
        return com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForInt(v0_1);
    }

    public static java.util.List dealWithArbAndXbl(java.util.List p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        int v1_0 = (p3.size() - 1);
        while (v1_0 >= 0) {
            v0_1.add(((com.jtkj.led1248.light.emoji.TextEmojiManager$TextEmojiItem) p3.get(v1_0)));
            v1_0--;
        }
        return v0_1;
    }

    public static java.util.List getAnimationData(java.util.List p2)
    {
        return com.jtkj.led1248.light.utils.Light1696Utils.getAnimationDataForCooledXSevenColor(p2, 96, 16);
    }

    public static java.util.List getAnimationData(java.util.List p0, int p1, int p2)
    {
        return com.jtkj.led1248.light.utils.Light1696Utils.getAnimationDataForCooledXSevenColor(p0, p1, p2);
    }

    public static java.util.List getCheckPasswordData(String p6)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0d");
        int v1_4 = new java.util.Random().nextInt(256);
        com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v1_4);
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v1_4));
        int v2_1 = 0;
        while (v2_1 < p6.length()) {
            String v3_6 = Integer.valueOf(new StringBuilder("0").append(p6.charAt(v2_1)).toString(), 16).intValue();
            com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v3_6);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt((v3_6 ^ v1_4)));
            v2_1++;
        }
        java.util.List v6_3 = Integer.valueOf("00", 16).intValue();
        int v1_1 = 2;
        while (v1_1 < v0_1.size()) {
            v6_3 ^= Integer.valueOf(((String) v0_1.get(v1_1)), 16).intValue();
            v1_1++;
        }
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v6_3));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getDataForCombineProgram(com.jtkj.led1248.light.device.DeviceManager$CombineProgram p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        if (p3.getType() != 2) {
            if (p3.getType() != 1) {
                if (p3.getType() != 4) {
                    if (p3.getType() == 3) {
                        java.util.List v3_2 = ((com.jtkj.led1248.light.device.DeviceManager$TextCombineProgram) p3).textItem;
                        if (v3_2.textContentProgramContent != null) {
                            if (v3_2.textCustomColorProgramContent != null) {
                                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithTextCustomColorProgramContent(v3_2.textCustomColorProgramContent));
                            }
                            if (v3_2.textAutoColorProgramContent != null) {
                                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithTextAutoColorProgramContent(v3_2.textAutoColorProgramContent));
                            }
                            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithTextContentProgramContent(v3_2.textContentProgramContent));
                        }
                        if (v3_2.frameItem != null) {
                            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithFrameProgramContent(v3_2.frameItem));
                        }
                    }
                    return v0_1;
                } else {
                    v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithFrameProgramContent(((com.jtkj.led1248.light.device.DeviceManager$FrameCombineProgram) p3).frameProgramContent));
                    return v0_1;
                }
            } else {
                v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithGraffitiCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$GraffitiCombineProgram) p3).graffitiItem.graffitiProgramContent));
                return v0_1;
            }
        } else {
            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithAnimationCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$AnimationCombineProgram) p3).animationItem.animationProgramContent));
            return v0_1;
        }
    }

    public static java.util.List getDataForProgram(com.jtkj.led1248.light.device.DeviceManager$Program p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.Iterator v2_2 = p2.combinePrograms.iterator();
        while (v2_2.hasNext()) {
            v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataForCombineProgram(((com.jtkj.led1248.light.device.DeviceManager$CombineProgram) v2_2.next())));
        }
        return v0_1;
    }

    public static java.util.List getDataFromHexString(String p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.Iterator v3_3 = java.util.Arrays.asList(p3.split(",")).iterator();
        while (v3_3.hasNext()) {
            v0_1.add(((String) v3_3.next()).substring(2));
        }
        return v0_1;
    }

    public static java.util.List getDataPacket(java.util.List p8, String p9)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        java.util.List v2_7 = (p8.size() / 1024);
        java.util.ArrayList v3_14 = (p8.size() % 1024);
        int v4 = 0;
        int v5 = 0;
        while (v5 < v2_7) {
            java.util.List v6_0 = (v5 * 1024);
            v5++;
            v1_1.add(p8.subList(v6_0, (v5 * 1024)));
        }
        if (v3_14 > null) {
            v1_1.add(p8.subList((v2_7 * 1024), p8.size()));
        }
        while (v4 < v1_1.size()) {
            java.util.List v2_4 = new java.util.ArrayList();
            v2_4.add("00");
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(p8));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwo(v4));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwo(((java.util.List) v1_1.get(v4)).size()));
            v2_4.addAll(((java.util.Collection) v1_1.get(v4)));
            v2_4.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.convertEnd(v2_4));
            java.util.ArrayList v3_12 = new java.util.ArrayList();
            v3_12.add(p9);
            v3_12.addAll(v2_4);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v3_12));
            v4++;
        }
        return v0_1;
    }

    public static com.jtkj.led1248.light.utils.CoolledMUtils$DataResult getDataResult(com.jtkj.led1248.light.device.DeviceManager$Program p1, int p2, int p3)
    {
        com.jtkj.led1248.light.utils.CoolledMUtils$DataResult v0_1 = new com.jtkj.led1248.light.utils.CoolledMUtils$DataResult();
        java.util.List v1_3 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataWithProgram(p1);
        v0_1.beginDataForProgram = com.jtkj.led1248.light.utils.CoolledMUtils.getStartDataForProgram(v1_3, p2, p3);
        java.util.ArrayList v2_3 = new java.util.ArrayList();
        v2_3.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress.getLzssCompressData(v1_3), "03"));
        v0_1.dataForProgram = v2_3;
        return v0_1;
    }

    public static java.util.List getDataWithAnimationCombineProgram(com.jtkj.led1248.light.device.DeviceManager$AnimationProgramContent p5)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("03");
        java.util.List v2_16 = 0;
        while (v2_16 < 7) {
            v1_1.add("00");
            v2_16++;
        }
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p5.layerType));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.showHeight));
        v1_1.add("00");
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.speed));
        java.util.List v5_2 = com.jtkj.led1248.light.utils.CoolledMUtils.getAnimationData(p5.mListDrawItems, p5.showWidth, p5.showHeight);
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(v5_2.size()));
        v1_1.addAll(v5_2);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDataWithFrameProgramContent(com.jtkj.led1248.light.device.DeviceManager$FrameProgramContent p7)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledMUtils.TAG, new StringBuilder("getDataWithFrameProgramContent>>>").append(p7.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("04");
        java.util.List v2_15 = 0;
        while (v2_15 < 7) {
            v1_2.add("00");
            v2_15++;
        }
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p7.layerType));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p7.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p7.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p7.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p7.showHeight));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p7.frameShowType));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p7.speed));
        if (p7.frameType != 1) {
            if (p7.frameType != 2) {
                if (p7.frameType != 3) {
                    if (p7.frameType != 4) {
                        if (p7.frameType != 5) {
                            if (p7.frameType != 6) {
                                if (p7.frameType != 7) {
                                    if (p7.frameType != 8) {
                                        if (p7.frameType != 9) {
                                            if (p7.frameType != 10) {
                                                if (p7.frameType != 11) {
                                                    if (p7.frameType != 12) {
                                                        if (p7.frameType != 13) {
                                                            if (p7.frameType != 14) {
                                                                if (p7.frameType != 15) {
                                                                    if (p7.frameType != 16) {
                                                                        if (p7.frameType != 17) {
                                                                            if (p7.frameType != 18) {
                                                                                if (p7.frameType == 19) {
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                                    java.util.List v7_3 = com.jtkj.led1248.light.utils.CoolledMUtils.yellow3;
                                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_3.size()));
                                                                                    v1_2.addAll(v7_3);
                                                                                }
                                                                            } else {
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                                java.util.List v7_5 = com.jtkj.led1248.light.utils.CoolledMUtils.yellow2;
                                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_5.size()));
                                                                                v1_2.addAll(v7_5);
                                                                            }
                                                                        } else {
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                            java.util.List v7_7 = com.jtkj.led1248.light.utils.CoolledMUtils.yellow1;
                                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_7.size()));
                                                                            v1_2.addAll(v7_7);
                                                                        }
                                                                    } else {
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                        java.util.List v7_9 = com.jtkj.led1248.light.utils.CoolledMUtils.redFrame3;
                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_9.size()));
                                                                        v1_2.addAll(v7_9);
                                                                    }
                                                                } else {
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                    java.util.List v7_11 = com.jtkj.led1248.light.utils.CoolledMUtils.redFrame2;
                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_11.size()));
                                                                    v1_2.addAll(v7_11);
                                                                }
                                                            } else {
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                java.util.List v7_13 = com.jtkj.led1248.light.utils.CoolledMUtils.redFrame1;
                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_13.size()));
                                                                v1_2.addAll(v7_13);
                                                            }
                                                        } else {
                                                            java.util.List v7_15 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataFromHexString("0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00");
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_15.size()));
                                                            v1_2.addAll(v7_15);
                                                        }
                                                    } else {
                                                        java.util.List v7_17 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataFromHexString("0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80");
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_17.size()));
                                                        v1_2.addAll(v7_17);
                                                    }
                                                } else {
                                                    java.util.List v7_19 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataFromHexString("0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x80,0x80,0x80,0x00,0x00");
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_19.size()));
                                                    v1_2.addAll(v7_19);
                                                }
                                            } else {
                                                java.util.List v7_21 = com.jtkj.led1248.light.utils.CoolledMUtils.getDataFromHexString("0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80");
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_21.size()));
                                                v1_2.addAll(v7_21);
                                            }
                                        } else {
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                            java.util.List v7_23 = com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeThree;
                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_23.size()));
                                            v1_2.addAll(v7_23);
                                        }
                                    } else {
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                        java.util.List v7_25 = com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeTwo;
                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_25.size()));
                                        v1_2.addAll(v7_25);
                                    }
                                } else {
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                    java.util.List v7_27 = com.jtkj.led1248.light.utils.CoolledMUtils.redColorFrameTypeOne;
                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_27.size()));
                                    v1_2.addAll(v7_27);
                                }
                            } else {
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                java.util.List v7_29 = com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeThree;
                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_29.size()));
                                v1_2.addAll(v7_29);
                            }
                        } else {
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                            java.util.List v7_31 = com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeTwo;
                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_31.size()));
                            v1_2.addAll(v7_31);
                        }
                    } else {
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                        java.util.List v7_33 = com.jtkj.led1248.light.utils.CoolledMUtils.threeColorFrameTypeOne;
                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_33.size()));
                        v1_2.addAll(v7_33);
                    }
                } else {
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                    java.util.List v7_35 = com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeThree;
                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_35.size()));
                    v1_2.addAll(v7_35);
                }
            } else {
                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                java.util.List v7_37 = com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeTwo;
                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_37.size()));
                v1_2.addAll(v7_37);
            }
        } else {
            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
            java.util.List v7_39 = com.jtkj.led1248.light.utils.CoolledMUtils.colorFulFrameTypeOne;
            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v7_39.size()));
            v1_2.addAll(v7_39);
        }
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithGraffitiCombineProgram(com.jtkj.led1248.light.device.DeviceManager$GraffitiProgramContent p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("02");
        java.util.List v2_19 = 0;
        while (v2_19 < 7) {
            v1_1.add("00");
            v2_19++;
        }
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.layerType));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.showHeight));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.mode));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.speed));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.stayTime));
        java.util.List v4_2 = com.jtkj.led1248.light.utils.CoolledMUtils.getGraffitiData(p4.mDrawItems, p4.showWidth, p4.showHeight);
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(v4_2.size()));
        v1_1.addAll(v4_2);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDataWithProgram(com.jtkj.led1248.light.device.DeviceManager$Program p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.List v1_4 = new java.util.ArrayList();
        int v2 = 0;
        while (v2 < 8) {
            v1_4.add("00");
            v2++;
        }
        v0_1.addAll(v1_4);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForWithOneByte(p4.getContentNumber()));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForWithOneByte(p4.showCount));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataForProgram(p4));
        return v0_1;
    }

    public static java.util.List getDataWithTextAutoColorProgramContent(com.jtkj.led1248.light.device.DeviceManager$TextAutoColorProgramContent p13)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledMUtils.TAG, new StringBuilder("getDataWithTextAutoColorProgramContent>>>").append(p13.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("05");
        String v3_9 = 0;
        while (v3_9 < 7) {
            v1_2.add("00");
            v3_9++;
        }
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p13.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p13.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p13.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p13.showHeight));
        if (p13.autoColorType != 1) {
            if (p13.autoColorType != 2) {
                if (p13.autoColorType != 3) {
                    if (p13.autoColorType != 4) {
                        if (p13.autoColorType != 5) {
                            if (p13.autoColorType != 6) {
                                if (p13.autoColorType != 7) {
                                    if (p13.autoColorType != 8) {
                                        if (p13.autoColorType != 9) {
                                            if (p13.autoColorType != 10) {
                                                if (p13.autoColorType != 11) {
                                                    if (p13.autoColorType != 12) {
                                                        if (p13.autoColorType != 13) {
                                                            if (p13.autoColorType != 14) {
                                                                if (p13.autoColorType != 15) {
                                                                    if (p13.autoColorType != 16) {
                                                                        if (p13.autoColorType != 17) {
                                                                            if (p13.autoColorType != 18) {
                                                                                if (p13.autoColorType != 19) {
                                                                                    if (p13.autoColorType != 20) {
                                                                                        if (p13.autoColorType != 21) {
                                                                                            if (p13.autoColorType != 22) {
                                                                                                if (p13.autoColorType != 23) {
                                                                                                    if (p13.autoColorType != 24) {
                                                                                                        if (p13.autoColorType != 25) {
                                                                                                            if (p13.autoColorType != 26) {
                                                                                                                if (p13.autoColorType != 27) {
                                                                                                                    if (p13.autoColorType == 28) {
                                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(8));
                                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                                        java.util.List v13_5 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_5.size()));
                                                                                                                        v1_2.addAll(v13_5);
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(8));
                                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                                    java.util.List v13_10 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_10.size()));
                                                                                                                    v1_2.addAll(v13_10);
                                                                                                                }
                                                                                                            } else {
                                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(7));
                                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                                java.util.List v13_15 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_15.size()));
                                                                                                                v1_2.addAll(v13_15);
                                                                                                            }
                                                                                                        } else {
                                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(7));
                                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                            java.util.List v13_20 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_20.size()));
                                                                                                            v1_2.addAll(v13_20);
                                                                                                        }
                                                                                                    } else {
                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(6));
                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                        java.util.List v13_25 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_25.size()));
                                                                                                        v1_2.addAll(v13_25);
                                                                                                    }
                                                                                                } else {
                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(6));
                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                    java.util.List v13_30 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_30.size()));
                                                                                                    v1_2.addAll(v13_30);
                                                                                                }
                                                                                            } else {
                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(5));
                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                                java.util.List v13_35 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_35.size()));
                                                                                                v1_2.addAll(v13_35);
                                                                                            }
                                                                                        } else {
                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(5));
                                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                            java.util.List v13_40 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_40.size()));
                                                                                            v1_2.addAll(v13_40);
                                                                                        }
                                                                                    } else {
                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                        java.util.List v13_45 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_45.size()));
                                                                                        v1_2.addAll(v13_45);
                                                                                    }
                                                                                } else {
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                    java.util.List v13_50 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_50.size()));
                                                                                    v1_2.addAll(v13_50);
                                                                                }
                                                                            } else {
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(2));
                                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                                java.util.List v13_55 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_55.size()));
                                                                                v1_2.addAll(v13_55);
                                                                            }
                                                                        } else {
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(2));
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                            java.util.List v13_60 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_60.size()));
                                                                            v1_2.addAll(v13_60);
                                                                        }
                                                                    } else {
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                        java.util.List v13_65 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_65.size()));
                                                                        v1_2.addAll(v13_65);
                                                                    }
                                                                } else {
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                    java.util.List v13_70 = com.jtkj.led1248.light.utils.CoolledMUtils.colorType15to28;
                                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_70.size()));
                                                                    v1_2.addAll(v13_70);
                                                                }
                                                            } else {
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(8));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                                java.util.List v13_75 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFourTeen;
                                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_75.size()));
                                                                v1_2.addAll(v13_75);
                                                            }
                                                        } else {
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(8));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                            java.util.List v13_80 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeThirteen;
                                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_80.size()));
                                                            v1_2.addAll(v13_80);
                                                        }
                                                    } else {
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(7));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                        java.util.List v13_85 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTwelve;
                                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_85.size()));
                                                        v1_2.addAll(v13_85);
                                                    }
                                                } else {
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(7));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                    java.util.List v13_90 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeEleven;
                                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_90.size()));
                                                    v1_2.addAll(v13_90);
                                                }
                                            } else {
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(6));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                                java.util.List v13_95 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTen;
                                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_95.size()));
                                                v1_2.addAll(v13_95);
                                            }
                                        } else {
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(6));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                            java.util.List v13_100 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeNine;
                                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_100.size()));
                                            v1_2.addAll(v13_100);
                                        }
                                    } else {
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(5));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                        java.util.List v13_105 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeEight;
                                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_105.size()));
                                        v1_2.addAll(v13_105);
                                    }
                                } else {
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(5));
                                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                    java.util.List v13_110 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeSeven;
                                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_110.size()));
                                    v1_2.addAll(v13_110);
                                }
                            } else {
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(4));
                                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                                java.util.List v13_115 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeSix;
                                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_115.size()));
                                v1_2.addAll(v13_115);
                            }
                        } else {
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                            java.util.List v13_120 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFive;
                            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_120.size()));
                            v1_2.addAll(v13_120);
                        }
                    } else {
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(3));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(2));
                        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                        java.util.List v13_125 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeFour;
                        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_125.size()));
                        v1_2.addAll(v13_125);
                    }
                } else {
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(2));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                    v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                    java.util.List v13_130 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeThree;
                    v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_130.size()));
                    v1_2.addAll(v13_130);
                }
            } else {
                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
                v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
                java.util.List v13_135 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeTwo;
                v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_135.size()));
                v1_2.addAll(v13_135);
            }
        } else {
            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p13.speed));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
            v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
            java.util.List v13_140 = com.jtkj.led1248.light.utils.CoolledMUtils.colorTypeOne;
            v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v13_140.size()));
            v1_2.addAll(v13_140);
        }
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithTextContentProgramContent(com.jtkj.led1248.light.device.DeviceManager$TextContentProgramContent p4)
    {
        com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledMUtils.TAG, new StringBuilder("getDataWithTextContentProgramContent>>>").append(p4.toString()).toString());
        java.util.ArrayList v0_2 = new java.util.ArrayList();
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.add("01");
        java.util.List v2_1 = 0;
        while (v2_1 < 7) {
            v1_2.add("00");
            v2_1++;
        }
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.layerType));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.startColumn));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.startRow));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.showWidth));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p4.showHeight));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.mode));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.speed));
        v1_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p4.stayTime));
        java.util.List v4_1 = com.jtkj.led1248.light.utils.CoolledMUtils.getTextDataForEmoji(p4, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(v4_1.data.size()));
        v1_2.addAll(v4_1.data);
        v0_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_2.size() + 4)));
        v0_2.addAll(v1_2);
        return v0_2;
    }

    public static java.util.List getDataWithTextCustomColorProgramContent(com.jtkj.led1248.light.device.DeviceManager$TextCustomColorProgramContent p5)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        java.util.ArrayList v1_1 = new java.util.ArrayList();
        v1_1.add("06");
        java.util.List v2_22 = 0;
        while (v2_22 < 7) {
            v1_1.add("00");
            v2_22++;
        }
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.startColumn));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.startRow));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.showWidth));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(p5.showHeight));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p5.mode));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p5.speed));
        v1_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p5.stayTime));
        v1_1.add("00");
        java.util.List v5_1 = com.jtkj.led1248.light.utils.CoolledMUtils.getTextCustomColorDataForEmoji(p5, com.jtkj.led1248.light.utils.FontUtils.getInstance(com.jtkj.led1248.CoolLED.getInstance()));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v5_1.textNumber));
        v1_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithTwoByte(v5_1.allTextWidth));
        v1_1.addAll(v5_1.allTextWidths);
        v1_1.addAll(v5_1.allTextColors);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte((v1_1.size() + 4)));
        v0_1.addAll(v1_1);
        return v0_1;
    }

    public static java.util.List getDeviceInfo()
    {
        java.util.List v0_1 = new java.util.ArrayList();
        v0_1.add("1f");
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getGraffitiData(java.util.List p2)
    {
        return com.jtkj.led1248.light.utils.Light1696Utils.getDrawListDataForCooledXSevenColor(p2, 96, 16);
    }

    public static java.util.List getGraffitiData(java.util.List p0, int p1, int p2)
    {
        return com.jtkj.led1248.light.utils.Light1696Utils.getDrawListDataForCooledXSevenColor(p0, p1, p2);
    }

    public static java.util.List getMusicDataString(int p2, int[] p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("01");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForInt(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataString(p3));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getOTAUpdate(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataPacket(com.jtkj.led1248.light.utils.CoolledMUtils$LzssCompress.getLzssCompressData(p2), "ff"));
        return v0_1;
    }

    private static java.util.List getSendDataWithInfo(java.util.List p3)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("01");
        java.util.ArrayList v1_2 = new java.util.ArrayList();
        v1_2.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getDataStringLength(p3));
        v1_2.addAll(p3);
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.convertData(v1_2, 0));
        v0_1.add("03");
        return v0_1;
    }

    public static java.util.List getSetBrightness(int p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("04");
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(p2));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetMirror(boolean p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0c");
        if (p2 == null) {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
        } else {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
        }
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetPasswordData(String p6)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("0e");
        int v1_4 = new java.util.Random().nextInt(256);
        com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v1_4);
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v1_4));
        int v2_1 = 0;
        while (v2_1 < p6.length()) {
            String v3_6 = Integer.valueOf(new StringBuilder("0").append(p6.charAt(v2_1)).toString(), 16).intValue();
            com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v3_6);
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt((v3_6 ^ v1_4)));
            v2_1++;
        }
        java.util.List v6_3 = Integer.valueOf("00", 16).intValue();
        int v1_1 = 2;
        while (v1_1 < v0_1.size()) {
            v6_3 ^= Integer.valueOf(((String) v0_1.get(v1_1)), 16).intValue();
            v1_1++;
        }
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(v6_3));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSetRyhthmType(int p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("06");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForInt(p2));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartDataForProgram(java.util.List p2, int p3, int p4)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("02");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(p2));
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForIntWithOneByte(p3));
        v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForIntWithOneByte(p4));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getStartOTAUpdate(java.util.List p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("fe");
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils$CrcCode.getCrcCode(p2));
        v0_1.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.getHexListStringForIntWithFourByte(p2));
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static java.util.List getSwitchData(boolean p2)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        v0_1.add("05");
        if (p2 == null) {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(0));
        } else {
            v0_1.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt(1));
        }
        return com.jtkj.led1248.light.utils.CoolledMUtils.getSendDataWithInfo(v0_1);
    }

    public static com.jtkj.led1248.light.utils.LightUtils$TextColorDataFor32Device getTextCustomColorDataForEmoji(com.jtkj.led1248.light.device.DeviceManager$TextCustomColorProgramContent p0, com.jtkj.led1248.light.utils.FontUtils p1)
    {
        return p1.getFontByteCustomColorDataCoolledmForEmoji(p0);
    }

    public static com.jtkj.led1248.light.utils.LightUtils$TextData getTextDataForEmoji(com.jtkj.led1248.light.device.DeviceManager$TextContentProgramContent p3, com.jtkj.led1248.light.utils.FontUtils p4)
    {
        com.jtkj.led1248.light.utils.LightUtils$TextData v0_1 = new com.jtkj.led1248.light.utils.LightUtils$TextData();
        String v1_5 = new java.util.ArrayList();
        try {
            v1_5.addAll(com.jtkj.led1248.light.utils.CoolledMUtils.byte2hex(p4.getFontByteDataCoolledmForEmoji(p3).data));
            v0_1.data = v1_5;
            return v0_1;
        } catch (Exception v3_1) {
            com.jtkj.library.commom.logger.CLog.i(com.jtkj.led1248.light.utils.CoolledMUtils.TAG, new StringBuilder("catch (Exception e) ").append(v3_1.getMessage()).toString());
            com.jtkj.led1248.CoolLED.reportError(v3_1);
            return v0_1;
        }
    }

    public static boolean isArab(String p1)
    {
        if (!p1.matches("[\\u0600-\\u06ff|\\u0750-\\u077f].*")) {
            return 0;
        } else {
            return 1;
        }
    }

    public static boolean isArbOrXbl(java.util.List p2)
    {
        int v2_1 = p2.iterator();
        while (v2_1.hasNext()) {
            boolean v0_4 = ((com.jtkj.led1248.light.emoji.TextEmojiManager$TextEmojiItem) v2_1.next());
            if ((v0_4.isText) && ((com.jtkj.led1248.light.utils.CoolledMUtils.isArab(v0_4.text)) || (com.jtkj.led1248.light.utils.CoolledMUtils.isXbl(v0_4.text)))) {
                return 1;
            }
        }
        return 0;
    }

    public static boolean isXbl(String p1)
    {
        if (!p1.matches("[\\u0590-\\u05ff].*")) {
            return 0;
        } else {
            return 1;
        }
    }

    public static java.util.List recoverData(java.util.List p7)
    {
        java.util.ArrayList v0_1 = new java.util.ArrayList();
        int v2_0 = 0;
        int v3 = 1;
        int v5 = 2;
        if ((p7.size() > 2) && ((Integer.parseInt(((String) p7.get(0)), 16) == Integer.parseInt("01", 16)) && (Integer.parseInt(((String) p7.get((p7.size() - 1))), 16) == Integer.parseInt("03", 16)))) {
            v0_1 = p7.subList(v3, (p7.size() - v3));
        }
        java.util.ArrayList v7_2 = new java.util.ArrayList();
        while (v2_0 < v0_1.size()) {
            if (Integer.parseInt(((String) v0_1.get(v2_0)), 16) == Integer.parseInt("02", 16)) {
                String v1_16 = (v2_0 + 1);
                if (v1_16 < v0_1.size()) {
                    v7_2.add(com.jtkj.led1248.light.utils.CoolledMUtils.getHexStringForInt((Integer.valueOf(((String) v0_1.get(v1_16)), 16).intValue() ^ Integer.valueOf("04", 16).intValue())));
                    v2_0 = v1_16;
                }
            } else {
                v7_2.add(((String) v0_1.get(v2_0)));
            }
            v2_0++;
        }
        java.util.ArrayList v0_5 = new java.util.ArrayList();
        while (v5 < v7_2.size()) {
            v0_5.add(((String) v7_2.get(v5)));
            v5++;
        }
        return v0_5;
    }
}
